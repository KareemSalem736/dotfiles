/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2016, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.openid.connect.sdk.federation.policy.language;


import net.minidev.json.JSONObject;


/**
 * JSON object configuration.
 */
public interface JSONObjectConfiguration extends PolicyConfiguration {
	
	
	/**
	 * Configure.
	 *
	 * @param parameter The JSON object configuration parameter. Must not
	 *                  be {@code null}.
	 */
	void configure(final JSONObject parameter);
	
	
	/**
	 * Gets the JSON object configuration.
	 *
	 * @return The JSON object configuration parameter.
	 */
	JSONObject getJSONObjectConfiguration();
}
