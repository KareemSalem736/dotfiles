/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2020, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.openid.connect.sdk.federation.api;


import net.jcip.annotations.Immutable;

import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;


/**
 * Fetch entity statement error response.
 *
 * <p>Related specifications:
 *
 * <ul>
 *     <li>OpenID Connect Federation 1.0, sections 7.1.2 and 7.5.
 * </ul>
 */
@Immutable
public class FetchEntityStatementErrorResponse extends FetchEntityStatementResponse {
	
	
	/**
	 * The federation API error.
	 */
	private final FederationAPIError error;
	
	
	/**
	 * Creates a new fetch entity statement error response.
	 *
	 * @param error The federation API error. Must not be {@code null}.
	 */
	public FetchEntityStatementErrorResponse(final FederationAPIError error) {
		if (error == null) {
			throw new IllegalArgumentException("The error object must not be null");
		}
		this.error = error;
	}
	
	
	/**
	 * Returns the federation API error.
	 *
	 * @return The federation API error.
	 */
	public FederationAPIError getErrorObject() {
		return error;
	}
	
	
	@Override
	public boolean indicatesSuccess() {
		return false;
	}
	
	
	@Override
	public HTTPResponse toHTTPResponse() {
		return error.toHTTPResponse();
	}
	
	
	/**
	 * Parses a fetch entity statement error response from the specified
	 * HTTP response.
	 *
	 * @param httpResponse The HTTP response. Must not be {@code null}.
	 *
	 * @return The fetch entity statement error response.
	 *
	 * @throws ParseException If parsing failed.
	 */
	public static FetchEntityStatementErrorResponse parse(final HTTPResponse httpResponse)
		throws ParseException {
		httpResponse.ensureStatusCodeNotOK();
		return new FetchEntityStatementErrorResponse(FederationAPIError.parse(httpResponse));
	}
}
