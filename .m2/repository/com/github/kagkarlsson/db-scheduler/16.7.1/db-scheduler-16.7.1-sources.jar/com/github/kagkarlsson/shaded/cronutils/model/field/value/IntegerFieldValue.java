/*
 * Copyright 2015 jmrozanec
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.github.kagkarlsson.shaded.cronutils.model.field.value;

public class IntegerFieldValue extends FieldValue<Integer> {

    private static final long serialVersionUID = -1305795676868267699L;
    private final int value;

    public IntegerFieldValue(final int value) {
        this.value = value;
    }

    @Override
    public Integer getValue() {
        return value;
    }
}

