/*
 * Copyright 2012-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.boot.graphql.autoconfigure.servlet;

import java.util.Collections;
import java.util.Map;

import graphql.GraphQL;
import jakarta.websocket.server.ServerContainer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jspecify.annotations.Nullable;

import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.graphql.autoconfigure.GraphQlAutoConfiguration;
import org.springframework.boot.graphql.autoconfigure.GraphQlCorsProperties;
import org.springframework.boot.graphql.autoconfigure.GraphQlProperties;
import org.springframework.boot.http.converter.autoconfigure.ServerHttpMessageConvertersCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportRuntimeHints;
import org.springframework.core.annotation.Order;
import org.springframework.core.log.LogMessage;
import org.springframework.graphql.ExecutionGraphQlService;
import org.springframework.graphql.execution.GraphQlSource;
import org.springframework.graphql.server.WebGraphQlHandler;
import org.springframework.graphql.server.WebGraphQlInterceptor;
import org.springframework.graphql.server.webmvc.GraphQlHttpHandler;
import org.springframework.graphql.server.webmvc.GraphQlRequestPredicates;
import org.springframework.graphql.server.webmvc.GraphQlSseHandler;
import org.springframework.graphql.server.webmvc.GraphQlWebSocketHandler;
import org.springframework.graphql.server.webmvc.GraphiQlHandler;
import org.springframework.graphql.server.webmvc.SchemaHandler;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverters;
import org.springframework.http.converter.HttpMessageConverters.ServerBuilder;
import org.springframework.util.Assert;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.RouterFunctions;
import org.springframework.web.servlet.function.ServerRequest;
import org.springframework.web.servlet.function.ServerResponse;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.support.DefaultHandshakeHandler;
import org.springframework.web.socket.server.support.WebSocketHandlerMapping;

/**
 * {@link EnableAutoConfiguration Auto-configuration} for enabling Spring GraphQL over
 * Spring MVC.
 *
 * @author Brian Clozel
 * @since 4.0.0
 */
@AutoConfiguration(after = GraphQlAutoConfiguration.class)
@ConditionalOnWebApplication(type = Type.SERVLET)
@ConditionalOnClass({ GraphQL.class, GraphQlHttpHandler.class })
@ConditionalOnBean(ExecutionGraphQlService.class)
@EnableConfigurationProperties(GraphQlCorsProperties.class)
@ImportRuntimeHints(GraphQlWebMvcAutoConfiguration.GraphiQlResourceHints.class)
public final class GraphQlWebMvcAutoConfiguration {

	private static final Log logger = LogFactory.getLog(GraphQlWebMvcAutoConfiguration.class);

	@Bean
	@ConditionalOnMissingBean
	GraphQlHttpHandler graphQlHttpHandler(WebGraphQlHandler webGraphQlHandler) {
		return new GraphQlHttpHandler(webGraphQlHandler);
	}

	@Bean
	@ConditionalOnMissingBean
	GraphQlSseHandler graphQlSseHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties) {
		return new GraphQlSseHandler(webGraphQlHandler, properties.getHttp().getSse().getTimeout(),
				properties.getHttp().getSse().getKeepAlive());
	}

	@Bean
	@ConditionalOnMissingBean
	WebGraphQlHandler webGraphQlHandler(ExecutionGraphQlService service,
			ObjectProvider<WebGraphQlInterceptor> interceptors) {
		return WebGraphQlHandler.builder(service).interceptors(interceptors.orderedStream().toList()).build();
	}

	@Bean
	@Order(0)
	RouterFunction<ServerResponse> graphQlRouterFunction(GraphQlHttpHandler httpHandler, GraphQlSseHandler sseHandler,
			ObjectProvider<GraphQlSource> graphQlSourceProvider, GraphQlProperties properties) {
		String path = properties.getHttp().getPath();
		logger.info(LogMessage.format("GraphQL endpoint HTTP POST %s", path));
		RouterFunctions.Builder builder = RouterFunctions.route();
		builder.route(GraphQlRequestPredicates.graphQlHttp(path), httpHandler::handleRequest);
		builder.route(GraphQlRequestPredicates.graphQlSse(path), sseHandler::handleRequest);
		builder.POST(path, this::unsupportedMediaType);
		builder.GET(path, this::onlyAllowPost);
		if (properties.getGraphiql().isEnabled()) {
			GraphiQlHandler graphiQLHandler = createGraphiQLHandler(properties, path);
			builder.GET(properties.getGraphiql().getPath(), graphiQLHandler::handleRequest);
		}
		GraphQlSource graphQlSource = graphQlSourceProvider.getIfAvailable();
		if (properties.getSchema().getPrinter().isEnabled() && graphQlSource != null) {
			SchemaHandler schemaHandler = new SchemaHandler(graphQlSource);
			builder.GET(path + "/schema", schemaHandler::handleRequest);
		}
		return builder.build();
	}

	private GraphiQlHandler createGraphiQLHandler(GraphQlProperties properties, String path) {
		return new GraphiQlHandler(path, properties.getWebsocket().getPath());
	}

	private ServerResponse unsupportedMediaType(ServerRequest request) {
		return ServerResponse.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).headers(this::acceptJson).build();
	}

	private void acceptJson(HttpHeaders headers) {
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
	}

	private ServerResponse onlyAllowPost(ServerRequest request) {
		return ServerResponse.status(HttpStatus.METHOD_NOT_ALLOWED).headers(this::onlyAllowPost).build();
	}

	private void onlyAllowPost(HttpHeaders headers) {
		headers.setAllow(Collections.singleton(HttpMethod.POST));
	}

	@Configuration(proxyBeanMethods = false)
	static class GraphQlEndpointCorsConfiguration implements WebMvcConfigurer {

		final GraphQlProperties graphQlProperties;

		final GraphQlCorsProperties corsProperties;

		GraphQlEndpointCorsConfiguration(GraphQlProperties graphQlProps, GraphQlCorsProperties corsProps) {
			this.graphQlProperties = graphQlProps;
			this.corsProperties = corsProps;
		}

		@Override
		public void addCorsMappings(CorsRegistry registry) {
			CorsConfiguration configuration = this.corsProperties.toCorsConfiguration();
			if (configuration != null) {
				registry.addMapping(this.graphQlProperties.getHttp().getPath()).combine(configuration);
			}
		}

	}

	@Configuration(proxyBeanMethods = false)
	@ConditionalOnClass({ HttpMessageConverter.class, ServerContainer.class, WebSocketHandler.class })
	@ConditionalOnProperty("spring.graphql.websocket.path")
	static class WebSocketConfiguration {

		@Bean
		@ConditionalOnMissingBean
		GraphQlWebSocketHandler graphQlWebSocketHandler(WebGraphQlHandler webGraphQlHandler,
				GraphQlProperties properties, ObjectProvider<ServerHttpMessageConvertersCustomizer> customizers) {
			return new GraphQlWebSocketHandler(webGraphQlHandler, getJsonConverter(customizers),
					properties.getWebsocket().getConnectionInitTimeout(), properties.getWebsocket().getKeepAlive());
		}

		private HttpMessageConverter<Object> getJsonConverter(
				ObjectProvider<ServerHttpMessageConvertersCustomizer> customizers) {
			ServerBuilder serverBuilder = HttpMessageConverters.forServer().registerDefaults();
			customizers.forEach((customizer) -> customizer.customize(serverBuilder));
			for (HttpMessageConverter<?> converter : serverBuilder.build()) {
				if (canReadJsonMap(converter)) {
					return asObjectHttpMessageConverter(converter);
				}
			}
			throw new IllegalStateException("No JSON converter");
		}

		private boolean canReadJsonMap(HttpMessageConverter<?> candidate) {
			return candidate.canRead(Map.class, MediaType.APPLICATION_JSON);
		}

		@SuppressWarnings("unchecked")
		private HttpMessageConverter<Object> asObjectHttpMessageConverter(HttpMessageConverter<?> converter) {
			return (HttpMessageConverter<Object>) converter;
		}

		@Bean
		HandlerMapping graphQlWebSocketMapping(GraphQlWebSocketHandler handler, GraphQlProperties properties) {
			String path = properties.getWebsocket().getPath();
			Assert.state(path != null, "'path' must not be null");
			logger.info(LogMessage.format("GraphQL endpoint WebSocket %s", path));
			WebSocketHandlerMapping mapping = new WebSocketHandlerMapping();
			mapping.setWebSocketUpgradeMatch(true);
			mapping.setUrlMap(Collections.singletonMap(path,
					handler.initWebSocketHttpRequestHandler(new DefaultHandshakeHandler())));
			mapping.setOrder(-2); // Ahead of HTTP endpoint ("routerFunctionMapping" bean)
			return mapping;
		}

	}

	static class GraphiQlResourceHints implements RuntimeHintsRegistrar {

		@Override
		public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
			hints.resources().registerPattern("graphiql/index.html");
		}

	}

}
