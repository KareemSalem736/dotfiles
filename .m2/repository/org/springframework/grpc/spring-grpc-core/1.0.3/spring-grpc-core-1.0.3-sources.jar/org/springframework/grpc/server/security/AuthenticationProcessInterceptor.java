/*
 * Copyright 2024-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.grpc.server.security;

import org.springframework.core.Ordered;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.authorization.AuthorizationResult;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import io.grpc.Context;
import io.grpc.Contexts;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCall.Listener;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;

/**
 * An interceptor that extracts the authentication credentials from the gRPC request
 * headers and metadata, authenticates the user, and sets the authentication in the
 * SecurityContext. This interceptor should be registered with the gRPC server to handle
 * authentication and authorization for gRPC requests.
 *
 * @author Dave Syer
 * @author Hyunsang Han
 */
public class AuthenticationProcessInterceptor implements ServerInterceptor, Ordered {

	private final AuthenticationManager authenticationManager;

	private final GrpcAuthenticationExtractor extractor;

	private AuthorizationManager<CallContext> authorizationManager;

	@Override
	public int getOrder() {
		return GrpcSecurity.CONTEXT_FILTER_ORDER - 10;
	}

	public AuthenticationProcessInterceptor(AuthenticationManager authenticationManager,
			GrpcAuthenticationExtractor extractor, AuthorizationManager<CallContext> authorizationManager) {
		this.authenticationManager = authenticationManager;
		this.extractor = extractor;
		this.authorizationManager = authorizationManager;
	}

	@Override
	public <ReqT, RespT> Listener<ReqT> interceptCall(ServerCall<ReqT, RespT> call, Metadata headers,
			ServerCallHandler<ReqT, RespT> next) {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		Authentication user = this.extractor.extract(headers, call.getAttributes(), call.getMethodDescriptor());
		if (user != null) {
			user = this.authenticationManager.authenticate(user);
			securityContext.setAuthentication(user);
		}

		if (this.authorizationManager != null) {
			CallContext context = new CallContext(headers, call.getAttributes(), call.getMethodDescriptor());
			if (user == null) {
				// Maybe just throw BadCredentialsException (authentication manager would
				// have to make the anonymous user)?
				user = new AnonymousAuthenticationToken("anonymous", "anonymous",
						AuthorityUtils.createAuthorityList("ROLE_ANONYMOUS"));
			}
			Authentication authentication = user;
			AuthorizationResult authResult = this.authorizationManager.authorize(() -> authentication, context);
			if (authResult == null || !authResult.isGranted()) {
				if (user instanceof AnonymousAuthenticationToken) {
					throw new BadCredentialsException("not authenticated");
				}
				throw new AccessDeniedException("not allowed");
			}
		}
		else if (user == null || !user.isAuthenticated()) {
			throw new BadCredentialsException("not authenticated");
		}
		// Only if successfully authenticated and authorized do we set the context for the
		// call
		SecurityContextHolder.setContext(securityContext);

		try {
			Context context = Context.current().withValue(GrpcSecurity.SECURITY_CONTEXT_KEY, securityContext);
			return new SecurityContextHandlerListener<ReqT, RespT>(Contexts.interceptCall(context, call, headers, next),
					securityContext);
		}
		finally {
			SecurityContextHolder.clearContext();
		}
	}

}
