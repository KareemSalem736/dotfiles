/*
 * Copyright 2024-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.grpc.server.exception;

import org.jspecify.annotations.Nullable;

import io.grpc.StatusException;

public class CompositeGrpcExceptionHandler implements GrpcExceptionHandler {

	private final GrpcExceptionHandler[] exceptionHandlers;

	public CompositeGrpcExceptionHandler(GrpcExceptionHandler... exceptionHandlers) {
		this.exceptionHandlers = exceptionHandlers;
	}

	@Override
	public @Nullable StatusException handleException(Throwable exception) {
		for (GrpcExceptionHandler exceptionHandler : this.exceptionHandlers) {
			StatusException status = exceptionHandler.handleException(exception);
			if (status != null) {
				return status;
			}
		}
		return null;
	}

}
