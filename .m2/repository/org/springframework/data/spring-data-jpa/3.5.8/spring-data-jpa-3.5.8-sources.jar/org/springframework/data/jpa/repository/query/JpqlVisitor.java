// Generated from org/springframework/data/jpa/repository/query/Jpql.g4 by ANTLR 4.13.0
package org.springframework.data.jpa.repository.query;

/**
 * JPQL per https://jakarta.ee/specifications/persistence/3.1/jakarta-persistence-spec-3.1.html#bnf
 *
 * This is JPA BNF for JPQL. There are gaps and inconsistencies in the BNF itself, explained by other fragments of the spec.
 *
 * @see https://github.com/jakartaee/persistence/blob/master/spec/src/main/asciidoc/ch04-query-language.adoc#bnf
 * @author Greg Turnquist
 * @author Christoph Strobl
 * @since 3.1
 */

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link JpqlParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
interface JpqlVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link JpqlParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(JpqlParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#ql_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQl_statement(JpqlParser.Ql_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#select_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_statement(JpqlParser.Select_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#update_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_statement(JpqlParser.Update_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#delete_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelete_statement(JpqlParser.Delete_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_clause(JpqlParser.From_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#identificationVariableDeclarationOrCollectionMemberDeclaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(JpqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#identification_variable_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentification_variable_declaration(JpqlParser.Identification_variable_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#range_variable_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange_variable_declaration(JpqlParser.Range_variable_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin(JpqlParser.JoinContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#fetch_join}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFetch_join(JpqlParser.Fetch_joinContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join_spec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_spec(JpqlParser.Join_specContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join_condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_condition(JpqlParser.Join_conditionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join_association_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_association_path_expression(JpqlParser.Join_association_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join_collection_valued_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_collection_valued_path_expression(JpqlParser.Join_collection_valued_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#join_single_valued_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJoin_single_valued_path_expression(JpqlParser.Join_single_valued_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_member_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_member_declaration(JpqlParser.Collection_member_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#qualified_identification_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQualified_identification_variable(JpqlParser.Qualified_identification_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#map_field_identification_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMap_field_identification_variable(JpqlParser.Map_field_identification_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#single_valued_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_valued_path_expression(JpqlParser.Single_valued_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#general_identification_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGeneral_identification_variable(JpqlParser.General_identification_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#general_subpath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGeneral_subpath(JpqlParser.General_subpathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_subpath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_subpath(JpqlParser.Simple_subpathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#treated_subpath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTreated_subpath(JpqlParser.Treated_subpathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#state_field_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitState_field_path_expression(JpqlParser.State_field_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#state_valued_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitState_valued_path_expression(JpqlParser.State_valued_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#single_valued_object_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_valued_object_path_expression(JpqlParser.Single_valued_object_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_valued_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_valued_path_expression(JpqlParser.Collection_valued_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#update_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_clause(JpqlParser.Update_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#update_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_item(JpqlParser.Update_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#new_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_value(JpqlParser.New_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#delete_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelete_clause(JpqlParser.Delete_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#select_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_clause(JpqlParser.Select_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#select_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_item(JpqlParser.Select_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#select_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_expression(JpqlParser.Select_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#constructor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstructor_expression(JpqlParser.Constructor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#constructor_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstructor_item(JpqlParser.Constructor_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#aggregate_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggregate_expression(JpqlParser.Aggregate_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhere_clause(JpqlParser.Where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#groupby_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupby_clause(JpqlParser.Groupby_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#groupby_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupby_item(JpqlParser.Groupby_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#having_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHaving_clause(JpqlParser.Having_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#orderby_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderby_clause(JpqlParser.Orderby_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#orderby_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderby_item(JpqlParser.Orderby_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#nullsPrecedence}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullsPrecedence(JpqlParser.NullsPrecedenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#subquery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubquery(JpqlParser.SubqueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#subquery_from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubquery_from_clause(JpqlParser.Subquery_from_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#subselect_identification_variable_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubselect_identification_variable_declaration(JpqlParser.Subselect_identification_variable_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#derived_path_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDerived_path_expression(JpqlParser.Derived_path_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#general_derived_path}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGeneral_derived_path(JpqlParser.General_derived_pathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_derived_path}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_derived_path(JpqlParser.Simple_derived_pathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#treated_derived_path}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTreated_derived_path(JpqlParser.Treated_derived_pathContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#derived_collection_member_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDerived_collection_member_declaration(JpqlParser.Derived_collection_member_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_select_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_select_clause(JpqlParser.Simple_select_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_select_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_select_expression(JpqlParser.Simple_select_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#scalar_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScalar_expression(JpqlParser.Scalar_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#conditional_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_expression(JpqlParser.Conditional_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#conditional_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_term(JpqlParser.Conditional_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#conditional_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_factor(JpqlParser.Conditional_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#conditional_primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditional_primary(JpqlParser.Conditional_primaryContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_cond_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_cond_expression(JpqlParser.Simple_cond_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#between_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween_expression(JpqlParser.Between_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#in_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn_expression(JpqlParser.In_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#in_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn_item(JpqlParser.In_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#like_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLike_expression(JpqlParser.Like_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#null_comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNull_comparison_expression(JpqlParser.Null_comparison_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#empty_collection_comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmpty_collection_comparison_expression(JpqlParser.Empty_collection_comparison_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_member_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_member_expression(JpqlParser.Collection_member_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#entity_or_value_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntity_or_value_expression(JpqlParser.Entity_or_value_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_entity_or_value_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_entity_or_value_expression(JpqlParser.Simple_entity_or_value_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#exists_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExists_expression(JpqlParser.Exists_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#all_or_any_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAll_or_any_expression(JpqlParser.All_or_any_expressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StringComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringComparison(JpqlParser.StringComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BooleanComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanComparison(JpqlParser.BooleanComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DirectBooleanCheck}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDirectBooleanCheck(JpqlParser.DirectBooleanCheckContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EnumComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnumComparison(JpqlParser.EnumComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DatetimeComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatetimeComparison(JpqlParser.DatetimeComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EntityComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntityComparison(JpqlParser.EntityComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArithmeticComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticComparison(JpqlParser.ArithmeticComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EntityTypeComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntityTypeComparison(JpqlParser.EntityTypeComparisonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RegexpComparison}
	 * labeled alternative in {@link JpqlParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegexpComparison(JpqlParser.RegexpComparisonContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#comparison_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparison_operator(JpqlParser.Comparison_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#arithmetic_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmetic_expression(JpqlParser.Arithmetic_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#arithmetic_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmetic_term(JpqlParser.Arithmetic_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#arithmetic_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmetic_factor(JpqlParser.Arithmetic_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#arithmetic_primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmetic_primary(JpqlParser.Arithmetic_primaryContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#string_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString_expression(JpqlParser.String_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#datetime_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatetime_expression(JpqlParser.Datetime_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#boolean_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolean_expression(JpqlParser.Boolean_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#enum_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnum_expression(JpqlParser.Enum_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#entity_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntity_expression(JpqlParser.Entity_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_entity_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_entity_expression(JpqlParser.Simple_entity_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#entity_type_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntity_type_expression(JpqlParser.Entity_type_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#type_discriminator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_discriminator(JpqlParser.Type_discriminatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#functions_returning_numerics}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctions_returning_numerics(JpqlParser.Functions_returning_numericsContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#functions_returning_datetime}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctions_returning_datetime(JpqlParser.Functions_returning_datetimeContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#functions_returning_strings}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctions_returning_strings(JpqlParser.Functions_returning_stringsContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#trim_specification}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrim_specification(JpqlParser.Trim_specificationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#arithmetic_cast_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmetic_cast_function(JpqlParser.Arithmetic_cast_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#type_cast_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_cast_function(JpqlParser.Type_cast_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#string_cast_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString_cast_function(JpqlParser.String_cast_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#function_invocation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_invocation(JpqlParser.Function_invocationContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#extract_datetime_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtract_datetime_field(JpqlParser.Extract_datetime_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#datetime_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatetime_field(JpqlParser.Datetime_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#extract_datetime_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtract_datetime_part(JpqlParser.Extract_datetime_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#datetime_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatetime_part(JpqlParser.Datetime_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#function_arg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_arg(JpqlParser.Function_argContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#case_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_expression(JpqlParser.Case_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#general_case_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGeneral_case_expression(JpqlParser.General_case_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#when_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhen_clause(JpqlParser.When_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_case_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_case_expression(JpqlParser.Simple_case_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#case_operand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_operand(JpqlParser.Case_operandContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#simple_when_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimple_when_clause(JpqlParser.Simple_when_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#coalesce_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCoalesce_expression(JpqlParser.Coalesce_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#nullif_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullif_expression(JpqlParser.Nullif_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#trim_character}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrim_character(JpqlParser.Trim_characterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#identification_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentification_variable(JpqlParser.Identification_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#constructor_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstructor_name(JpqlParser.Constructor_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral(JpqlParser.LiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#input_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInput_parameter(JpqlParser.Input_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#pattern_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPattern_value(JpqlParser.Pattern_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#date_time_timestamp_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDate_time_timestamp_literal(JpqlParser.Date_time_timestamp_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#entity_type_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntity_type_literal(JpqlParser.Entity_type_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#escape_character}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEscape_character(JpqlParser.Escape_characterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#numeric_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumeric_literal(JpqlParser.Numeric_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#boolean_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolean_literal(JpqlParser.Boolean_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#enum_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnum_literal(JpqlParser.Enum_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#string_literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString_literal(JpqlParser.String_literalContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#single_valued_embeddable_object_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_valued_embeddable_object_field(JpqlParser.Single_valued_embeddable_object_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#subtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubtype(JpqlParser.SubtypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_valued_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_valued_field(JpqlParser.Collection_valued_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#single_valued_object_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_valued_object_field(JpqlParser.Single_valued_object_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#state_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitState_field(JpqlParser.State_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_value_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_value_field(JpqlParser.Collection_value_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#entity_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntity_name(JpqlParser.Entity_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#result_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitResult_variable(JpqlParser.Result_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#superquery_identification_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSuperquery_identification_variable(JpqlParser.Superquery_identification_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#collection_valued_input_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollection_valued_input_parameter(JpqlParser.Collection_valued_input_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#single_valued_input_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_valued_input_parameter(JpqlParser.Single_valued_input_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#function_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_name(JpqlParser.Function_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#character_valued_input_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharacter_valued_input_parameter(JpqlParser.Character_valued_input_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link JpqlParser#reserved_word}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReserved_word(JpqlParser.Reserved_wordContext ctx);
}