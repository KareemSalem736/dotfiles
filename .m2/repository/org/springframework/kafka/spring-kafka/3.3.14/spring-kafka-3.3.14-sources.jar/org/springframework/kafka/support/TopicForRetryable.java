/*
 * Copyright 2022-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.kafka.support;

import org.apache.kafka.clients.admin.NewTopic;

/**
 * Marker to indicate this {@link NewTopic} is for retryable topics; admin will ignore these if
 * a regular {@link NewTopic} exist.
 *
 * @author Gary Russell
 * @since 2.8.10
 *
 */
public class TopicForRetryable extends NewTopic {

	/**
	 * Create an instance with the provided properties.
	 * @param topic the topic.
	 * @param numPartitions the partitions.
	 * @param replicationFactor the replication factor.
	 */
	public TopicForRetryable(String topic, int numPartitions, short replicationFactor) {
		super(topic, numPartitions, replicationFactor);
	}

}
