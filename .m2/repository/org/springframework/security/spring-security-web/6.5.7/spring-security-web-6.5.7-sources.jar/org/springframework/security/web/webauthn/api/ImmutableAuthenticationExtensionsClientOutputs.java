/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.web.webauthn.api;

import java.io.Serial;
import java.util.Arrays;
import java.util.List;

/**
 * An immutable implementation of {@link AuthenticationExtensionsClientOutputs}.
 *
 * @author Rob Winch
 */
public class ImmutableAuthenticationExtensionsClientOutputs implements AuthenticationExtensionsClientOutputs {

	@Serial
	private static final long serialVersionUID = -4656390173585180393L;

	private final List<AuthenticationExtensionsClientOutput<?>> outputs;

	public ImmutableAuthenticationExtensionsClientOutputs(List<AuthenticationExtensionsClientOutput<?>> outputs) {
		this.outputs = outputs;
	}

	public ImmutableAuthenticationExtensionsClientOutputs(AuthenticationExtensionsClientOutput<?>... outputs) {
		this(Arrays.asList(outputs));
	}

	@Override
	public List<AuthenticationExtensionsClientOutput<?>> getOutputs() {
		return this.outputs;
	}

}
