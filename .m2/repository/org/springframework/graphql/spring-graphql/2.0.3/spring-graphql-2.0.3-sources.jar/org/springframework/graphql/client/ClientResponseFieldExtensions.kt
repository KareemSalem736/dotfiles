/*
 * Copyright 2025-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.graphql.client

import org.springframework.core.ParameterizedTypeReference

/**
 * Extension for [ClientResponseField.toEntity] providing a `toEntity<Book>()` variant
 * leveraging Kotlin reified type parameters. This extension is not subject to type
 * erasure and retains actual generic type arguments.
 *
 * @author Brian Clozel
 * @since 2.0.1
 */
inline fun <reified T : Any> ClientResponseField.toEntity(): T? =
    toEntity(object : ParameterizedTypeReference<T>() {})

/**
 * Extension for [ClientResponseField.toEntityList] providing a `toEntityList<Book>()` variant
 * leveraging Kotlin reified type parameters. This extension is not subject to type
 * erasure and retains actual generic type arguments.
 *
 * @author Brian Clozel
 * @since 2.0.1
 */
inline fun <reified T : Any> ClientResponseField.toEntityList(): List<T> =
    toEntityList(object : ParameterizedTypeReference<T>() {})
