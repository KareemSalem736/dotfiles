/*
 * Copyright 2012-2017 Brian Campbell
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jose4j.jwk;

import org.jose4j.jws.EcdsaUsingShaAlgorithm;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jws.JsonWebSignatureAlgorithm;
import org.jose4j.lang.JoseException;

import java.util.Collection;
import java.util.List;

/**
 *
 */
public class VerificationJwkSelector
{
    private static final String[] EDDSA_CRVS = new String[]{OctetKeyPairJsonWebKey.SUBTYPE_ED25519, OctetKeyPairJsonWebKey.SUBTYPE_ED448};

    public JsonWebKey select(JsonWebSignature jws, Collection<JsonWebKey> keys) throws JoseException
    {
        List<JsonWebKey> jsonWebKeys = selectList(jws, keys);
        return jsonWebKeys.isEmpty() ? null : jsonWebKeys.get(0);
    }

    public List<JsonWebKey> selectList(JsonWebSignature jws, Collection<JsonWebKey> keys) throws JoseException
    {
        SimpleJwkFilter filter = SelectorSupport.filterForInboundSigned(jws);
        List<JsonWebKey> filtered = filter.filter(keys);

        if (hasMoreThanOne(filtered))
        {
            filter.setAlg(jws.getAlgorithmHeaderValue(), SimpleJwkFilter.OMITTED_OKAY);
            filtered = filter.filter(filtered);
        }

        if (hasMoreThanOne(filtered))
        {
            String keyType = jws.getKeyType();
            if (EllipticCurveJsonWebKey.KEY_TYPE.equals(keyType))
            {
                JsonWebSignatureAlgorithm algorithm = jws.getAlgorithmNoConstraintCheck();
                EcdsaUsingShaAlgorithm ecdsaAlgorithm = (EcdsaUsingShaAlgorithm) algorithm;
                filter.setCrv(ecdsaAlgorithm.getCurveName(), SimpleJwkFilter.OMITTED_OKAY);
                filtered = filter.filter(filtered);
            }
            else if (OctetKeyPairJsonWebKey.KEY_TYPE.equals(keyType))
            {
                filter.setCrvs(EDDSA_CRVS, SimpleJwkFilter.OMITTED_OKAY);
                filtered = filter.filter(filtered);
            }
        }

        return filtered;

        // todo -> if >1, try even harder... maybe. But are there actually realistic cases where this will happen?
    }

    public JsonWebKey selectWithVerifySignatureDisambiguate(JsonWebSignature jws, Collection<JsonWebKey> keys) throws JoseException
    {
        List<JsonWebKey> jsonWebKeys = selectList(jws, keys);
        if (jsonWebKeys.isEmpty())
        {
            return null;
        }
        else if (jsonWebKeys.size() == 1)
        {
            return jsonWebKeys.get(0);
        }
        else
        {
            for (JsonWebKey jwk : jsonWebKeys)
            {
                jws.setKey(jwk.getKey());
                if (jws.verifySignature())
                {
                    return jwk;
                }
            }
        }
        return null;
    }

    private boolean hasMoreThanOne(List<JsonWebKey> filtered)
    {
        return filtered.size() > 1;
    }
}