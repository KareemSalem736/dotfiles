/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.share.generated;

import java.util.ArrayList;
import java.util.List;
import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.protocol.ApiMessage;
import org.apache.kafka.common.protocol.Message;
import org.apache.kafka.common.protocol.MessageSizeAccumulator;
import org.apache.kafka.common.protocol.MessageUtil;
import org.apache.kafka.common.protocol.ObjectSerializationCache;
import org.apache.kafka.common.protocol.Readable;
import org.apache.kafka.common.protocol.Writable;
import org.apache.kafka.common.protocol.types.CompactArrayOf;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.protocol.types.RawTaggedField;
import org.apache.kafka.common.protocol.types.RawTaggedFieldWriter;
import org.apache.kafka.common.protocol.types.Schema;
import org.apache.kafka.common.protocol.types.Type;
import org.apache.kafka.common.utils.ByteUtils;

import static org.apache.kafka.common.protocol.types.Field.TaggedFieldsSection;


public class ShareSnapshotValue implements ApiMessage {
    int snapshotEpoch;
    int stateEpoch;
    int leaderEpoch;
    long startOffset;
    long createTimestamp;
    long writeTimestamp;
    List<StateBatch> stateBatches;
    private List<RawTaggedField> _unknownTaggedFields;
    
    public static final Schema SCHEMA_0 =
        new Schema(
            new Field("snapshot_epoch", Type.INT32, "The snapshot epoch."),
            new Field("state_epoch", Type.INT32, "The state epoch for this share-partition."),
            new Field("leader_epoch", Type.INT32, "The leader epoch of the share-partition."),
            new Field("start_offset", Type.INT64, "The share-partition start offset."),
            new Field("create_timestamp", Type.INT64, "The time at which the state was created."),
            new Field("write_timestamp", Type.INT64, "The time at which the state was written or rewritten."),
            new Field("state_batches", new CompactArrayOf(StateBatch.SCHEMA_0), "The state batches."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema[] SCHEMAS = new Schema[] {
        SCHEMA_0
    };
    
    public static final short LOWEST_SUPPORTED_VERSION = 0;
    public static final short HIGHEST_SUPPORTED_VERSION = 0;
    
    public ShareSnapshotValue(Readable _readable, short _version) {
        read(_readable, _version);
    }
    
    public ShareSnapshotValue() {
        this.snapshotEpoch = 0;
        this.stateEpoch = 0;
        this.leaderEpoch = 0;
        this.startOffset = 0L;
        this.createTimestamp = 0L;
        this.writeTimestamp = 0L;
        this.stateBatches = new ArrayList<StateBatch>(0);
    }
    
    @Override
    public short apiKey() {
        return 0;
    }
    
    @Override
    public short lowestSupportedVersion() {
        return 0;
    }
    
    @Override
    public short highestSupportedVersion() {
        return 0;
    }
    
    @Override
    public final void read(Readable _readable, short _version) {
        this.snapshotEpoch = _readable.readInt();
        this.stateEpoch = _readable.readInt();
        this.leaderEpoch = _readable.readInt();
        this.startOffset = _readable.readLong();
        this.createTimestamp = _readable.readLong();
        this.writeTimestamp = _readable.readLong();
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field stateBatches was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<StateBatch> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new StateBatch(_readable, _version));
                }
                this.stateBatches = newCollection;
            }
        }
        this._unknownTaggedFields = null;
        int _numTaggedFields = _readable.readUnsignedVarint();
        for (int _i = 0; _i < _numTaggedFields; _i++) {
            int _tag = _readable.readUnsignedVarint();
            int _size = _readable.readUnsignedVarint();
            switch (_tag) {
                default:
                    this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                    break;
            }
        }
    }
    
    @Override
    public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _writable.writeInt(snapshotEpoch);
        _writable.writeInt(stateEpoch);
        _writable.writeInt(leaderEpoch);
        _writable.writeLong(startOffset);
        _writable.writeLong(createTimestamp);
        _writable.writeLong(writeTimestamp);
        _writable.writeUnsignedVarint(stateBatches.size() + 1);
        for (StateBatch stateBatchesElement : stateBatches) {
            stateBatchesElement.write(_writable, _cache, _version);
        }
        RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
        _numTaggedFields += _rawWriter.numFields();
        _writable.writeUnsignedVarint(_numTaggedFields);
        _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
    }
    
    @Override
    public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _size.addBytes(4);
        _size.addBytes(4);
        _size.addBytes(4);
        _size.addBytes(8);
        _size.addBytes(8);
        _size.addBytes(8);
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(stateBatches.size() + 1));
            for (StateBatch stateBatchesElement : stateBatches) {
                stateBatchesElement.addSize(_size, _cache, _version);
            }
        }
        if (_unknownTaggedFields != null) {
            _numTaggedFields += _unknownTaggedFields.size();
            for (RawTaggedField _field : _unknownTaggedFields) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                _size.addBytes(_field.size());
            }
        }
        _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ShareSnapshotValue)) return false;
        ShareSnapshotValue other = (ShareSnapshotValue) obj;
        if (snapshotEpoch != other.snapshotEpoch) return false;
        if (stateEpoch != other.stateEpoch) return false;
        if (leaderEpoch != other.leaderEpoch) return false;
        if (startOffset != other.startOffset) return false;
        if (createTimestamp != other.createTimestamp) return false;
        if (writeTimestamp != other.writeTimestamp) return false;
        if (this.stateBatches == null) {
            if (other.stateBatches != null) return false;
        } else {
            if (!this.stateBatches.equals(other.stateBatches)) return false;
        }
        return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
    }
    
    @Override
    public int hashCode() {
        int hashCode = 0;
        hashCode = 31 * hashCode + snapshotEpoch;
        hashCode = 31 * hashCode + stateEpoch;
        hashCode = 31 * hashCode + leaderEpoch;
        hashCode = 31 * hashCode + ((int) (startOffset >> 32) ^ (int) startOffset);
        hashCode = 31 * hashCode + ((int) (createTimestamp >> 32) ^ (int) createTimestamp);
        hashCode = 31 * hashCode + ((int) (writeTimestamp >> 32) ^ (int) writeTimestamp);
        hashCode = 31 * hashCode + (stateBatches == null ? 0 : stateBatches.hashCode());
        return hashCode;
    }
    
    @Override
    public ShareSnapshotValue duplicate() {
        ShareSnapshotValue _duplicate = new ShareSnapshotValue();
        _duplicate.snapshotEpoch = snapshotEpoch;
        _duplicate.stateEpoch = stateEpoch;
        _duplicate.leaderEpoch = leaderEpoch;
        _duplicate.startOffset = startOffset;
        _duplicate.createTimestamp = createTimestamp;
        _duplicate.writeTimestamp = writeTimestamp;
        ArrayList<StateBatch> newStateBatches = new ArrayList<StateBatch>(stateBatches.size());
        for (StateBatch _element : stateBatches) {
            newStateBatches.add(_element.duplicate());
        }
        _duplicate.stateBatches = newStateBatches;
        return _duplicate;
    }
    
    @Override
    public String toString() {
        return "ShareSnapshotValue("
            + "snapshotEpoch=" + snapshotEpoch
            + ", stateEpoch=" + stateEpoch
            + ", leaderEpoch=" + leaderEpoch
            + ", startOffset=" + startOffset
            + ", createTimestamp=" + createTimestamp
            + ", writeTimestamp=" + writeTimestamp
            + ", stateBatches=" + MessageUtil.deepToString(stateBatches.iterator())
            + ")";
    }
    
    public int snapshotEpoch() {
        return this.snapshotEpoch;
    }
    
    public int stateEpoch() {
        return this.stateEpoch;
    }
    
    public int leaderEpoch() {
        return this.leaderEpoch;
    }
    
    public long startOffset() {
        return this.startOffset;
    }
    
    public long createTimestamp() {
        return this.createTimestamp;
    }
    
    public long writeTimestamp() {
        return this.writeTimestamp;
    }
    
    public List<StateBatch> stateBatches() {
        return this.stateBatches;
    }
    
    @Override
    public List<RawTaggedField> unknownTaggedFields() {
        if (_unknownTaggedFields == null) {
            _unknownTaggedFields = new ArrayList<>(0);
        }
        return _unknownTaggedFields;
    }
    
    public ShareSnapshotValue setSnapshotEpoch(int v) {
        this.snapshotEpoch = v;
        return this;
    }
    
    public ShareSnapshotValue setStateEpoch(int v) {
        this.stateEpoch = v;
        return this;
    }
    
    public ShareSnapshotValue setLeaderEpoch(int v) {
        this.leaderEpoch = v;
        return this;
    }
    
    public ShareSnapshotValue setStartOffset(long v) {
        this.startOffset = v;
        return this;
    }
    
    public ShareSnapshotValue setCreateTimestamp(long v) {
        this.createTimestamp = v;
        return this;
    }
    
    public ShareSnapshotValue setWriteTimestamp(long v) {
        this.writeTimestamp = v;
        return this;
    }
    
    public ShareSnapshotValue setStateBatches(List<StateBatch> v) {
        this.stateBatches = v;
        return this;
    }
    
    public static class StateBatch implements Message {
        long firstOffset;
        long lastOffset;
        byte deliveryState;
        short deliveryCount;
        private List<RawTaggedField> _unknownTaggedFields;
        
        public static final Schema SCHEMA_0 =
            new Schema(
                new Field("first_offset", Type.INT64, "The first offset of this state batch."),
                new Field("last_offset", Type.INT64, "The last offset of this state batch."),
                new Field("delivery_state", Type.INT8, "The delivery state - 0:Available,2:Acked,4:Archived."),
                new Field("delivery_count", Type.INT16, "The delivery count."),
                TaggedFieldsSection.of(
                )
            );
        
        public static final Schema[] SCHEMAS = new Schema[] {
            SCHEMA_0
        };
        
        public static final short LOWEST_SUPPORTED_VERSION = 0;
        public static final short HIGHEST_SUPPORTED_VERSION = 0;
        
        public StateBatch(Readable _readable, short _version) {
            read(_readable, _version);
        }
        
        public StateBatch() {
            this.firstOffset = 0L;
            this.lastOffset = 0L;
            this.deliveryState = (byte) 0;
            this.deliveryCount = (short) 0;
        }
        
        
        @Override
        public short lowestSupportedVersion() {
            return 0;
        }
        
        @Override
        public short highestSupportedVersion() {
            return 0;
        }
        
        @Override
        public final void read(Readable _readable, short _version) {
            if (_version > 0) {
                throw new UnsupportedVersionException("Can't read version " + _version + " of StateBatch");
            }
            this.firstOffset = _readable.readLong();
            this.lastOffset = _readable.readLong();
            this.deliveryState = _readable.readByte();
            this.deliveryCount = _readable.readShort();
            this._unknownTaggedFields = null;
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
        
        @Override
        public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            _writable.writeLong(firstOffset);
            _writable.writeLong(lastOffset);
            _writable.writeByte(deliveryState);
            _writable.writeShort(deliveryCount);
            RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
            _numTaggedFields += _rawWriter.numFields();
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        }
        
        @Override
        public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            if (_version > 0) {
                throw new UnsupportedVersionException("Can't size version " + _version + " of StateBatch");
            }
            _size.addBytes(8);
            _size.addBytes(8);
            _size.addBytes(1);
            _size.addBytes(2);
            if (_unknownTaggedFields != null) {
                _numTaggedFields += _unknownTaggedFields.size();
                for (RawTaggedField _field : _unknownTaggedFields) {
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                    _size.addBytes(_field.size());
                }
            }
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        }
        
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof StateBatch)) return false;
            StateBatch other = (StateBatch) obj;
            if (firstOffset != other.firstOffset) return false;
            if (lastOffset != other.lastOffset) return false;
            if (deliveryState != other.deliveryState) return false;
            if (deliveryCount != other.deliveryCount) return false;
            return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
        }
        
        @Override
        public int hashCode() {
            int hashCode = 0;
            hashCode = 31 * hashCode + ((int) (firstOffset >> 32) ^ (int) firstOffset);
            hashCode = 31 * hashCode + ((int) (lastOffset >> 32) ^ (int) lastOffset);
            hashCode = 31 * hashCode + deliveryState;
            hashCode = 31 * hashCode + deliveryCount;
            return hashCode;
        }
        
        @Override
        public StateBatch duplicate() {
            StateBatch _duplicate = new StateBatch();
            _duplicate.firstOffset = firstOffset;
            _duplicate.lastOffset = lastOffset;
            _duplicate.deliveryState = deliveryState;
            _duplicate.deliveryCount = deliveryCount;
            return _duplicate;
        }
        
        @Override
        public String toString() {
            return "StateBatch("
                + "firstOffset=" + firstOffset
                + ", lastOffset=" + lastOffset
                + ", deliveryState=" + deliveryState
                + ", deliveryCount=" + deliveryCount
                + ")";
        }
        
        public long firstOffset() {
            return this.firstOffset;
        }
        
        public long lastOffset() {
            return this.lastOffset;
        }
        
        public byte deliveryState() {
            return this.deliveryState;
        }
        
        public short deliveryCount() {
            return this.deliveryCount;
        }
        
        @Override
        public List<RawTaggedField> unknownTaggedFields() {
            if (_unknownTaggedFields == null) {
                _unknownTaggedFields = new ArrayList<>(0);
            }
            return _unknownTaggedFields;
        }
        
        public StateBatch setFirstOffset(long v) {
            this.firstOffset = v;
            return this;
        }
        
        public StateBatch setLastOffset(long v) {
            this.lastOffset = v;
            return this;
        }
        
        public StateBatch setDeliveryState(byte v) {
            this.deliveryState = v;
            return this;
        }
        
        public StateBatch setDeliveryCount(short v) {
            this.deliveryCount = v;
            return this;
        }
    }
}
