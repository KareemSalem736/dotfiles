/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.share.generated;

import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.protocol.ApiMessage;

public enum CoordinatorRecordType {
    SHARE_SNAPSHOT("ShareSnapshot", (short) 0, (short) 0, (short) 0),
    SHARE_UPDATE("ShareUpdate", (short) 1, (short) 0, (short) 0);
    
    private final String name;
    private final short id;
    private final short lowestSupportedVersion;
    private final short highestSupportedVersion;
    
    CoordinatorRecordType(String name, short id, short lowestSupportedVersion, short highestSupportedVersion) {
        this.name = name;
        this.id = id;
        this.lowestSupportedVersion = lowestSupportedVersion;
        this.highestSupportedVersion = highestSupportedVersion;
    }
    
    public static CoordinatorRecordType fromId(short id) {
        switch (id) {
            case 0:
                return SHARE_SNAPSHOT;
            case 1:
                return SHARE_UPDATE;
            default:
                throw new UnsupportedVersionException("Unknown record id " + id);
        }
    }
    
    public ApiMessage newRecordKey() {
        switch (id) {
            case 0:
                return new ShareSnapshotKey();
            case 1:
                return new ShareUpdateKey();
            default:
                throw new UnsupportedVersionException("Unknown record id " + id);
        }
    }
    
    public ApiMessage newRecordValue() {
        switch (id) {
            case 0:
                return new ShareSnapshotValue();
            case 1:
                return new ShareUpdateValue();
            default:
                throw new UnsupportedVersionException("Unknown record id " + id);
        }
    }
    
    public short id() {
        return this.id;
    }
    
    public short lowestSupportedVersion() {
        return this.lowestSupportedVersion;
    }
    
    public short highestSupportedVersion() {
        return this.highestSupportedVersion;
    }
    
    @Override
    public String toString() {
        return this.name();
    }
}
