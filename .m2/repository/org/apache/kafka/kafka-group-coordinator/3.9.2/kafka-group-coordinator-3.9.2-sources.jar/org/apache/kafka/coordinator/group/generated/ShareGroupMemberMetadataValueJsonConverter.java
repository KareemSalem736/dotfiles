/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.util.ArrayList;

import static org.apache.kafka.coordinator.group.generated.ShareGroupMemberMetadataValue.*;

public class ShareGroupMemberMetadataValueJsonConverter {
    public static ShareGroupMemberMetadataValue read(JsonNode _node, short _version) {
        ShareGroupMemberMetadataValue _object = new ShareGroupMemberMetadataValue();
        JsonNode _rackIdNode = _node.get("rackId");
        if (_rackIdNode == null) {
            throw new RuntimeException("ShareGroupMemberMetadataValue: unable to locate field 'rackId', which is mandatory in version " + _version);
        } else {
            if (_rackIdNode.isNull()) {
                _object.rackId = null;
            } else {
                if (!_rackIdNode.isTextual()) {
                    throw new RuntimeException("ShareGroupMemberMetadataValue expected a string type, but got " + _node.getNodeType());
                }
                _object.rackId = _rackIdNode.asText();
            }
        }
        JsonNode _clientIdNode = _node.get("clientId");
        if (_clientIdNode == null) {
            throw new RuntimeException("ShareGroupMemberMetadataValue: unable to locate field 'clientId', which is mandatory in version " + _version);
        } else {
            if (!_clientIdNode.isTextual()) {
                throw new RuntimeException("ShareGroupMemberMetadataValue expected a string type, but got " + _node.getNodeType());
            }
            _object.clientId = _clientIdNode.asText();
        }
        JsonNode _clientHostNode = _node.get("clientHost");
        if (_clientHostNode == null) {
            throw new RuntimeException("ShareGroupMemberMetadataValue: unable to locate field 'clientHost', which is mandatory in version " + _version);
        } else {
            if (!_clientHostNode.isTextual()) {
                throw new RuntimeException("ShareGroupMemberMetadataValue expected a string type, but got " + _node.getNodeType());
            }
            _object.clientHost = _clientHostNode.asText();
        }
        JsonNode _subscribedTopicNamesNode = _node.get("subscribedTopicNames");
        if (_subscribedTopicNamesNode == null) {
            throw new RuntimeException("ShareGroupMemberMetadataValue: unable to locate field 'subscribedTopicNames', which is mandatory in version " + _version);
        } else {
            if (!_subscribedTopicNamesNode.isArray()) {
                throw new RuntimeException("ShareGroupMemberMetadataValue expected a JSON array, but got " + _node.getNodeType());
            }
            ArrayList<String> _collection = new ArrayList<String>(_subscribedTopicNamesNode.size());
            _object.subscribedTopicNames = _collection;
            for (JsonNode _element : _subscribedTopicNamesNode) {
                if (!_element.isTextual()) {
                    throw new RuntimeException("ShareGroupMemberMetadataValue element expected a string type, but got " + _node.getNodeType());
                }
                _collection.add(_element.asText());
            }
        }
        return _object;
    }
    public static JsonNode write(ShareGroupMemberMetadataValue _object, short _version, boolean _serializeRecords) {
        ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
        if (_object.rackId == null) {
            _node.set("rackId", NullNode.instance);
        } else {
            _node.set("rackId", new TextNode(_object.rackId));
        }
        _node.set("clientId", new TextNode(_object.clientId));
        _node.set("clientHost", new TextNode(_object.clientHost));
        ArrayNode _subscribedTopicNamesArray = new ArrayNode(JsonNodeFactory.instance);
        for (String _element : _object.subscribedTopicNames) {
            _subscribedTopicNamesArray.add(new TextNode(_element));
        }
        _node.set("subscribedTopicNames", _subscribedTopicNamesArray);
        return _node;
    }
    public static JsonNode write(ShareGroupMemberMetadataValue _object, short _version) {
        return write(_object, _version, true);
    }
}
