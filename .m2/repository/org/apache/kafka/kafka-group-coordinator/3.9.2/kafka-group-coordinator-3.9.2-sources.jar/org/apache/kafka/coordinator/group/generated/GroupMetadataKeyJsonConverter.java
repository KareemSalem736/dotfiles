/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

import static org.apache.kafka.coordinator.group.generated.GroupMetadataKey.*;

public class GroupMetadataKeyJsonConverter {
    public static GroupMetadataKey read(JsonNode _node, short _version) {
        GroupMetadataKey _object = new GroupMetadataKey();
        JsonNode _groupNode = _node.get("group");
        if (_groupNode == null) {
            throw new RuntimeException("GroupMetadataKey: unable to locate field 'group', which is mandatory in version " + _version);
        } else {
            if (!_groupNode.isTextual()) {
                throw new RuntimeException("GroupMetadataKey expected a string type, but got " + _node.getNodeType());
            }
            _object.group = _groupNode.asText();
        }
        return _object;
    }
    public static JsonNode write(GroupMetadataKey _object, short _version, boolean _serializeRecords) {
        ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
        _node.set("group", new TextNode(_object.group));
        return _node;
    }
    public static JsonNode write(GroupMetadataKey _object, short _version) {
        return write(_object, _version, true);
    }
}
