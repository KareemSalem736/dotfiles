/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.apache.kafka.common.protocol.ApiMessage;
import org.apache.kafka.common.protocol.Message;
import org.apache.kafka.common.protocol.MessageSizeAccumulator;
import org.apache.kafka.common.protocol.MessageUtil;
import org.apache.kafka.common.protocol.ObjectSerializationCache;
import org.apache.kafka.common.protocol.Readable;
import org.apache.kafka.common.protocol.Writable;
import org.apache.kafka.common.protocol.types.CompactArrayOf;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.protocol.types.RawTaggedField;
import org.apache.kafka.common.protocol.types.RawTaggedFieldWriter;
import org.apache.kafka.common.protocol.types.Schema;
import org.apache.kafka.common.protocol.types.Type;
import org.apache.kafka.common.utils.ByteUtils;

import static org.apache.kafka.common.protocol.types.Field.TaggedFieldsSection;


public class StreamsGroupMemberMetadataValue implements ApiMessage {
    String instanceId;
    String rackId;
    String clientId;
    String clientHost;
    int rebalanceTimeoutMs;
    int topologyEpoch;
    String processId;
    Endpoint userEndpoint;
    List<KeyValue> clientTags;
    private List<RawTaggedField> _unknownTaggedFields;
    
    public static final Schema SCHEMA_0 =
        new Schema(
            new Field("instance_id", Type.COMPACT_NULLABLE_STRING, "The (optional) instance ID for static membership."),
            new Field("rack_id", Type.COMPACT_NULLABLE_STRING, "The (optional) rack ID."),
            new Field("client_id", Type.COMPACT_STRING, "The client ID."),
            new Field("client_host", Type.COMPACT_STRING, "The client host."),
            new Field("rebalance_timeout_ms", Type.INT32, "The rebalance timeout."),
            new Field("topology_epoch", Type.INT32, "The epoch of the topology."),
            new Field("process_id", Type.COMPACT_STRING, "Identity of the streams instance that may have multiple consumers."),
            new Field("user_endpoint", Endpoint.SCHEMA_0, "User-defined endpoint for running interactive queries on this instance."),
            new Field("client_tags", new CompactArrayOf(KeyValue.SCHEMA_0), "Used for rack-aware assignment algorithm."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema[] SCHEMAS = new Schema[] {
        SCHEMA_0
    };
    
    public static final short LOWEST_SUPPORTED_VERSION = 0;
    public static final short HIGHEST_SUPPORTED_VERSION = 0;
    
    public StreamsGroupMemberMetadataValue(Readable _readable, short _version) {
        read(_readable, _version);
    }
    
    public StreamsGroupMemberMetadataValue() {
        this.instanceId = "";
        this.rackId = "";
        this.clientId = "";
        this.clientHost = "";
        this.rebalanceTimeoutMs = -1;
        this.topologyEpoch = 0;
        this.processId = "";
        this.userEndpoint = null;
        this.clientTags = new ArrayList<KeyValue>(0);
    }
    
    @Override
    public short apiKey() {
        return 19;
    }
    
    @Override
    public short lowestSupportedVersion() {
        return 0;
    }
    
    @Override
    public short highestSupportedVersion() {
        return 0;
    }
    
    @Override
    public final void read(Readable _readable, short _version) {
        {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                this.instanceId = null;
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field instanceId had invalid length " + length);
            } else {
                this.instanceId = _readable.readString(length);
            }
        }
        {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                this.rackId = null;
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field rackId had invalid length " + length);
            } else {
                this.rackId = _readable.readString(length);
            }
        }
        {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                throw new RuntimeException("non-nullable field clientId was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field clientId had invalid length " + length);
            } else {
                this.clientId = _readable.readString(length);
            }
        }
        {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                throw new RuntimeException("non-nullable field clientHost was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field clientHost had invalid length " + length);
            } else {
                this.clientHost = _readable.readString(length);
            }
        }
        this.rebalanceTimeoutMs = _readable.readInt();
        this.topologyEpoch = _readable.readInt();
        {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                throw new RuntimeException("non-nullable field processId was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field processId had invalid length " + length);
            } else {
                this.processId = _readable.readString(length);
            }
        }
        {
            if (_readable.readByte() < 0) {
                this.userEndpoint = null;
            } else {
                this.userEndpoint = new Endpoint(_readable, _version);
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field clientTags was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<KeyValue> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new KeyValue(_readable, _version));
                }
                this.clientTags = newCollection;
            }
        }
        this._unknownTaggedFields = null;
        int _numTaggedFields = _readable.readUnsignedVarint();
        for (int _i = 0; _i < _numTaggedFields; _i++) {
            int _tag = _readable.readUnsignedVarint();
            int _size = _readable.readUnsignedVarint();
            switch (_tag) {
                default:
                    this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                    break;
            }
        }
    }
    
    @Override
    public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        if (instanceId == null) {
            _writable.writeUnsignedVarint(0);
        } else {
            byte[] _stringBytes = _cache.getSerializedValue(instanceId);
            _writable.writeUnsignedVarint(_stringBytes.length + 1);
            _writable.writeByteArray(_stringBytes);
        }
        if (rackId == null) {
            _writable.writeUnsignedVarint(0);
        } else {
            byte[] _stringBytes = _cache.getSerializedValue(rackId);
            _writable.writeUnsignedVarint(_stringBytes.length + 1);
            _writable.writeByteArray(_stringBytes);
        }
        {
            byte[] _stringBytes = _cache.getSerializedValue(clientId);
            _writable.writeUnsignedVarint(_stringBytes.length + 1);
            _writable.writeByteArray(_stringBytes);
        }
        {
            byte[] _stringBytes = _cache.getSerializedValue(clientHost);
            _writable.writeUnsignedVarint(_stringBytes.length + 1);
            _writable.writeByteArray(_stringBytes);
        }
        _writable.writeInt(rebalanceTimeoutMs);
        _writable.writeInt(topologyEpoch);
        {
            byte[] _stringBytes = _cache.getSerializedValue(processId);
            _writable.writeUnsignedVarint(_stringBytes.length + 1);
            _writable.writeByteArray(_stringBytes);
        }
        if (userEndpoint == null) {
            _writable.writeByte((byte) -1);
        } else {
            _writable.writeByte((byte) 1);
            userEndpoint.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(clientTags.size() + 1);
        for (KeyValue clientTagsElement : clientTags) {
            clientTagsElement.write(_writable, _cache, _version);
        }
        RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
        _numTaggedFields += _rawWriter.numFields();
        _writable.writeUnsignedVarint(_numTaggedFields);
        _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
    }
    
    @Override
    public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        if (instanceId == null) {
            _size.addBytes(1);
        } else {
            byte[] _stringBytes = instanceId.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'instanceId' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(instanceId, _stringBytes);
            _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
        }
        if (rackId == null) {
            _size.addBytes(1);
        } else {
            byte[] _stringBytes = rackId.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'rackId' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(rackId, _stringBytes);
            _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
        }
        {
            byte[] _stringBytes = clientId.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'clientId' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(clientId, _stringBytes);
            _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
        }
        {
            byte[] _stringBytes = clientHost.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'clientHost' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(clientHost, _stringBytes);
            _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
        }
        _size.addBytes(4);
        _size.addBytes(4);
        {
            byte[] _stringBytes = processId.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'processId' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(processId, _stringBytes);
            _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
        }
        if (userEndpoint == null) {
            _size.addBytes(1);
        } else {
            _size.addBytes(1);
            this.userEndpoint.addSize(_size, _cache, _version);
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(clientTags.size() + 1));
            for (KeyValue clientTagsElement : clientTags) {
                clientTagsElement.addSize(_size, _cache, _version);
            }
        }
        if (_unknownTaggedFields != null) {
            _numTaggedFields += _unknownTaggedFields.size();
            for (RawTaggedField _field : _unknownTaggedFields) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                _size.addBytes(_field.size());
            }
        }
        _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof StreamsGroupMemberMetadataValue)) return false;
        StreamsGroupMemberMetadataValue other = (StreamsGroupMemberMetadataValue) obj;
        if (this.instanceId == null) {
            if (other.instanceId != null) return false;
        } else {
            if (!this.instanceId.equals(other.instanceId)) return false;
        }
        if (this.rackId == null) {
            if (other.rackId != null) return false;
        } else {
            if (!this.rackId.equals(other.rackId)) return false;
        }
        if (this.clientId == null) {
            if (other.clientId != null) return false;
        } else {
            if (!this.clientId.equals(other.clientId)) return false;
        }
        if (this.clientHost == null) {
            if (other.clientHost != null) return false;
        } else {
            if (!this.clientHost.equals(other.clientHost)) return false;
        }
        if (rebalanceTimeoutMs != other.rebalanceTimeoutMs) return false;
        if (topologyEpoch != other.topologyEpoch) return false;
        if (this.processId == null) {
            if (other.processId != null) return false;
        } else {
            if (!this.processId.equals(other.processId)) return false;
        }
        if (this.userEndpoint == null) {
            if (other.userEndpoint != null) return false;
        } else {
            if (!this.userEndpoint.equals(other.userEndpoint)) return false;
        }
        if (this.clientTags == null) {
            if (other.clientTags != null) return false;
        } else {
            if (!this.clientTags.equals(other.clientTags)) return false;
        }
        return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
    }
    
    @Override
    public int hashCode() {
        int hashCode = 0;
        hashCode = 31 * hashCode + (instanceId == null ? 0 : instanceId.hashCode());
        hashCode = 31 * hashCode + (rackId == null ? 0 : rackId.hashCode());
        hashCode = 31 * hashCode + (clientId == null ? 0 : clientId.hashCode());
        hashCode = 31 * hashCode + (clientHost == null ? 0 : clientHost.hashCode());
        hashCode = 31 * hashCode + rebalanceTimeoutMs;
        hashCode = 31 * hashCode + topologyEpoch;
        hashCode = 31 * hashCode + (processId == null ? 0 : processId.hashCode());
        hashCode = 31 * hashCode + (userEndpoint == null ? 0 : userEndpoint.hashCode());
        hashCode = 31 * hashCode + (clientTags == null ? 0 : clientTags.hashCode());
        return hashCode;
    }
    
    @Override
    public StreamsGroupMemberMetadataValue duplicate() {
        StreamsGroupMemberMetadataValue _duplicate = new StreamsGroupMemberMetadataValue();
        if (instanceId == null) {
            _duplicate.instanceId = null;
        } else {
            _duplicate.instanceId = instanceId;
        }
        if (rackId == null) {
            _duplicate.rackId = null;
        } else {
            _duplicate.rackId = rackId;
        }
        _duplicate.clientId = clientId;
        _duplicate.clientHost = clientHost;
        _duplicate.rebalanceTimeoutMs = rebalanceTimeoutMs;
        _duplicate.topologyEpoch = topologyEpoch;
        _duplicate.processId = processId;
        if (userEndpoint == null) {
            _duplicate.userEndpoint = null;
        } else {
            _duplicate.userEndpoint = userEndpoint.duplicate();
        }
        ArrayList<KeyValue> newClientTags = new ArrayList<KeyValue>(clientTags.size());
        for (KeyValue _element : clientTags) {
            newClientTags.add(_element.duplicate());
        }
        _duplicate.clientTags = newClientTags;
        return _duplicate;
    }
    
    @Override
    public String toString() {
        return "StreamsGroupMemberMetadataValue("
            + "instanceId=" + ((instanceId == null) ? "null" : "'" + instanceId.toString() + "'")
            + ", rackId=" + ((rackId == null) ? "null" : "'" + rackId.toString() + "'")
            + ", clientId=" + ((clientId == null) ? "null" : "'" + clientId.toString() + "'")
            + ", clientHost=" + ((clientHost == null) ? "null" : "'" + clientHost.toString() + "'")
            + ", rebalanceTimeoutMs=" + rebalanceTimeoutMs
            + ", topologyEpoch=" + topologyEpoch
            + ", processId=" + ((processId == null) ? "null" : "'" + processId.toString() + "'")
            + ", userEndpoint=" + ((userEndpoint == null) ? "null" : userEndpoint.toString())
            + ", clientTags=" + MessageUtil.deepToString(clientTags.iterator())
            + ")";
    }
    
    public String instanceId() {
        return this.instanceId;
    }
    
    public String rackId() {
        return this.rackId;
    }
    
    public String clientId() {
        return this.clientId;
    }
    
    public String clientHost() {
        return this.clientHost;
    }
    
    public int rebalanceTimeoutMs() {
        return this.rebalanceTimeoutMs;
    }
    
    public int topologyEpoch() {
        return this.topologyEpoch;
    }
    
    public String processId() {
        return this.processId;
    }
    
    public Endpoint userEndpoint() {
        return this.userEndpoint;
    }
    
    public List<KeyValue> clientTags() {
        return this.clientTags;
    }
    
    @Override
    public List<RawTaggedField> unknownTaggedFields() {
        if (_unknownTaggedFields == null) {
            _unknownTaggedFields = new ArrayList<>(0);
        }
        return _unknownTaggedFields;
    }
    
    public StreamsGroupMemberMetadataValue setInstanceId(String v) {
        this.instanceId = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setRackId(String v) {
        this.rackId = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setClientId(String v) {
        this.clientId = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setClientHost(String v) {
        this.clientHost = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setRebalanceTimeoutMs(int v) {
        this.rebalanceTimeoutMs = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setTopologyEpoch(int v) {
        this.topologyEpoch = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setProcessId(String v) {
        this.processId = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setUserEndpoint(Endpoint v) {
        this.userEndpoint = v;
        return this;
    }
    
    public StreamsGroupMemberMetadataValue setClientTags(List<KeyValue> v) {
        this.clientTags = v;
        return this;
    }
    
    public static class Endpoint implements Message {
        String host;
        int port;
        private List<RawTaggedField> _unknownTaggedFields;
        
        public static final Schema SCHEMA_0 =
            new Schema(
                new Field("host", Type.COMPACT_STRING, "The host of the endpoint."),
                new Field("port", Type.UINT16, "The port of the endpoint."),
                TaggedFieldsSection.of(
                )
            );
        
        public static final Schema[] SCHEMAS = new Schema[] {
            SCHEMA_0
        };
        
        public static final short LOWEST_SUPPORTED_VERSION = 0;
        public static final short HIGHEST_SUPPORTED_VERSION = 0;
        
        public Endpoint(Readable _readable, short _version) {
            read(_readable, _version);
        }
        
        public Endpoint() {
            this.host = "";
            this.port = 0;
        }
        
        
        @Override
        public short lowestSupportedVersion() {
            return 0;
        }
        
        @Override
        public short highestSupportedVersion() {
            return 32767;
        }
        
        @Override
        public final void read(Readable _readable, short _version) {
            {
                int length;
                length = _readable.readUnsignedVarint() - 1;
                if (length < 0) {
                    throw new RuntimeException("non-nullable field host was serialized as null");
                } else if (length > 0x7fff) {
                    throw new RuntimeException("string field host had invalid length " + length);
                } else {
                    this.host = _readable.readString(length);
                }
            }
            this.port = _readable.readUnsignedShort();
            this._unknownTaggedFields = null;
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
        
        @Override
        public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = _cache.getSerializedValue(host);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
            _writable.writeUnsignedShort(port);
            RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
            _numTaggedFields += _rawWriter.numFields();
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        }
        
        @Override
        public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = host.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'host' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(host, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
            _size.addBytes(2);
            if (_unknownTaggedFields != null) {
                _numTaggedFields += _unknownTaggedFields.size();
                for (RawTaggedField _field : _unknownTaggedFields) {
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                    _size.addBytes(_field.size());
                }
            }
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        }
        
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof Endpoint)) return false;
            Endpoint other = (Endpoint) obj;
            if (this.host == null) {
                if (other.host != null) return false;
            } else {
                if (!this.host.equals(other.host)) return false;
            }
            if (port != other.port) return false;
            return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
        }
        
        @Override
        public int hashCode() {
            int hashCode = 0;
            hashCode = 31 * hashCode + (host == null ? 0 : host.hashCode());
            hashCode = 31 * hashCode + port;
            return hashCode;
        }
        
        @Override
        public Endpoint duplicate() {
            Endpoint _duplicate = new Endpoint();
            _duplicate.host = host;
            _duplicate.port = port;
            return _duplicate;
        }
        
        @Override
        public String toString() {
            return "Endpoint("
                + "host=" + ((host == null) ? "null" : "'" + host.toString() + "'")
                + ", port=" + port
                + ")";
        }
        
        public String host() {
            return this.host;
        }
        
        public int port() {
            return this.port;
        }
        
        @Override
        public List<RawTaggedField> unknownTaggedFields() {
            if (_unknownTaggedFields == null) {
                _unknownTaggedFields = new ArrayList<>(0);
            }
            return _unknownTaggedFields;
        }
        
        public Endpoint setHost(String v) {
            this.host = v;
            return this;
        }
        
        public Endpoint setPort(int v) {
            if (v < 0 || v > 65535) {
                throw new RuntimeException("Invalid value " + v + " for unsigned short field.");
            }
            this.port = v;
            return this;
        }
    }
    
    public static class KeyValue implements Message {
        String key;
        String value;
        private List<RawTaggedField> _unknownTaggedFields;
        
        public static final Schema SCHEMA_0 =
            new Schema(
                new Field("key", Type.COMPACT_STRING, "The key of the config."),
                new Field("value", Type.COMPACT_STRING, "the value of the config."),
                TaggedFieldsSection.of(
                )
            );
        
        public static final Schema[] SCHEMAS = new Schema[] {
            SCHEMA_0
        };
        
        public static final short LOWEST_SUPPORTED_VERSION = 0;
        public static final short HIGHEST_SUPPORTED_VERSION = 0;
        
        public KeyValue(Readable _readable, short _version) {
            read(_readable, _version);
        }
        
        public KeyValue() {
            this.key = "";
            this.value = "";
        }
        
        
        @Override
        public short lowestSupportedVersion() {
            return 0;
        }
        
        @Override
        public short highestSupportedVersion() {
            return 32767;
        }
        
        @Override
        public final void read(Readable _readable, short _version) {
            {
                int length;
                length = _readable.readUnsignedVarint() - 1;
                if (length < 0) {
                    throw new RuntimeException("non-nullable field key was serialized as null");
                } else if (length > 0x7fff) {
                    throw new RuntimeException("string field key had invalid length " + length);
                } else {
                    this.key = _readable.readString(length);
                }
            }
            {
                int length;
                length = _readable.readUnsignedVarint() - 1;
                if (length < 0) {
                    throw new RuntimeException("non-nullable field value was serialized as null");
                } else if (length > 0x7fff) {
                    throw new RuntimeException("string field value had invalid length " + length);
                } else {
                    this.value = _readable.readString(length);
                }
            }
            this._unknownTaggedFields = null;
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
        
        @Override
        public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = _cache.getSerializedValue(key);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
            {
                byte[] _stringBytes = _cache.getSerializedValue(value);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
            RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
            _numTaggedFields += _rawWriter.numFields();
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        }
        
        @Override
        public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = key.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'key' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(key, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
            {
                byte[] _stringBytes = value.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'value' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(value, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
            if (_unknownTaggedFields != null) {
                _numTaggedFields += _unknownTaggedFields.size();
                for (RawTaggedField _field : _unknownTaggedFields) {
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                    _size.addBytes(_field.size());
                }
            }
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        }
        
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof KeyValue)) return false;
            KeyValue other = (KeyValue) obj;
            if (this.key == null) {
                if (other.key != null) return false;
            } else {
                if (!this.key.equals(other.key)) return false;
            }
            if (this.value == null) {
                if (other.value != null) return false;
            } else {
                if (!this.value.equals(other.value)) return false;
            }
            return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
        }
        
        @Override
        public int hashCode() {
            int hashCode = 0;
            hashCode = 31 * hashCode + (key == null ? 0 : key.hashCode());
            hashCode = 31 * hashCode + (value == null ? 0 : value.hashCode());
            return hashCode;
        }
        
        @Override
        public KeyValue duplicate() {
            KeyValue _duplicate = new KeyValue();
            _duplicate.key = key;
            _duplicate.value = value;
            return _duplicate;
        }
        
        @Override
        public String toString() {
            return "KeyValue("
                + "key=" + ((key == null) ? "null" : "'" + key.toString() + "'")
                + ", value=" + ((value == null) ? "null" : "'" + value.toString() + "'")
                + ")";
        }
        
        public String key() {
            return this.key;
        }
        
        public String value() {
            return this.value;
        }
        
        @Override
        public List<RawTaggedField> unknownTaggedFields() {
            if (_unknownTaggedFields == null) {
                _unknownTaggedFields = new ArrayList<>(0);
            }
            return _unknownTaggedFields;
        }
        
        public KeyValue setKey(String v) {
            this.key = v;
            return this;
        }
        
        public KeyValue setValue(String v) {
            this.value = v;
            return this;
        }
    }
}
