/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.common.protocol.MessageUtil;

import static org.apache.kafka.coordinator.group.generated.ShareGroupMetadataValue.*;

public class ShareGroupMetadataValueJsonConverter {
    public static ShareGroupMetadataValue read(JsonNode _node, short _version) {
        ShareGroupMetadataValue _object = new ShareGroupMetadataValue();
        JsonNode _epochNode = _node.get("epoch");
        if (_epochNode == null) {
            throw new RuntimeException("ShareGroupMetadataValue: unable to locate field 'epoch', which is mandatory in version " + _version);
        } else {
            _object.epoch = MessageUtil.jsonNodeToInt(_epochNode, "ShareGroupMetadataValue");
        }
        JsonNode _metadataHashNode = _node.get("metadataHash");
        if (_metadataHashNode == null) {
            throw new RuntimeException("ShareGroupMetadataValue: unable to locate field 'metadataHash', which is mandatory in version " + _version);
        } else {
            _object.metadataHash = MessageUtil.jsonNodeToLong(_metadataHashNode, "ShareGroupMetadataValue");
        }
        return _object;
    }
    public static JsonNode write(ShareGroupMetadataValue _object, short _version, boolean _serializeRecords) {
        ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
        _node.set("epoch", new IntNode(_object.epoch));
        _node.set("metadataHash", new LongNode(_object.metadataHash));
        return _node;
    }
    public static JsonNode write(ShareGroupMetadataValue _object, short _version) {
        return write(_object, _version, true);
    }
}
