/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import org.apache.kafka.common.protocol.MessageUtil;

import static org.apache.kafka.coordinator.group.generated.LegacyOffsetCommitValue.*;

public class LegacyOffsetCommitValueJsonConverter {
    public static LegacyOffsetCommitValue read(JsonNode _node, short _version) {
        LegacyOffsetCommitValue _object = new LegacyOffsetCommitValue();
        JsonNode _offsetNode = _node.get("offset");
        if (_offsetNode == null) {
            throw new RuntimeException("LegacyOffsetCommitValue: unable to locate field 'offset', which is mandatory in version " + _version);
        } else {
            _object.offset = MessageUtil.jsonNodeToLong(_offsetNode, "LegacyOffsetCommitValue");
        }
        JsonNode _metadataNode = _node.get("metadata");
        if (_metadataNode == null) {
            throw new RuntimeException("LegacyOffsetCommitValue: unable to locate field 'metadata', which is mandatory in version " + _version);
        } else {
            if (!_metadataNode.isTextual()) {
                throw new RuntimeException("LegacyOffsetCommitValue expected a string type, but got " + _node.getNodeType());
            }
            _object.metadata = _metadataNode.asText();
        }
        JsonNode _commitTimestampNode = _node.get("commitTimestamp");
        if (_commitTimestampNode == null) {
            throw new RuntimeException("LegacyOffsetCommitValue: unable to locate field 'commitTimestamp', which is mandatory in version " + _version);
        } else {
            _object.commitTimestamp = MessageUtil.jsonNodeToLong(_commitTimestampNode, "LegacyOffsetCommitValue");
        }
        return _object;
    }
    public static JsonNode write(LegacyOffsetCommitValue _object, short _version, boolean _serializeRecords) {
        ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
        _node.set("offset", new LongNode(_object.offset));
        _node.set("metadata", new TextNode(_object.metadata));
        _node.set("commitTimestamp", new LongNode(_object.commitTimestamp));
        return _node;
    }
    public static JsonNode write(LegacyOffsetCommitValue _object, short _version) {
        return write(_object, _version, true);
    }
}
