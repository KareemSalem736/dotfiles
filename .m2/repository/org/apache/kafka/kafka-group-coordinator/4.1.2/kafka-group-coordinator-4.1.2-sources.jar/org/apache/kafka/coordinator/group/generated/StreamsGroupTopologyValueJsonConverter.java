/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ShortNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.util.ArrayList;
import org.apache.kafka.common.protocol.MessageUtil;

import static org.apache.kafka.coordinator.group.generated.StreamsGroupTopologyValue.*;

public class StreamsGroupTopologyValueJsonConverter {
    public static StreamsGroupTopologyValue read(JsonNode _node, short _version) {
        StreamsGroupTopologyValue _object = new StreamsGroupTopologyValue();
        JsonNode _epochNode = _node.get("epoch");
        if (_epochNode == null) {
            throw new RuntimeException("StreamsGroupTopologyValue: unable to locate field 'epoch', which is mandatory in version " + _version);
        } else {
            _object.epoch = MessageUtil.jsonNodeToInt(_epochNode, "StreamsGroupTopologyValue");
        }
        JsonNode _subtopologiesNode = _node.get("subtopologies");
        if (_subtopologiesNode == null) {
            throw new RuntimeException("StreamsGroupTopologyValue: unable to locate field 'subtopologies', which is mandatory in version " + _version);
        } else {
            if (!_subtopologiesNode.isArray()) {
                throw new RuntimeException("StreamsGroupTopologyValue expected a JSON array, but got " + _node.getNodeType());
            }
            ArrayList<Subtopology> _collection = new ArrayList<Subtopology>(_subtopologiesNode.size());
            _object.subtopologies = _collection;
            for (JsonNode _element : _subtopologiesNode) {
                _collection.add(SubtopologyJsonConverter.read(_element, _version));
            }
        }
        return _object;
    }
    public static JsonNode write(StreamsGroupTopologyValue _object, short _version, boolean _serializeRecords) {
        ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
        _node.set("epoch", new IntNode(_object.epoch));
        ArrayNode _subtopologiesArray = new ArrayNode(JsonNodeFactory.instance);
        for (Subtopology _element : _object.subtopologies) {
            _subtopologiesArray.add(SubtopologyJsonConverter.write(_element, _version, _serializeRecords));
        }
        _node.set("subtopologies", _subtopologiesArray);
        return _node;
    }
    public static JsonNode write(StreamsGroupTopologyValue _object, short _version) {
        return write(_object, _version, true);
    }
    
    public static class CopartitionGroupJsonConverter {
        public static CopartitionGroup read(JsonNode _node, short _version) {
            CopartitionGroup _object = new CopartitionGroup();
            JsonNode _sourceTopicsNode = _node.get("sourceTopics");
            if (_sourceTopicsNode == null) {
                throw new RuntimeException("CopartitionGroup: unable to locate field 'sourceTopics', which is mandatory in version " + _version);
            } else {
                if (!_sourceTopicsNode.isArray()) {
                    throw new RuntimeException("CopartitionGroup expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<Short> _collection = new ArrayList<Short>(_sourceTopicsNode.size());
                _object.sourceTopics = _collection;
                for (JsonNode _element : _sourceTopicsNode) {
                    _collection.add(MessageUtil.jsonNodeToShort(_element, "CopartitionGroup element"));
                }
            }
            JsonNode _sourceTopicRegexNode = _node.get("sourceTopicRegex");
            if (_sourceTopicRegexNode == null) {
                throw new RuntimeException("CopartitionGroup: unable to locate field 'sourceTopicRegex', which is mandatory in version " + _version);
            } else {
                if (!_sourceTopicRegexNode.isArray()) {
                    throw new RuntimeException("CopartitionGroup expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<Short> _collection = new ArrayList<Short>(_sourceTopicRegexNode.size());
                _object.sourceTopicRegex = _collection;
                for (JsonNode _element : _sourceTopicRegexNode) {
                    _collection.add(MessageUtil.jsonNodeToShort(_element, "CopartitionGroup element"));
                }
            }
            JsonNode _repartitionSourceTopicsNode = _node.get("repartitionSourceTopics");
            if (_repartitionSourceTopicsNode == null) {
                throw new RuntimeException("CopartitionGroup: unable to locate field 'repartitionSourceTopics', which is mandatory in version " + _version);
            } else {
                if (!_repartitionSourceTopicsNode.isArray()) {
                    throw new RuntimeException("CopartitionGroup expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<Short> _collection = new ArrayList<Short>(_repartitionSourceTopicsNode.size());
                _object.repartitionSourceTopics = _collection;
                for (JsonNode _element : _repartitionSourceTopicsNode) {
                    _collection.add(MessageUtil.jsonNodeToShort(_element, "CopartitionGroup element"));
                }
            }
            return _object;
        }
        public static JsonNode write(CopartitionGroup _object, short _version, boolean _serializeRecords) {
            ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
            ArrayNode _sourceTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (Short _element : _object.sourceTopics) {
                _sourceTopicsArray.add(new ShortNode(_element));
            }
            _node.set("sourceTopics", _sourceTopicsArray);
            ArrayNode _sourceTopicRegexArray = new ArrayNode(JsonNodeFactory.instance);
            for (Short _element : _object.sourceTopicRegex) {
                _sourceTopicRegexArray.add(new ShortNode(_element));
            }
            _node.set("sourceTopicRegex", _sourceTopicRegexArray);
            ArrayNode _repartitionSourceTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (Short _element : _object.repartitionSourceTopics) {
                _repartitionSourceTopicsArray.add(new ShortNode(_element));
            }
            _node.set("repartitionSourceTopics", _repartitionSourceTopicsArray);
            return _node;
        }
        public static JsonNode write(CopartitionGroup _object, short _version) {
            return write(_object, _version, true);
        }
    }
    
    public static class SubtopologyJsonConverter {
        public static Subtopology read(JsonNode _node, short _version) {
            Subtopology _object = new Subtopology();
            JsonNode _subtopologyIdNode = _node.get("subtopologyId");
            if (_subtopologyIdNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'subtopologyId', which is mandatory in version " + _version);
            } else {
                if (!_subtopologyIdNode.isTextual()) {
                    throw new RuntimeException("Subtopology expected a string type, but got " + _node.getNodeType());
                }
                _object.subtopologyId = _subtopologyIdNode.asText();
            }
            JsonNode _sourceTopicsNode = _node.get("sourceTopics");
            if (_sourceTopicsNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'sourceTopics', which is mandatory in version " + _version);
            } else {
                if (!_sourceTopicsNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<String> _collection = new ArrayList<String>(_sourceTopicsNode.size());
                _object.sourceTopics = _collection;
                for (JsonNode _element : _sourceTopicsNode) {
                    if (!_element.isTextual()) {
                        throw new RuntimeException("Subtopology element expected a string type, but got " + _node.getNodeType());
                    }
                    _collection.add(_element.asText());
                }
            }
            JsonNode _sourceTopicRegexNode = _node.get("sourceTopicRegex");
            if (_sourceTopicRegexNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'sourceTopicRegex', which is mandatory in version " + _version);
            } else {
                if (!_sourceTopicRegexNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<String> _collection = new ArrayList<String>(_sourceTopicRegexNode.size());
                _object.sourceTopicRegex = _collection;
                for (JsonNode _element : _sourceTopicRegexNode) {
                    if (!_element.isTextual()) {
                        throw new RuntimeException("Subtopology element expected a string type, but got " + _node.getNodeType());
                    }
                    _collection.add(_element.asText());
                }
            }
            JsonNode _stateChangelogTopicsNode = _node.get("stateChangelogTopics");
            if (_stateChangelogTopicsNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'stateChangelogTopics', which is mandatory in version " + _version);
            } else {
                if (!_stateChangelogTopicsNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<TopicInfo> _collection = new ArrayList<TopicInfo>(_stateChangelogTopicsNode.size());
                _object.stateChangelogTopics = _collection;
                for (JsonNode _element : _stateChangelogTopicsNode) {
                    _collection.add(TopicInfoJsonConverter.read(_element, _version));
                }
            }
            JsonNode _repartitionSinkTopicsNode = _node.get("repartitionSinkTopics");
            if (_repartitionSinkTopicsNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'repartitionSinkTopics', which is mandatory in version " + _version);
            } else {
                if (!_repartitionSinkTopicsNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<String> _collection = new ArrayList<String>(_repartitionSinkTopicsNode.size());
                _object.repartitionSinkTopics = _collection;
                for (JsonNode _element : _repartitionSinkTopicsNode) {
                    if (!_element.isTextual()) {
                        throw new RuntimeException("Subtopology element expected a string type, but got " + _node.getNodeType());
                    }
                    _collection.add(_element.asText());
                }
            }
            JsonNode _repartitionSourceTopicsNode = _node.get("repartitionSourceTopics");
            if (_repartitionSourceTopicsNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'repartitionSourceTopics', which is mandatory in version " + _version);
            } else {
                if (!_repartitionSourceTopicsNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<TopicInfo> _collection = new ArrayList<TopicInfo>(_repartitionSourceTopicsNode.size());
                _object.repartitionSourceTopics = _collection;
                for (JsonNode _element : _repartitionSourceTopicsNode) {
                    _collection.add(TopicInfoJsonConverter.read(_element, _version));
                }
            }
            JsonNode _copartitionGroupsNode = _node.get("copartitionGroups");
            if (_copartitionGroupsNode == null) {
                throw new RuntimeException("Subtopology: unable to locate field 'copartitionGroups', which is mandatory in version " + _version);
            } else {
                if (!_copartitionGroupsNode.isArray()) {
                    throw new RuntimeException("Subtopology expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<CopartitionGroup> _collection = new ArrayList<CopartitionGroup>(_copartitionGroupsNode.size());
                _object.copartitionGroups = _collection;
                for (JsonNode _element : _copartitionGroupsNode) {
                    _collection.add(CopartitionGroupJsonConverter.read(_element, _version));
                }
            }
            return _object;
        }
        public static JsonNode write(Subtopology _object, short _version, boolean _serializeRecords) {
            ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
            _node.set("subtopologyId", new TextNode(_object.subtopologyId));
            ArrayNode _sourceTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (String _element : _object.sourceTopics) {
                _sourceTopicsArray.add(new TextNode(_element));
            }
            _node.set("sourceTopics", _sourceTopicsArray);
            ArrayNode _sourceTopicRegexArray = new ArrayNode(JsonNodeFactory.instance);
            for (String _element : _object.sourceTopicRegex) {
                _sourceTopicRegexArray.add(new TextNode(_element));
            }
            _node.set("sourceTopicRegex", _sourceTopicRegexArray);
            ArrayNode _stateChangelogTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (TopicInfo _element : _object.stateChangelogTopics) {
                _stateChangelogTopicsArray.add(TopicInfoJsonConverter.write(_element, _version, _serializeRecords));
            }
            _node.set("stateChangelogTopics", _stateChangelogTopicsArray);
            ArrayNode _repartitionSinkTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (String _element : _object.repartitionSinkTopics) {
                _repartitionSinkTopicsArray.add(new TextNode(_element));
            }
            _node.set("repartitionSinkTopics", _repartitionSinkTopicsArray);
            ArrayNode _repartitionSourceTopicsArray = new ArrayNode(JsonNodeFactory.instance);
            for (TopicInfo _element : _object.repartitionSourceTopics) {
                _repartitionSourceTopicsArray.add(TopicInfoJsonConverter.write(_element, _version, _serializeRecords));
            }
            _node.set("repartitionSourceTopics", _repartitionSourceTopicsArray);
            ArrayNode _copartitionGroupsArray = new ArrayNode(JsonNodeFactory.instance);
            for (CopartitionGroup _element : _object.copartitionGroups) {
                _copartitionGroupsArray.add(CopartitionGroupJsonConverter.write(_element, _version, _serializeRecords));
            }
            _node.set("copartitionGroups", _copartitionGroupsArray);
            return _node;
        }
        public static JsonNode write(Subtopology _object, short _version) {
            return write(_object, _version, true);
        }
    }
    
    public static class TopicConfigJsonConverter {
        public static TopicConfig read(JsonNode _node, short _version) {
            TopicConfig _object = new TopicConfig();
            JsonNode _keyNode = _node.get("key");
            if (_keyNode == null) {
                throw new RuntimeException("TopicConfig: unable to locate field 'key', which is mandatory in version " + _version);
            } else {
                if (!_keyNode.isTextual()) {
                    throw new RuntimeException("TopicConfig expected a string type, but got " + _node.getNodeType());
                }
                _object.key = _keyNode.asText();
            }
            JsonNode _valueNode = _node.get("value");
            if (_valueNode == null) {
                throw new RuntimeException("TopicConfig: unable to locate field 'value', which is mandatory in version " + _version);
            } else {
                if (!_valueNode.isTextual()) {
                    throw new RuntimeException("TopicConfig expected a string type, but got " + _node.getNodeType());
                }
                _object.value = _valueNode.asText();
            }
            return _object;
        }
        public static JsonNode write(TopicConfig _object, short _version, boolean _serializeRecords) {
            ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
            _node.set("key", new TextNode(_object.key));
            _node.set("value", new TextNode(_object.value));
            return _node;
        }
        public static JsonNode write(TopicConfig _object, short _version) {
            return write(_object, _version, true);
        }
    }
    
    public static class TopicInfoJsonConverter {
        public static TopicInfo read(JsonNode _node, short _version) {
            TopicInfo _object = new TopicInfo();
            JsonNode _nameNode = _node.get("name");
            if (_nameNode == null) {
                throw new RuntimeException("TopicInfo: unable to locate field 'name', which is mandatory in version " + _version);
            } else {
                if (!_nameNode.isTextual()) {
                    throw new RuntimeException("TopicInfo expected a string type, but got " + _node.getNodeType());
                }
                _object.name = _nameNode.asText();
            }
            JsonNode _partitionsNode = _node.get("partitions");
            if (_partitionsNode == null) {
                throw new RuntimeException("TopicInfo: unable to locate field 'partitions', which is mandatory in version " + _version);
            } else {
                _object.partitions = MessageUtil.jsonNodeToInt(_partitionsNode, "TopicInfo");
            }
            JsonNode _replicationFactorNode = _node.get("replicationFactor");
            if (_replicationFactorNode == null) {
                throw new RuntimeException("TopicInfo: unable to locate field 'replicationFactor', which is mandatory in version " + _version);
            } else {
                _object.replicationFactor = MessageUtil.jsonNodeToShort(_replicationFactorNode, "TopicInfo");
            }
            JsonNode _topicConfigsNode = _node.get("topicConfigs");
            if (_topicConfigsNode == null) {
                throw new RuntimeException("TopicInfo: unable to locate field 'topicConfigs', which is mandatory in version " + _version);
            } else {
                if (!_topicConfigsNode.isArray()) {
                    throw new RuntimeException("TopicInfo expected a JSON array, but got " + _node.getNodeType());
                }
                ArrayList<TopicConfig> _collection = new ArrayList<TopicConfig>(_topicConfigsNode.size());
                _object.topicConfigs = _collection;
                for (JsonNode _element : _topicConfigsNode) {
                    _collection.add(TopicConfigJsonConverter.read(_element, _version));
                }
            }
            return _object;
        }
        public static JsonNode write(TopicInfo _object, short _version, boolean _serializeRecords) {
            ObjectNode _node = new ObjectNode(JsonNodeFactory.instance);
            _node.set("name", new TextNode(_object.name));
            _node.set("partitions", new IntNode(_object.partitions));
            _node.set("replicationFactor", new ShortNode(_object.replicationFactor));
            ArrayNode _topicConfigsArray = new ArrayNode(JsonNodeFactory.instance);
            for (TopicConfig _element : _object.topicConfigs) {
                _topicConfigsArray.add(TopicConfigJsonConverter.write(_element, _version, _serializeRecords));
            }
            _node.set("topicConfigs", _topicConfigsArray);
            return _node;
        }
        public static JsonNode write(TopicInfo _object, short _version) {
            return write(_object, _version, true);
        }
    }
}
