/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.protocol.ApiMessage;

public class CoordinatorRecordJsonConverters {
    public static JsonNode writeRecordKeyAsJson(ApiMessage key) {
        switch (key.apiKey()) {
            case 0:
                return LegacyOffsetCommitKeyJsonConverter.write((LegacyOffsetCommitKey) key, (short) 0);
            case 1:
                return OffsetCommitKeyJsonConverter.write((OffsetCommitKey) key, (short) 0);
            case 2:
                return GroupMetadataKeyJsonConverter.write((GroupMetadataKey) key, (short) 0);
            case 3:
                return ConsumerGroupMetadataKeyJsonConverter.write((ConsumerGroupMetadataKey) key, (short) 0);
            case 4:
                return ConsumerGroupPartitionMetadataKeyJsonConverter.write((ConsumerGroupPartitionMetadataKey) key, (short) 0);
            case 5:
                return ConsumerGroupMemberMetadataKeyJsonConverter.write((ConsumerGroupMemberMetadataKey) key, (short) 0);
            case 6:
                return ConsumerGroupTargetAssignmentMetadataKeyJsonConverter.write((ConsumerGroupTargetAssignmentMetadataKey) key, (short) 0);
            case 7:
                return ConsumerGroupTargetAssignmentMemberKeyJsonConverter.write((ConsumerGroupTargetAssignmentMemberKey) key, (short) 0);
            case 8:
                return ConsumerGroupCurrentMemberAssignmentKeyJsonConverter.write((ConsumerGroupCurrentMemberAssignmentKey) key, (short) 0);
            case 10:
                return ShareGroupMemberMetadataKeyJsonConverter.write((ShareGroupMemberMetadataKey) key, (short) 0);
            case 11:
                return ShareGroupMetadataKeyJsonConverter.write((ShareGroupMetadataKey) key, (short) 0);
            case 12:
                return ShareGroupTargetAssignmentMetadataKeyJsonConverter.write((ShareGroupTargetAssignmentMetadataKey) key, (short) 0);
            case 13:
                return ShareGroupTargetAssignmentMemberKeyJsonConverter.write((ShareGroupTargetAssignmentMemberKey) key, (short) 0);
            case 14:
                return ShareGroupCurrentMemberAssignmentKeyJsonConverter.write((ShareGroupCurrentMemberAssignmentKey) key, (short) 0);
            case 15:
                return ShareGroupStatePartitionMetadataKeyJsonConverter.write((ShareGroupStatePartitionMetadataKey) key, (short) 0);
            case 16:
                return ConsumerGroupRegularExpressionKeyJsonConverter.write((ConsumerGroupRegularExpressionKey) key, (short) 0);
            case 17:
                return StreamsGroupMetadataKeyJsonConverter.write((StreamsGroupMetadataKey) key, (short) 0);
            case 19:
                return StreamsGroupMemberMetadataKeyJsonConverter.write((StreamsGroupMemberMetadataKey) key, (short) 0);
            case 20:
                return StreamsGroupTargetAssignmentMetadataKeyJsonConverter.write((StreamsGroupTargetAssignmentMetadataKey) key, (short) 0);
            case 21:
                return StreamsGroupTargetAssignmentMemberKeyJsonConverter.write((StreamsGroupTargetAssignmentMemberKey) key, (short) 0);
            case 22:
                return StreamsGroupCurrentMemberAssignmentKeyJsonConverter.write((StreamsGroupCurrentMemberAssignmentKey) key, (short) 0);
            case 23:
                return StreamsGroupTopologyKeyJsonConverter.write((StreamsGroupTopologyKey) key, (short) 0);
            default:
                throw new UnsupportedVersionException("Unknown record id " + key.apiKey());
        }
    }
    
    public static JsonNode writeRecordValueAsJson(ApiMessage value, short version) {
        switch (value.apiKey()) {
            case 0:
                return LegacyOffsetCommitValueJsonConverter.write((LegacyOffsetCommitValue) value, version);
            case 1:
                return OffsetCommitValueJsonConverter.write((OffsetCommitValue) value, version);
            case 2:
                return GroupMetadataValueJsonConverter.write((GroupMetadataValue) value, version);
            case 3:
                return ConsumerGroupMetadataValueJsonConverter.write((ConsumerGroupMetadataValue) value, version);
            case 4:
                return ConsumerGroupPartitionMetadataValueJsonConverter.write((ConsumerGroupPartitionMetadataValue) value, version);
            case 5:
                return ConsumerGroupMemberMetadataValueJsonConverter.write((ConsumerGroupMemberMetadataValue) value, version);
            case 6:
                return ConsumerGroupTargetAssignmentMetadataValueJsonConverter.write((ConsumerGroupTargetAssignmentMetadataValue) value, version);
            case 7:
                return ConsumerGroupTargetAssignmentMemberValueJsonConverter.write((ConsumerGroupTargetAssignmentMemberValue) value, version);
            case 8:
                return ConsumerGroupCurrentMemberAssignmentValueJsonConverter.write((ConsumerGroupCurrentMemberAssignmentValue) value, version);
            case 10:
                return ShareGroupMemberMetadataValueJsonConverter.write((ShareGroupMemberMetadataValue) value, version);
            case 11:
                return ShareGroupMetadataValueJsonConverter.write((ShareGroupMetadataValue) value, version);
            case 12:
                return ShareGroupTargetAssignmentMetadataValueJsonConverter.write((ShareGroupTargetAssignmentMetadataValue) value, version);
            case 13:
                return ShareGroupTargetAssignmentMemberValueJsonConverter.write((ShareGroupTargetAssignmentMemberValue) value, version);
            case 14:
                return ShareGroupCurrentMemberAssignmentValueJsonConverter.write((ShareGroupCurrentMemberAssignmentValue) value, version);
            case 15:
                return ShareGroupStatePartitionMetadataValueJsonConverter.write((ShareGroupStatePartitionMetadataValue) value, version);
            case 16:
                return ConsumerGroupRegularExpressionValueJsonConverter.write((ConsumerGroupRegularExpressionValue) value, version);
            case 17:
                return StreamsGroupMetadataValueJsonConverter.write((StreamsGroupMetadataValue) value, version);
            case 19:
                return StreamsGroupMemberMetadataValueJsonConverter.write((StreamsGroupMemberMetadataValue) value, version);
            case 20:
                return StreamsGroupTargetAssignmentMetadataValueJsonConverter.write((StreamsGroupTargetAssignmentMetadataValue) value, version);
            case 21:
                return StreamsGroupTargetAssignmentMemberValueJsonConverter.write((StreamsGroupTargetAssignmentMemberValue) value, version);
            case 22:
                return StreamsGroupCurrentMemberAssignmentValueJsonConverter.write((StreamsGroupCurrentMemberAssignmentValue) value, version);
            case 23:
                return StreamsGroupTopologyValueJsonConverter.write((StreamsGroupTopologyValue) value, version);
            default:
                throw new UnsupportedVersionException("Unknown record id " + value.apiKey());
        }
    }
    
    public static ApiMessage readRecordKeyFromJson(JsonNode json, short apiKey) {
        switch (apiKey) {
            case 0:
                return LegacyOffsetCommitKeyJsonConverter.read(json, (short) 0);
            case 1:
                return OffsetCommitKeyJsonConverter.read(json, (short) 0);
            case 2:
                return GroupMetadataKeyJsonConverter.read(json, (short) 0);
            case 3:
                return ConsumerGroupMetadataKeyJsonConverter.read(json, (short) 0);
            case 4:
                return ConsumerGroupPartitionMetadataKeyJsonConverter.read(json, (short) 0);
            case 5:
                return ConsumerGroupMemberMetadataKeyJsonConverter.read(json, (short) 0);
            case 6:
                return ConsumerGroupTargetAssignmentMetadataKeyJsonConverter.read(json, (short) 0);
            case 7:
                return ConsumerGroupTargetAssignmentMemberKeyJsonConverter.read(json, (short) 0);
            case 8:
                return ConsumerGroupCurrentMemberAssignmentKeyJsonConverter.read(json, (short) 0);
            case 10:
                return ShareGroupMemberMetadataKeyJsonConverter.read(json, (short) 0);
            case 11:
                return ShareGroupMetadataKeyJsonConverter.read(json, (short) 0);
            case 12:
                return ShareGroupTargetAssignmentMetadataKeyJsonConverter.read(json, (short) 0);
            case 13:
                return ShareGroupTargetAssignmentMemberKeyJsonConverter.read(json, (short) 0);
            case 14:
                return ShareGroupCurrentMemberAssignmentKeyJsonConverter.read(json, (short) 0);
            case 15:
                return ShareGroupStatePartitionMetadataKeyJsonConverter.read(json, (short) 0);
            case 16:
                return ConsumerGroupRegularExpressionKeyJsonConverter.read(json, (short) 0);
            case 17:
                return StreamsGroupMetadataKeyJsonConverter.read(json, (short) 0);
            case 19:
                return StreamsGroupMemberMetadataKeyJsonConverter.read(json, (short) 0);
            case 20:
                return StreamsGroupTargetAssignmentMetadataKeyJsonConverter.read(json, (short) 0);
            case 21:
                return StreamsGroupTargetAssignmentMemberKeyJsonConverter.read(json, (short) 0);
            case 22:
                return StreamsGroupCurrentMemberAssignmentKeyJsonConverter.read(json, (short) 0);
            case 23:
                return StreamsGroupTopologyKeyJsonConverter.read(json, (short) 0);
            default:
                throw new UnsupportedVersionException("Unknown record id " + apiKey);
        }
    }
    
    public static ApiMessage readRecordValueFromJson(JsonNode json, short apiKey, short version) {
        switch (apiKey) {
            case 0:
                return LegacyOffsetCommitValueJsonConverter.read(json, version);
            case 1:
                return OffsetCommitValueJsonConverter.read(json, version);
            case 2:
                return GroupMetadataValueJsonConverter.read(json, version);
            case 3:
                return ConsumerGroupMetadataValueJsonConverter.read(json, version);
            case 4:
                return ConsumerGroupPartitionMetadataValueJsonConverter.read(json, version);
            case 5:
                return ConsumerGroupMemberMetadataValueJsonConverter.read(json, version);
            case 6:
                return ConsumerGroupTargetAssignmentMetadataValueJsonConverter.read(json, version);
            case 7:
                return ConsumerGroupTargetAssignmentMemberValueJsonConverter.read(json, version);
            case 8:
                return ConsumerGroupCurrentMemberAssignmentValueJsonConverter.read(json, version);
            case 10:
                return ShareGroupMemberMetadataValueJsonConverter.read(json, version);
            case 11:
                return ShareGroupMetadataValueJsonConverter.read(json, version);
            case 12:
                return ShareGroupTargetAssignmentMetadataValueJsonConverter.read(json, version);
            case 13:
                return ShareGroupTargetAssignmentMemberValueJsonConverter.read(json, version);
            case 14:
                return ShareGroupCurrentMemberAssignmentValueJsonConverter.read(json, version);
            case 15:
                return ShareGroupStatePartitionMetadataValueJsonConverter.read(json, version);
            case 16:
                return ConsumerGroupRegularExpressionValueJsonConverter.read(json, version);
            case 17:
                return StreamsGroupMetadataValueJsonConverter.read(json, version);
            case 19:
                return StreamsGroupMemberMetadataValueJsonConverter.read(json, version);
            case 20:
                return StreamsGroupTargetAssignmentMetadataValueJsonConverter.read(json, version);
            case 21:
                return StreamsGroupTargetAssignmentMemberValueJsonConverter.read(json, version);
            case 22:
                return StreamsGroupCurrentMemberAssignmentValueJsonConverter.read(json, version);
            case 23:
                return StreamsGroupTopologyValueJsonConverter.read(json, version);
            default:
                throw new UnsupportedVersionException("Unknown record id " + apiKey);
        }
    }
    
}
