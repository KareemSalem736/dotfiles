/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.coordinator.group.generated;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.apache.kafka.common.protocol.ApiMessage;
import org.apache.kafka.common.protocol.Message;
import org.apache.kafka.common.protocol.MessageSizeAccumulator;
import org.apache.kafka.common.protocol.MessageUtil;
import org.apache.kafka.common.protocol.ObjectSerializationCache;
import org.apache.kafka.common.protocol.Readable;
import org.apache.kafka.common.protocol.Writable;
import org.apache.kafka.common.protocol.types.CompactArrayOf;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.protocol.types.RawTaggedField;
import org.apache.kafka.common.protocol.types.RawTaggedFieldWriter;
import org.apache.kafka.common.protocol.types.Schema;
import org.apache.kafka.common.protocol.types.Type;
import org.apache.kafka.common.utils.ByteUtils;

import static org.apache.kafka.common.protocol.types.Field.TaggedFieldsSection;


public class StreamsGroupCurrentMemberAssignmentValue implements ApiMessage {
    int memberEpoch;
    int previousMemberEpoch;
    byte state;
    List<TaskIds> activeTasks;
    List<TaskIds> standbyTasks;
    List<TaskIds> warmupTasks;
    List<TaskIds> activeTasksPendingRevocation;
    List<TaskIds> standbyTasksPendingRevocation;
    List<TaskIds> warmupTasksPendingRevocation;
    private List<RawTaggedField> _unknownTaggedFields;
    
    public static final Schema SCHEMA_0 =
        new Schema(
            new Field("member_epoch", Type.INT32, "The current member epoch that is expected from the member in the heartbeat request."),
            new Field("previous_member_epoch", Type.INT32, "If the last epoch bump is lost before reaching the member, the member will retry with the previous epoch."),
            new Field("state", Type.INT8, "The member state. See StreamsGroupMember.MemberState for the possible values."),
            new Field("active_tasks", new CompactArrayOf(TaskIds.SCHEMA_0), "Currently assigned active tasks for this streams client."),
            new Field("standby_tasks", new CompactArrayOf(TaskIds.SCHEMA_0), "Currently assigned standby tasks for this streams client."),
            new Field("warmup_tasks", new CompactArrayOf(TaskIds.SCHEMA_0), "Currently assigned warm-up tasks for this streams client."),
            new Field("active_tasks_pending_revocation", new CompactArrayOf(TaskIds.SCHEMA_0), "The active tasks that must be revoked by this member."),
            new Field("standby_tasks_pending_revocation", new CompactArrayOf(TaskIds.SCHEMA_0), "The standby tasks that must be revoked by this member."),
            new Field("warmup_tasks_pending_revocation", new CompactArrayOf(TaskIds.SCHEMA_0), "The warmup tasks that must be revoked by this member."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema[] SCHEMAS = new Schema[] {
        SCHEMA_0
    };
    
    public static final short LOWEST_SUPPORTED_VERSION = 0;
    public static final short HIGHEST_SUPPORTED_VERSION = 0;
    
    public StreamsGroupCurrentMemberAssignmentValue(Readable _readable, short _version) {
        read(_readable, _version);
    }
    
    public StreamsGroupCurrentMemberAssignmentValue() {
        this.memberEpoch = 0;
        this.previousMemberEpoch = 0;
        this.state = (byte) 0;
        this.activeTasks = new ArrayList<TaskIds>(0);
        this.standbyTasks = new ArrayList<TaskIds>(0);
        this.warmupTasks = new ArrayList<TaskIds>(0);
        this.activeTasksPendingRevocation = new ArrayList<TaskIds>(0);
        this.standbyTasksPendingRevocation = new ArrayList<TaskIds>(0);
        this.warmupTasksPendingRevocation = new ArrayList<TaskIds>(0);
    }
    
    @Override
    public short apiKey() {
        return 22;
    }
    
    @Override
    public short lowestSupportedVersion() {
        return 0;
    }
    
    @Override
    public short highestSupportedVersion() {
        return 0;
    }
    
    @Override
    public final void read(Readable _readable, short _version) {
        this.memberEpoch = _readable.readInt();
        this.previousMemberEpoch = _readable.readInt();
        this.state = _readable.readByte();
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field activeTasks was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.activeTasks = newCollection;
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field standbyTasks was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.standbyTasks = newCollection;
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field warmupTasks was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.warmupTasks = newCollection;
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field activeTasksPendingRevocation was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.activeTasksPendingRevocation = newCollection;
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field standbyTasksPendingRevocation was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.standbyTasksPendingRevocation = newCollection;
            }
        }
        {
            int arrayLength;
            arrayLength = _readable.readUnsignedVarint() - 1;
            if (arrayLength < 0) {
                throw new RuntimeException("non-nullable field warmupTasksPendingRevocation was serialized as null");
            } else {
                if (arrayLength > _readable.remaining()) {
                    throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                }
                ArrayList<TaskIds> newCollection = new ArrayList<>(arrayLength);
                for (int i = 0; i < arrayLength; i++) {
                    newCollection.add(new TaskIds(_readable, _version));
                }
                this.warmupTasksPendingRevocation = newCollection;
            }
        }
        this._unknownTaggedFields = null;
        int _numTaggedFields = _readable.readUnsignedVarint();
        for (int _i = 0; _i < _numTaggedFields; _i++) {
            int _tag = _readable.readUnsignedVarint();
            int _size = _readable.readUnsignedVarint();
            switch (_tag) {
                default:
                    this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                    break;
            }
        }
    }
    
    @Override
    public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _writable.writeInt(memberEpoch);
        _writable.writeInt(previousMemberEpoch);
        _writable.writeByte(state);
        _writable.writeUnsignedVarint(activeTasks.size() + 1);
        for (TaskIds activeTasksElement : activeTasks) {
            activeTasksElement.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(standbyTasks.size() + 1);
        for (TaskIds standbyTasksElement : standbyTasks) {
            standbyTasksElement.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(warmupTasks.size() + 1);
        for (TaskIds warmupTasksElement : warmupTasks) {
            warmupTasksElement.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(activeTasksPendingRevocation.size() + 1);
        for (TaskIds activeTasksPendingRevocationElement : activeTasksPendingRevocation) {
            activeTasksPendingRevocationElement.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(standbyTasksPendingRevocation.size() + 1);
        for (TaskIds standbyTasksPendingRevocationElement : standbyTasksPendingRevocation) {
            standbyTasksPendingRevocationElement.write(_writable, _cache, _version);
        }
        _writable.writeUnsignedVarint(warmupTasksPendingRevocation.size() + 1);
        for (TaskIds warmupTasksPendingRevocationElement : warmupTasksPendingRevocation) {
            warmupTasksPendingRevocationElement.write(_writable, _cache, _version);
        }
        RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
        _numTaggedFields += _rawWriter.numFields();
        _writable.writeUnsignedVarint(_numTaggedFields);
        _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
    }
    
    @Override
    public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _size.addBytes(4);
        _size.addBytes(4);
        _size.addBytes(1);
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(activeTasks.size() + 1));
            for (TaskIds activeTasksElement : activeTasks) {
                activeTasksElement.addSize(_size, _cache, _version);
            }
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(standbyTasks.size() + 1));
            for (TaskIds standbyTasksElement : standbyTasks) {
                standbyTasksElement.addSize(_size, _cache, _version);
            }
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(warmupTasks.size() + 1));
            for (TaskIds warmupTasksElement : warmupTasks) {
                warmupTasksElement.addSize(_size, _cache, _version);
            }
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(activeTasksPendingRevocation.size() + 1));
            for (TaskIds activeTasksPendingRevocationElement : activeTasksPendingRevocation) {
                activeTasksPendingRevocationElement.addSize(_size, _cache, _version);
            }
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(standbyTasksPendingRevocation.size() + 1));
            for (TaskIds standbyTasksPendingRevocationElement : standbyTasksPendingRevocation) {
                standbyTasksPendingRevocationElement.addSize(_size, _cache, _version);
            }
        }
        {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(warmupTasksPendingRevocation.size() + 1));
            for (TaskIds warmupTasksPendingRevocationElement : warmupTasksPendingRevocation) {
                warmupTasksPendingRevocationElement.addSize(_size, _cache, _version);
            }
        }
        if (_unknownTaggedFields != null) {
            _numTaggedFields += _unknownTaggedFields.size();
            for (RawTaggedField _field : _unknownTaggedFields) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                _size.addBytes(_field.size());
            }
        }
        _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof StreamsGroupCurrentMemberAssignmentValue)) return false;
        StreamsGroupCurrentMemberAssignmentValue other = (StreamsGroupCurrentMemberAssignmentValue) obj;
        if (memberEpoch != other.memberEpoch) return false;
        if (previousMemberEpoch != other.previousMemberEpoch) return false;
        if (state != other.state) return false;
        if (this.activeTasks == null) {
            if (other.activeTasks != null) return false;
        } else {
            if (!this.activeTasks.equals(other.activeTasks)) return false;
        }
        if (this.standbyTasks == null) {
            if (other.standbyTasks != null) return false;
        } else {
            if (!this.standbyTasks.equals(other.standbyTasks)) return false;
        }
        if (this.warmupTasks == null) {
            if (other.warmupTasks != null) return false;
        } else {
            if (!this.warmupTasks.equals(other.warmupTasks)) return false;
        }
        if (this.activeTasksPendingRevocation == null) {
            if (other.activeTasksPendingRevocation != null) return false;
        } else {
            if (!this.activeTasksPendingRevocation.equals(other.activeTasksPendingRevocation)) return false;
        }
        if (this.standbyTasksPendingRevocation == null) {
            if (other.standbyTasksPendingRevocation != null) return false;
        } else {
            if (!this.standbyTasksPendingRevocation.equals(other.standbyTasksPendingRevocation)) return false;
        }
        if (this.warmupTasksPendingRevocation == null) {
            if (other.warmupTasksPendingRevocation != null) return false;
        } else {
            if (!this.warmupTasksPendingRevocation.equals(other.warmupTasksPendingRevocation)) return false;
        }
        return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
    }
    
    @Override
    public int hashCode() {
        int hashCode = 0;
        hashCode = 31 * hashCode + memberEpoch;
        hashCode = 31 * hashCode + previousMemberEpoch;
        hashCode = 31 * hashCode + state;
        hashCode = 31 * hashCode + (activeTasks == null ? 0 : activeTasks.hashCode());
        hashCode = 31 * hashCode + (standbyTasks == null ? 0 : standbyTasks.hashCode());
        hashCode = 31 * hashCode + (warmupTasks == null ? 0 : warmupTasks.hashCode());
        hashCode = 31 * hashCode + (activeTasksPendingRevocation == null ? 0 : activeTasksPendingRevocation.hashCode());
        hashCode = 31 * hashCode + (standbyTasksPendingRevocation == null ? 0 : standbyTasksPendingRevocation.hashCode());
        hashCode = 31 * hashCode + (warmupTasksPendingRevocation == null ? 0 : warmupTasksPendingRevocation.hashCode());
        return hashCode;
    }
    
    @Override
    public StreamsGroupCurrentMemberAssignmentValue duplicate() {
        StreamsGroupCurrentMemberAssignmentValue _duplicate = new StreamsGroupCurrentMemberAssignmentValue();
        _duplicate.memberEpoch = memberEpoch;
        _duplicate.previousMemberEpoch = previousMemberEpoch;
        _duplicate.state = state;
        ArrayList<TaskIds> newActiveTasks = new ArrayList<TaskIds>(activeTasks.size());
        for (TaskIds _element : activeTasks) {
            newActiveTasks.add(_element.duplicate());
        }
        _duplicate.activeTasks = newActiveTasks;
        ArrayList<TaskIds> newStandbyTasks = new ArrayList<TaskIds>(standbyTasks.size());
        for (TaskIds _element : standbyTasks) {
            newStandbyTasks.add(_element.duplicate());
        }
        _duplicate.standbyTasks = newStandbyTasks;
        ArrayList<TaskIds> newWarmupTasks = new ArrayList<TaskIds>(warmupTasks.size());
        for (TaskIds _element : warmupTasks) {
            newWarmupTasks.add(_element.duplicate());
        }
        _duplicate.warmupTasks = newWarmupTasks;
        ArrayList<TaskIds> newActiveTasksPendingRevocation = new ArrayList<TaskIds>(activeTasksPendingRevocation.size());
        for (TaskIds _element : activeTasksPendingRevocation) {
            newActiveTasksPendingRevocation.add(_element.duplicate());
        }
        _duplicate.activeTasksPendingRevocation = newActiveTasksPendingRevocation;
        ArrayList<TaskIds> newStandbyTasksPendingRevocation = new ArrayList<TaskIds>(standbyTasksPendingRevocation.size());
        for (TaskIds _element : standbyTasksPendingRevocation) {
            newStandbyTasksPendingRevocation.add(_element.duplicate());
        }
        _duplicate.standbyTasksPendingRevocation = newStandbyTasksPendingRevocation;
        ArrayList<TaskIds> newWarmupTasksPendingRevocation = new ArrayList<TaskIds>(warmupTasksPendingRevocation.size());
        for (TaskIds _element : warmupTasksPendingRevocation) {
            newWarmupTasksPendingRevocation.add(_element.duplicate());
        }
        _duplicate.warmupTasksPendingRevocation = newWarmupTasksPendingRevocation;
        return _duplicate;
    }
    
    @Override
    public String toString() {
        return "StreamsGroupCurrentMemberAssignmentValue("
            + "memberEpoch=" + memberEpoch
            + ", previousMemberEpoch=" + previousMemberEpoch
            + ", state=" + state
            + ", activeTasks=" + MessageUtil.deepToString(activeTasks.iterator())
            + ", standbyTasks=" + MessageUtil.deepToString(standbyTasks.iterator())
            + ", warmupTasks=" + MessageUtil.deepToString(warmupTasks.iterator())
            + ", activeTasksPendingRevocation=" + MessageUtil.deepToString(activeTasksPendingRevocation.iterator())
            + ", standbyTasksPendingRevocation=" + MessageUtil.deepToString(standbyTasksPendingRevocation.iterator())
            + ", warmupTasksPendingRevocation=" + MessageUtil.deepToString(warmupTasksPendingRevocation.iterator())
            + ")";
    }
    
    public int memberEpoch() {
        return this.memberEpoch;
    }
    
    public int previousMemberEpoch() {
        return this.previousMemberEpoch;
    }
    
    public byte state() {
        return this.state;
    }
    
    public List<TaskIds> activeTasks() {
        return this.activeTasks;
    }
    
    public List<TaskIds> standbyTasks() {
        return this.standbyTasks;
    }
    
    public List<TaskIds> warmupTasks() {
        return this.warmupTasks;
    }
    
    public List<TaskIds> activeTasksPendingRevocation() {
        return this.activeTasksPendingRevocation;
    }
    
    public List<TaskIds> standbyTasksPendingRevocation() {
        return this.standbyTasksPendingRevocation;
    }
    
    public List<TaskIds> warmupTasksPendingRevocation() {
        return this.warmupTasksPendingRevocation;
    }
    
    @Override
    public List<RawTaggedField> unknownTaggedFields() {
        if (_unknownTaggedFields == null) {
            _unknownTaggedFields = new ArrayList<>(0);
        }
        return _unknownTaggedFields;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setMemberEpoch(int v) {
        this.memberEpoch = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setPreviousMemberEpoch(int v) {
        this.previousMemberEpoch = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setState(byte v) {
        this.state = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setActiveTasks(List<TaskIds> v) {
        this.activeTasks = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setStandbyTasks(List<TaskIds> v) {
        this.standbyTasks = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setWarmupTasks(List<TaskIds> v) {
        this.warmupTasks = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setActiveTasksPendingRevocation(List<TaskIds> v) {
        this.activeTasksPendingRevocation = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setStandbyTasksPendingRevocation(List<TaskIds> v) {
        this.standbyTasksPendingRevocation = v;
        return this;
    }
    
    public StreamsGroupCurrentMemberAssignmentValue setWarmupTasksPendingRevocation(List<TaskIds> v) {
        this.warmupTasksPendingRevocation = v;
        return this;
    }
    
    public static class TaskIds implements Message {
        String subtopologyId;
        List<Integer> partitions;
        private List<RawTaggedField> _unknownTaggedFields;
        
        public static final Schema SCHEMA_0 =
            new Schema(
                new Field("subtopology_id", Type.COMPACT_STRING, "The subtopology ID."),
                new Field("partitions", new CompactArrayOf(Type.INT32), "The partitions of the input topics processed by this member."),
                TaggedFieldsSection.of(
                )
            );
        
        public static final Schema[] SCHEMAS = new Schema[] {
            SCHEMA_0
        };
        
        public static final short LOWEST_SUPPORTED_VERSION = 0;
        public static final short HIGHEST_SUPPORTED_VERSION = 0;
        
        public TaskIds(Readable _readable, short _version) {
            read(_readable, _version);
        }
        
        public TaskIds() {
            this.subtopologyId = "";
            this.partitions = new ArrayList<Integer>(0);
        }
        
        
        @Override
        public short lowestSupportedVersion() {
            return 0;
        }
        
        @Override
        public short highestSupportedVersion() {
            return 32767;
        }
        
        @Override
        public final void read(Readable _readable, short _version) {
            {
                int length;
                length = _readable.readUnsignedVarint() - 1;
                if (length < 0) {
                    throw new RuntimeException("non-nullable field subtopologyId was serialized as null");
                } else if (length > 0x7fff) {
                    throw new RuntimeException("string field subtopologyId had invalid length " + length);
                } else {
                    this.subtopologyId = _readable.readString(length);
                }
            }
            {
                int arrayLength;
                arrayLength = _readable.readUnsignedVarint() - 1;
                if (arrayLength < 0) {
                    throw new RuntimeException("non-nullable field partitions was serialized as null");
                } else {
                    if (arrayLength > _readable.remaining()) {
                        throw new RuntimeException("Tried to allocate a collection of size " + arrayLength + ", but there are only " + _readable.remaining() + " bytes remaining.");
                    }
                    ArrayList<Integer> newCollection = new ArrayList<>(arrayLength);
                    for (int i = 0; i < arrayLength; i++) {
                        newCollection.add(_readable.readInt());
                    }
                    this.partitions = newCollection;
                }
            }
            this._unknownTaggedFields = null;
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
        
        @Override
        public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = _cache.getSerializedValue(subtopologyId);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
            _writable.writeUnsignedVarint(partitions.size() + 1);
            for (Integer partitionsElement : partitions) {
                _writable.writeInt(partitionsElement);
            }
            RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
            _numTaggedFields += _rawWriter.numFields();
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        }
        
        @Override
        public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
            int _numTaggedFields = 0;
            {
                byte[] _stringBytes = subtopologyId.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'subtopologyId' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(subtopologyId, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
            {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(partitions.size() + 1));
                _size.addBytes(partitions.size() * 4);
            }
            if (_unknownTaggedFields != null) {
                _numTaggedFields += _unknownTaggedFields.size();
                for (RawTaggedField _field : _unknownTaggedFields) {
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                    _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                    _size.addBytes(_field.size());
                }
            }
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        }
        
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof TaskIds)) return false;
            TaskIds other = (TaskIds) obj;
            if (this.subtopologyId == null) {
                if (other.subtopologyId != null) return false;
            } else {
                if (!this.subtopologyId.equals(other.subtopologyId)) return false;
            }
            if (this.partitions == null) {
                if (other.partitions != null) return false;
            } else {
                if (!this.partitions.equals(other.partitions)) return false;
            }
            return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
        }
        
        @Override
        public int hashCode() {
            int hashCode = 0;
            hashCode = 31 * hashCode + (subtopologyId == null ? 0 : subtopologyId.hashCode());
            hashCode = 31 * hashCode + (partitions == null ? 0 : partitions.hashCode());
            return hashCode;
        }
        
        @Override
        public TaskIds duplicate() {
            TaskIds _duplicate = new TaskIds();
            _duplicate.subtopologyId = subtopologyId;
            ArrayList<Integer> newPartitions = new ArrayList<Integer>(partitions.size());
            for (Integer _element : partitions) {
                newPartitions.add(_element);
            }
            _duplicate.partitions = newPartitions;
            return _duplicate;
        }
        
        @Override
        public String toString() {
            return "TaskIds("
                + "subtopologyId=" + ((subtopologyId == null) ? "null" : "'" + subtopologyId.toString() + "'")
                + ", partitions=" + MessageUtil.deepToString(partitions.iterator())
                + ")";
        }
        
        public String subtopologyId() {
            return this.subtopologyId;
        }
        
        public List<Integer> partitions() {
            return this.partitions;
        }
        
        @Override
        public List<RawTaggedField> unknownTaggedFields() {
            if (_unknownTaggedFields == null) {
                _unknownTaggedFields = new ArrayList<>(0);
            }
            return _unknownTaggedFields;
        }
        
        public TaskIds setSubtopologyId(String v) {
            this.subtopologyId = v;
            return this;
        }
        
        public TaskIds setPartitions(List<Integer> v) {
            this.partitions = v;
            return this;
        }
    }
}
