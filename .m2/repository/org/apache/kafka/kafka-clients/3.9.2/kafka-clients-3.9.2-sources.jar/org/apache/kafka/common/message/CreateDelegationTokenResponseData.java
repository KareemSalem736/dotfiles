/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// THIS CODE IS AUTOMATICALLY GENERATED.  DO NOT EDIT.

package org.apache.kafka.common.message;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.protocol.ApiMessage;
import org.apache.kafka.common.protocol.MessageSizeAccumulator;
import org.apache.kafka.common.protocol.MessageUtil;
import org.apache.kafka.common.protocol.ObjectSerializationCache;
import org.apache.kafka.common.protocol.Readable;
import org.apache.kafka.common.protocol.Writable;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.protocol.types.RawTaggedField;
import org.apache.kafka.common.protocol.types.RawTaggedFieldWriter;
import org.apache.kafka.common.protocol.types.Schema;
import org.apache.kafka.common.protocol.types.Type;
import org.apache.kafka.common.utils.ByteUtils;
import org.apache.kafka.common.utils.Bytes;

import static org.apache.kafka.common.protocol.types.Field.TaggedFieldsSection;


public class CreateDelegationTokenResponseData implements ApiMessage {
    short errorCode;
    String principalType;
    String principalName;
    String tokenRequesterPrincipalType;
    String tokenRequesterPrincipalName;
    long issueTimestampMs;
    long expiryTimestampMs;
    long maxTimestampMs;
    String tokenId;
    byte[] hmac;
    int throttleTimeMs;
    private List<RawTaggedField> _unknownTaggedFields;
    
    public static final Schema SCHEMA_0 =
        new Schema(
            new Field("error_code", Type.INT16, "The top-level error, or zero if there was no error."),
            new Field("principal_type", Type.STRING, "The principal type of the token owner."),
            new Field("principal_name", Type.STRING, "The name of the token owner."),
            new Field("issue_timestamp_ms", Type.INT64, "When this token was generated."),
            new Field("expiry_timestamp_ms", Type.INT64, "When this token expires."),
            new Field("max_timestamp_ms", Type.INT64, "The maximum lifetime of this token."),
            new Field("token_id", Type.STRING, "The token UUID."),
            new Field("hmac", Type.BYTES, "HMAC of the delegation token."),
            new Field("throttle_time_ms", Type.INT32, "The duration in milliseconds for which the request was throttled due to a quota violation, or zero if the request did not violate any quota.")
        );
    
    public static final Schema SCHEMA_1 = SCHEMA_0;
    
    public static final Schema SCHEMA_2 =
        new Schema(
            new Field("error_code", Type.INT16, "The top-level error, or zero if there was no error."),
            new Field("principal_type", Type.COMPACT_STRING, "The principal type of the token owner."),
            new Field("principal_name", Type.COMPACT_STRING, "The name of the token owner."),
            new Field("issue_timestamp_ms", Type.INT64, "When this token was generated."),
            new Field("expiry_timestamp_ms", Type.INT64, "When this token expires."),
            new Field("max_timestamp_ms", Type.INT64, "The maximum lifetime of this token."),
            new Field("token_id", Type.COMPACT_STRING, "The token UUID."),
            new Field("hmac", Type.COMPACT_BYTES, "HMAC of the delegation token."),
            new Field("throttle_time_ms", Type.INT32, "The duration in milliseconds for which the request was throttled due to a quota violation, or zero if the request did not violate any quota."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema SCHEMA_3 =
        new Schema(
            new Field("error_code", Type.INT16, "The top-level error, or zero if there was no error."),
            new Field("principal_type", Type.COMPACT_STRING, "The principal type of the token owner."),
            new Field("principal_name", Type.COMPACT_STRING, "The name of the token owner."),
            new Field("token_requester_principal_type", Type.COMPACT_STRING, "The principal type of the requester of the token."),
            new Field("token_requester_principal_name", Type.COMPACT_STRING, "The principal type of the requester of the token."),
            new Field("issue_timestamp_ms", Type.INT64, "When this token was generated."),
            new Field("expiry_timestamp_ms", Type.INT64, "When this token expires."),
            new Field("max_timestamp_ms", Type.INT64, "The maximum lifetime of this token."),
            new Field("token_id", Type.COMPACT_STRING, "The token UUID."),
            new Field("hmac", Type.COMPACT_BYTES, "HMAC of the delegation token."),
            new Field("throttle_time_ms", Type.INT32, "The duration in milliseconds for which the request was throttled due to a quota violation, or zero if the request did not violate any quota."),
            TaggedFieldsSection.of(
            )
        );
    
    public static final Schema[] SCHEMAS = new Schema[] {
        SCHEMA_0,
        SCHEMA_1,
        SCHEMA_2,
        SCHEMA_3
    };
    
    public static final short LOWEST_SUPPORTED_VERSION = 0;
    public static final short HIGHEST_SUPPORTED_VERSION = 3;
    
    public CreateDelegationTokenResponseData(Readable _readable, short _version) {
        read(_readable, _version);
    }
    
    public CreateDelegationTokenResponseData() {
        this.errorCode = (short) 0;
        this.principalType = "";
        this.principalName = "";
        this.tokenRequesterPrincipalType = "";
        this.tokenRequesterPrincipalName = "";
        this.issueTimestampMs = 0L;
        this.expiryTimestampMs = 0L;
        this.maxTimestampMs = 0L;
        this.tokenId = "";
        this.hmac = Bytes.EMPTY;
        this.throttleTimeMs = 0;
    }
    
    @Override
    public short apiKey() {
        return 38;
    }
    
    @Override
    public short lowestSupportedVersion() {
        return 0;
    }
    
    @Override
    public short highestSupportedVersion() {
        return 3;
    }
    
    @Override
    public final void read(Readable _readable, short _version) {
        this.errorCode = _readable.readShort();
        {
            int length;
            if (_version >= 2) {
                length = _readable.readUnsignedVarint() - 1;
            } else {
                length = _readable.readShort();
            }
            if (length < 0) {
                throw new RuntimeException("non-nullable field principalType was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field principalType had invalid length " + length);
            } else {
                this.principalType = _readable.readString(length);
            }
        }
        {
            int length;
            if (_version >= 2) {
                length = _readable.readUnsignedVarint() - 1;
            } else {
                length = _readable.readShort();
            }
            if (length < 0) {
                throw new RuntimeException("non-nullable field principalName was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field principalName had invalid length " + length);
            } else {
                this.principalName = _readable.readString(length);
            }
        }
        if (_version >= 3) {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                throw new RuntimeException("non-nullable field tokenRequesterPrincipalType was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field tokenRequesterPrincipalType had invalid length " + length);
            } else {
                this.tokenRequesterPrincipalType = _readable.readString(length);
            }
        } else {
            this.tokenRequesterPrincipalType = "";
        }
        if (_version >= 3) {
            int length;
            length = _readable.readUnsignedVarint() - 1;
            if (length < 0) {
                throw new RuntimeException("non-nullable field tokenRequesterPrincipalName was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field tokenRequesterPrincipalName had invalid length " + length);
            } else {
                this.tokenRequesterPrincipalName = _readable.readString(length);
            }
        } else {
            this.tokenRequesterPrincipalName = "";
        }
        this.issueTimestampMs = _readable.readLong();
        this.expiryTimestampMs = _readable.readLong();
        this.maxTimestampMs = _readable.readLong();
        {
            int length;
            if (_version >= 2) {
                length = _readable.readUnsignedVarint() - 1;
            } else {
                length = _readable.readShort();
            }
            if (length < 0) {
                throw new RuntimeException("non-nullable field tokenId was serialized as null");
            } else if (length > 0x7fff) {
                throw new RuntimeException("string field tokenId had invalid length " + length);
            } else {
                this.tokenId = _readable.readString(length);
            }
        }
        {
            int length;
            if (_version >= 2) {
                length = _readable.readUnsignedVarint() - 1;
            } else {
                length = _readable.readInt();
            }
            if (length < 0) {
                throw new RuntimeException("non-nullable field hmac was serialized as null");
            } else {
                byte[] newBytes = _readable.readArray(length);
                this.hmac = newBytes;
            }
        }
        this.throttleTimeMs = _readable.readInt();
        this._unknownTaggedFields = null;
        if (_version >= 2) {
            int _numTaggedFields = _readable.readUnsignedVarint();
            for (int _i = 0; _i < _numTaggedFields; _i++) {
                int _tag = _readable.readUnsignedVarint();
                int _size = _readable.readUnsignedVarint();
                switch (_tag) {
                    default:
                        this._unknownTaggedFields = _readable.readUnknownTaggedField(this._unknownTaggedFields, _tag, _size);
                        break;
                }
            }
        }
    }
    
    @Override
    public void write(Writable _writable, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _writable.writeShort(errorCode);
        {
            byte[] _stringBytes = _cache.getSerializedValue(principalType);
            if (_version >= 2) {
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
            } else {
                _writable.writeShort((short) _stringBytes.length);
            }
            _writable.writeByteArray(_stringBytes);
        }
        {
            byte[] _stringBytes = _cache.getSerializedValue(principalName);
            if (_version >= 2) {
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
            } else {
                _writable.writeShort((short) _stringBytes.length);
            }
            _writable.writeByteArray(_stringBytes);
        }
        if (_version >= 3) {
            {
                byte[] _stringBytes = _cache.getSerializedValue(tokenRequesterPrincipalType);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
        } else {
            if (!this.tokenRequesterPrincipalType.equals("")) {
                throw new UnsupportedVersionException("Attempted to write a non-default tokenRequesterPrincipalType at version " + _version);
            }
        }
        if (_version >= 3) {
            {
                byte[] _stringBytes = _cache.getSerializedValue(tokenRequesterPrincipalName);
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
                _writable.writeByteArray(_stringBytes);
            }
        } else {
            if (!this.tokenRequesterPrincipalName.equals("")) {
                throw new UnsupportedVersionException("Attempted to write a non-default tokenRequesterPrincipalName at version " + _version);
            }
        }
        _writable.writeLong(issueTimestampMs);
        _writable.writeLong(expiryTimestampMs);
        _writable.writeLong(maxTimestampMs);
        {
            byte[] _stringBytes = _cache.getSerializedValue(tokenId);
            if (_version >= 2) {
                _writable.writeUnsignedVarint(_stringBytes.length + 1);
            } else {
                _writable.writeShort((short) _stringBytes.length);
            }
            _writable.writeByteArray(_stringBytes);
        }
        if (_version >= 2) {
            _writable.writeUnsignedVarint(hmac.length + 1);
        } else {
            _writable.writeInt(hmac.length);
        }
        _writable.writeByteArray(hmac);
        _writable.writeInt(throttleTimeMs);
        RawTaggedFieldWriter _rawWriter = RawTaggedFieldWriter.forFields(_unknownTaggedFields);
        _numTaggedFields += _rawWriter.numFields();
        if (_version >= 2) {
            _writable.writeUnsignedVarint(_numTaggedFields);
            _rawWriter.writeRawTags(_writable, Integer.MAX_VALUE);
        } else {
            if (_numTaggedFields > 0) {
                throw new UnsupportedVersionException("Tagged fields were set, but version " + _version + " of this message does not support them.");
            }
        }
    }
    
    @Override
    public void addSize(MessageSizeAccumulator _size, ObjectSerializationCache _cache, short _version) {
        int _numTaggedFields = 0;
        _size.addBytes(2);
        {
            byte[] _stringBytes = principalType.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'principalType' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(principalType, _stringBytes);
            if (_version >= 2) {
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            } else {
                _size.addBytes(_stringBytes.length + 2);
            }
        }
        {
            byte[] _stringBytes = principalName.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'principalName' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(principalName, _stringBytes);
            if (_version >= 2) {
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            } else {
                _size.addBytes(_stringBytes.length + 2);
            }
        }
        if (_version >= 3) {
            {
                byte[] _stringBytes = tokenRequesterPrincipalType.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'tokenRequesterPrincipalType' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(tokenRequesterPrincipalType, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
        }
        if (_version >= 3) {
            {
                byte[] _stringBytes = tokenRequesterPrincipalName.getBytes(StandardCharsets.UTF_8);
                if (_stringBytes.length > 0x7fff) {
                    throw new RuntimeException("'tokenRequesterPrincipalName' field is too long to be serialized");
                }
                _cache.cacheSerializedValue(tokenRequesterPrincipalName, _stringBytes);
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            }
        }
        _size.addBytes(8);
        _size.addBytes(8);
        _size.addBytes(8);
        {
            byte[] _stringBytes = tokenId.getBytes(StandardCharsets.UTF_8);
            if (_stringBytes.length > 0x7fff) {
                throw new RuntimeException("'tokenId' field is too long to be serialized");
            }
            _cache.cacheSerializedValue(tokenId, _stringBytes);
            if (_version >= 2) {
                _size.addBytes(_stringBytes.length + ByteUtils.sizeOfUnsignedVarint(_stringBytes.length + 1));
            } else {
                _size.addBytes(_stringBytes.length + 2);
            }
        }
        {
            _size.addBytes(hmac.length);
            if (_version >= 2) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(hmac.length + 1));
            } else {
                _size.addBytes(4);
            }
        }
        _size.addBytes(4);
        if (_unknownTaggedFields != null) {
            _numTaggedFields += _unknownTaggedFields.size();
            for (RawTaggedField _field : _unknownTaggedFields) {
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.tag()));
                _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_field.size()));
                _size.addBytes(_field.size());
            }
        }
        if (_version >= 2) {
            _size.addBytes(ByteUtils.sizeOfUnsignedVarint(_numTaggedFields));
        } else {
            if (_numTaggedFields > 0) {
                throw new UnsupportedVersionException("Tagged fields were set, but version " + _version + " of this message does not support them.");
            }
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof CreateDelegationTokenResponseData)) return false;
        CreateDelegationTokenResponseData other = (CreateDelegationTokenResponseData) obj;
        if (errorCode != other.errorCode) return false;
        if (this.principalType == null) {
            if (other.principalType != null) return false;
        } else {
            if (!this.principalType.equals(other.principalType)) return false;
        }
        if (this.principalName == null) {
            if (other.principalName != null) return false;
        } else {
            if (!this.principalName.equals(other.principalName)) return false;
        }
        if (this.tokenRequesterPrincipalType == null) {
            if (other.tokenRequesterPrincipalType != null) return false;
        } else {
            if (!this.tokenRequesterPrincipalType.equals(other.tokenRequesterPrincipalType)) return false;
        }
        if (this.tokenRequesterPrincipalName == null) {
            if (other.tokenRequesterPrincipalName != null) return false;
        } else {
            if (!this.tokenRequesterPrincipalName.equals(other.tokenRequesterPrincipalName)) return false;
        }
        if (issueTimestampMs != other.issueTimestampMs) return false;
        if (expiryTimestampMs != other.expiryTimestampMs) return false;
        if (maxTimestampMs != other.maxTimestampMs) return false;
        if (this.tokenId == null) {
            if (other.tokenId != null) return false;
        } else {
            if (!this.tokenId.equals(other.tokenId)) return false;
        }
        if (!Arrays.equals(this.hmac, other.hmac)) return false;
        if (throttleTimeMs != other.throttleTimeMs) return false;
        return MessageUtil.compareRawTaggedFields(_unknownTaggedFields, other._unknownTaggedFields);
    }
    
    @Override
    public int hashCode() {
        int hashCode = 0;
        hashCode = 31 * hashCode + errorCode;
        hashCode = 31 * hashCode + (principalType == null ? 0 : principalType.hashCode());
        hashCode = 31 * hashCode + (principalName == null ? 0 : principalName.hashCode());
        hashCode = 31 * hashCode + (tokenRequesterPrincipalType == null ? 0 : tokenRequesterPrincipalType.hashCode());
        hashCode = 31 * hashCode + (tokenRequesterPrincipalName == null ? 0 : tokenRequesterPrincipalName.hashCode());
        hashCode = 31 * hashCode + ((int) (issueTimestampMs >> 32) ^ (int) issueTimestampMs);
        hashCode = 31 * hashCode + ((int) (expiryTimestampMs >> 32) ^ (int) expiryTimestampMs);
        hashCode = 31 * hashCode + ((int) (maxTimestampMs >> 32) ^ (int) maxTimestampMs);
        hashCode = 31 * hashCode + (tokenId == null ? 0 : tokenId.hashCode());
        hashCode = 31 * hashCode + Arrays.hashCode(hmac);
        hashCode = 31 * hashCode + throttleTimeMs;
        return hashCode;
    }
    
    @Override
    public CreateDelegationTokenResponseData duplicate() {
        CreateDelegationTokenResponseData _duplicate = new CreateDelegationTokenResponseData();
        _duplicate.errorCode = errorCode;
        _duplicate.principalType = principalType;
        _duplicate.principalName = principalName;
        _duplicate.tokenRequesterPrincipalType = tokenRequesterPrincipalType;
        _duplicate.tokenRequesterPrincipalName = tokenRequesterPrincipalName;
        _duplicate.issueTimestampMs = issueTimestampMs;
        _duplicate.expiryTimestampMs = expiryTimestampMs;
        _duplicate.maxTimestampMs = maxTimestampMs;
        _duplicate.tokenId = tokenId;
        _duplicate.hmac = MessageUtil.duplicate(hmac);
        _duplicate.throttleTimeMs = throttleTimeMs;
        return _duplicate;
    }
    
    @Override
    public String toString() {
        return "CreateDelegationTokenResponseData("
            + "errorCode=" + errorCode
            + ", principalType=" + ((principalType == null) ? "null" : "'" + principalType.toString() + "'")
            + ", principalName=" + ((principalName == null) ? "null" : "'" + principalName.toString() + "'")
            + ", tokenRequesterPrincipalType=" + ((tokenRequesterPrincipalType == null) ? "null" : "'" + tokenRequesterPrincipalType.toString() + "'")
            + ", tokenRequesterPrincipalName=" + ((tokenRequesterPrincipalName == null) ? "null" : "'" + tokenRequesterPrincipalName.toString() + "'")
            + ", issueTimestampMs=" + issueTimestampMs
            + ", expiryTimestampMs=" + expiryTimestampMs
            + ", maxTimestampMs=" + maxTimestampMs
            + ", tokenId=" + ((tokenId == null) ? "null" : "'" + tokenId.toString() + "'")
            + ", hmac=" + Arrays.toString(hmac)
            + ", throttleTimeMs=" + throttleTimeMs
            + ")";
    }
    
    public short errorCode() {
        return this.errorCode;
    }
    
    public String principalType() {
        return this.principalType;
    }
    
    public String principalName() {
        return this.principalName;
    }
    
    public String tokenRequesterPrincipalType() {
        return this.tokenRequesterPrincipalType;
    }
    
    public String tokenRequesterPrincipalName() {
        return this.tokenRequesterPrincipalName;
    }
    
    public long issueTimestampMs() {
        return this.issueTimestampMs;
    }
    
    public long expiryTimestampMs() {
        return this.expiryTimestampMs;
    }
    
    public long maxTimestampMs() {
        return this.maxTimestampMs;
    }
    
    public String tokenId() {
        return this.tokenId;
    }
    
    public byte[] hmac() {
        return this.hmac;
    }
    
    public int throttleTimeMs() {
        return this.throttleTimeMs;
    }
    
    @Override
    public List<RawTaggedField> unknownTaggedFields() {
        if (_unknownTaggedFields == null) {
            _unknownTaggedFields = new ArrayList<>(0);
        }
        return _unknownTaggedFields;
    }
    
    public CreateDelegationTokenResponseData setErrorCode(short v) {
        this.errorCode = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setPrincipalType(String v) {
        this.principalType = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setPrincipalName(String v) {
        this.principalName = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setTokenRequesterPrincipalType(String v) {
        this.tokenRequesterPrincipalType = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setTokenRequesterPrincipalName(String v) {
        this.tokenRequesterPrincipalName = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setIssueTimestampMs(long v) {
        this.issueTimestampMs = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setExpiryTimestampMs(long v) {
        this.expiryTimestampMs = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setMaxTimestampMs(long v) {
        this.maxTimestampMs = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setTokenId(String v) {
        this.tokenId = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setHmac(byte[] v) {
        this.hmac = v;
        return this;
    }
    
    public CreateDelegationTokenResponseData setThrottleTimeMs(int v) {
        this.throttleTimeMs = v;
        return this;
    }
}
