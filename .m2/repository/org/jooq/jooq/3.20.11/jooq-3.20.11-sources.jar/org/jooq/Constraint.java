/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Other licenses:
 * -----------------------------------------------------------------------------
 * Commercial licenses for this work are available. These replace the above
 * Apache-2.0 license and offer limited warranties, support, maintenance, and
 * commercial database integrations.
 *
 * For more information, please visit: https://www.jooq.org/legal/licensing
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
package org.jooq;

import org.jooq.impl.DSL;

/**
 * A DDL constraint.
 * <p>
 * Constraint definitions can be used in DDL statements in order to specify the
 * constraint, or in some DML statements that reference a given constraint.
 * <p>
 * <strong>Example:</strong>
 * <p>
 * <pre><code>
 * // Assuming import static org.jooq.impl.DSL.*;
 *
 * using(configuration)
 *    .alterTable(ACTOR)
 *    .add(constraint("actor_unique_name")
 *        .unique(ACTOR.FIRST_NAME, ACTOR.LAST_NAME))
 *    .execute();
 * </code></pre>
 * <p>
 * Instances can be created using {@link DSL#constraint(Name)} and overloads.
 *
 * @author Lukas Eder
 */
public interface Constraint
extends
    FieldOrConstraint,
    TableElement
{

}
