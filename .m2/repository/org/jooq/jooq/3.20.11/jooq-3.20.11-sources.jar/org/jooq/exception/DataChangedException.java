/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Other licenses:
 * -----------------------------------------------------------------------------
 * Commercial licenses for this work are available. These replace the above
 * Apache-2.0 license and offer limited warranties, support, maintenance, and
 * commercial database integrations.
 *
 * For more information, please visit: https://www.jooq.org/legal/licensing
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
package org.jooq.exception;

import org.jooq.UpdatableRecord;

/**
 * An error occurred while storing a record with optimistic locking active,
 * whose underlying data had already been changed.
 * <p>
 * This exception may be thrown if:
 * <ul>
 * <li>The record has been changed.</li>
 * <li>The record has been removed.</li>
 * <li>It isn't possible to detect whether the record has been changed (e.g.
 * because {@link UpdatableRecord#update()} is called on a record that hasn't
 * been previously fetched from the database).</li>
 * </ul>
 *
 * @see UpdatableRecord#store()
 * @author Lukas Eder
 */
public class DataChangedException extends DataAccessException {

    /**
     * Constructor for DataChangedException.
     *
     * @param message the detail message
     */
    public DataChangedException(String message) {
        super(message);
    }

    /**
     * Constructor for DataChangedException.
     *
     * @param message the detail message
     * @param cause the root cause (usually from using a underlying data access
     *            API such as JDBC)
     */
    public DataChangedException(String message, Throwable cause) {
        super(message, cause);
    }
}
