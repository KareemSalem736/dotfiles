// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

package io.prometheus.metrics.shaded.com_google_protobuf_4_31_1;

/** Represents the syntax version of the message. */
@ExperimentalApi
public enum ProtoSyntax {
  PROTO2,
  PROTO3,
  EDITIONS;
}
