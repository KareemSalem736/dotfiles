// This file contains the serialized FeatureSetDefaults object corresponding to
// the Java runtime.  This is used for feature resolution under Editions.

package io.prometheus.metrics.shaded.com_google_protobuf_4_31_1;

public final class JavaEditionDefaults {
  public static final String PROTOBUF_INTERNAL_JAVA_EDITION_DEFAULTS = "\n\'\030\204\007\"\003\312>\000*\035\010\001\020\002\030\002 \003(\0010\0028\002@\001\312>\n\010\001\020\001\030\000 \001(\003\n\'\030\347\007\"\003\312>\000*\035\010\002\020\001\030\001 \002(\0010\0018\002@\001\312>\n\010\000\020\001\030\000 \001(\003\n\'\030\350\007\"\023\010\001\020\001\030\001 \002(\0010\001\312>\004\010\000\020\001*\r8\002@\001\312>\006\030\000 \001(\003 \346\007(\350\007";

  private JavaEditionDefaults() {}
}
