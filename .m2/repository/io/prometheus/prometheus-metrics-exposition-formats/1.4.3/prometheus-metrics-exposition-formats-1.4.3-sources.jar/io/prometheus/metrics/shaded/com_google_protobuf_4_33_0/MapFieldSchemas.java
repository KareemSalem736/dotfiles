// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

package io.prometheus.metrics.shaded.com_google_protobuf_4_33_0;

@CheckReturnValue
final class MapFieldSchemas {
  private static final MapFieldSchema FULL_SCHEMA = loadSchemaForFullRuntime();
  private static final MapFieldSchema LITE_SCHEMA = new MapFieldSchemaLite();

  static MapFieldSchema full() {
    return FULL_SCHEMA;
  }

  static MapFieldSchema lite() {
    return LITE_SCHEMA;
  }

  private static MapFieldSchema loadSchemaForFullRuntime() {
    if (Android.assumeLiteRuntime) {
      return null;
    }
    try {
      Class<?> clazz = Class.forName("io.prometheus.metrics.shaded.com_google_protobuf_4_33_0.MapFieldSchemaFull");
      return (MapFieldSchema) clazz.getDeclaredConstructor().newInstance();
    } catch (Exception e) {
      return null;
    }
  }

  private MapFieldSchemas() {}
}
