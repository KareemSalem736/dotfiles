package io.blackcape.atoms.common.exception;

import lombok.EqualsAndHashCode;
import lombok.experimental.StandardException;

/**
 * A base runtime exception from which all other ATOMS exceptions extend
 */
@EqualsAndHashCode(callSuper = false)
@StandardException
public class AtomsException extends RuntimeException {
	// Intentionally left blank
}
