package io.blackcape.atoms.common.function;

import lombok.NoArgsConstructor;

import java.util.function.Function;

import static lombok.AccessLevel.PRIVATE;

/**
 * A utility class for arbitrary java functions and functional interface helpers
 */
@NoArgsConstructor(access = PRIVATE)
public final class Functions {
	/**
	 * Apply the given function to the given param and return the result only if the
	 * param is not null
	 *
	 * @param param
	 *            The input param
	 * @param function
	 *            The function
	 * @param <T>
	 *            The input type
	 * @param <S>
	 *            The return type
	 * @return The result
	 */
	public static <T, S> S applyIfNotNull(T param, Function<T, S> function) {
		// Apply the function if the parameter is not null
		return (param != null) ? function.apply(param) : null;
	}
}
