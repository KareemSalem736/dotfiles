package io.blackcape.atoms.common.exception;

import lombok.EqualsAndHashCode;
import lombok.experimental.StandardException;

/**
 * An exception to throw when a given user DN is invalid
 */
@EqualsAndHashCode(callSuper = false)
@StandardException
public class InvalidUserDnException extends AtomsException {
	// Intentionally left blank
}
