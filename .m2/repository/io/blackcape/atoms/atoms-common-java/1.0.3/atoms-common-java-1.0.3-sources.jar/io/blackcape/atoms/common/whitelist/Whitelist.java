package io.blackcape.atoms.common.whitelist;

import io.blackcape.atoms.common.types.UserDn;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.function.Predicate.not;

/**
 * A wrapper around a whitelist of user DNs
 */
public class Whitelist {
	// Members
	private final Set<UserDn> whitelistUsers;

	/**
	 * Constructor
	 *
	 * @param path
	 *            The whitelist file path
	 * @throws IOException
	 *             Thrown if the whitelist file is invalid
	 */
	public Whitelist(Path path) throws IOException {
		// Read the file line by line
		whitelistUsers = Files.readAllLines(path).stream()
				// Exclude any blank lines
				.filter(not(String::isBlank))
				// Format each user DN
				.map(UserDn::new)
				// Collect into a set
				.collect(Collectors.toSet());
	}

	/**
	 * Determine if the given user DN is in the whitelist
	 *
	 * @param userDn
	 *            The user DN
	 * @return True if the user DN is in the whitelist
	 */
	public boolean isUserInWhitelist(UserDn userDn) {
		// Check to see if the formatted user DN is in the whitelist
		return whitelistUsers.contains(userDn);
	}
}
