package io.blackcape.atoms.common.format;

import io.blackcape.atoms.common.exception.InvalidUserDnException;
import lombok.NoArgsConstructor;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;

import static java.util.Objects.requireNonNull;
import static lombok.AccessLevel.PRIVATE;

/**
 * A utility class to assist with formatting
 */
@NoArgsConstructor(access = PRIVATE)
public final class FormatUtils {
	/**
	 * Format the given user DN enforcing casing and component order
	 *
	 * @param userDn
	 *            The user DN
	 * @return The formatted user DN
	 */
	public static String formatUserDn(String userDn) {
		try {
			// Parse the userDN as an LDAP name
			LdapName dn = new LdapName(requireNonNull(userDn).toLowerCase());

			// Build a new LDAP Name with the RDS from the first to retrigger formatting
			return new LdapName(dn.getRdns()).toString();
		} catch (NullPointerException | InvalidNameException e) {
			throw new InvalidUserDnException("Invalid LDAP name", e);
		}
	}
}
