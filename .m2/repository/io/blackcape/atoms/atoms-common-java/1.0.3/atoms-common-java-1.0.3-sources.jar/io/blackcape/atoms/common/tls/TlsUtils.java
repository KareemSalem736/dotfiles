package io.blackcape.atoms.common.tls;

import io.blackcape.atoms.common.exception.TlsException;
import lombok.NoArgsConstructor;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;

import static lombok.AccessLevel.PRIVATE;

/**
 * A utility class for TLS functions
 */
@NoArgsConstructor(access = PRIVATE)
public final class TlsUtils {

	/**
	 * Create an SSLContext instance for the given keystore and truststore
	 *
	 * @param keyStorePath
	 *            The keystore file path
	 * @param keyStorePassword
	 *            The keystore password
	 * @param trustStorePath
	 *            The truststore file path
	 * @param trustStorePassword
	 *            The truststore password
	 * @return The SSLContext instance
	 */
	public static SSLContext getSslContext(
			String keyStorePath,
			String keyStorePassword,
			String trustStorePath,
			String trustStorePassword) {
		try {
			// Initialize the SSL Context
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(getKeyManagers(keyStorePath, keyStorePassword),
					getTrustManagers(trustStorePath, trustStorePassword), null);

			// Return the SSL context
			return sslContext;
		} catch (Exception e) {
			throw new TlsException(e);
		}
	}

	/**
	 * Get the key manager array for the given parameters
	 *
	 * @param keyStorePath
	 *            The keystore file path
	 * @param keyStorePassword
	 *            The keystore password
	 * @return The key managers array
	 */
	public static KeyManager[] getKeyManagers(
			String keyStorePath,
			String keyStorePassword) {
		try {
			// Configure the key store
			KeyStore keyStore = KeyStore.getInstance("PKCS12");
			try (FileInputStream keyStoreFileInputStream = new FileInputStream(keyStorePath)) {
				keyStore.load(keyStoreFileInputStream, keyStorePassword.toCharArray());
			}

			// Create the key manager factory
			KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(
					KeyManagerFactory.getDefaultAlgorithm());

			// Initialize the key manager factory
			keyManagerFactory.init(keyStore, keyStorePassword.toCharArray());

			// Return the key managers
			return keyManagerFactory.getKeyManagers();
		} catch (Exception e) {
			throw new TlsException(e);
		}
	}

	/**
	 * Get the trust manager array for the given parameters
	 *
	 * @param trustStorePath
	 *            The truststore file path
	 * @param trustStorePassword
	 *            The truststore password
	 * @return The key managers array
	 */
	public static TrustManager[] getTrustManagers(
			String trustStorePath,
			String trustStorePassword) {
		try {
			// Configure the trust store
			KeyStore trustStore = KeyStore.getInstance("PKCS12");
			try (FileInputStream trustStoreFileInputStream = new FileInputStream(trustStorePath)) {
				trustStore.load(trustStoreFileInputStream, trustStorePassword.toCharArray());
			}

			// Create the trust manager factory
			TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(
					TrustManagerFactory.getDefaultAlgorithm());

			// Initialize the key manager factory
			trustManagerFactory.init(trustStore);

			// Return the key managers
			return trustManagerFactory.getTrustManagers();
		} catch (Exception e) {
			throw new TlsException(e);
		}
	}
}
