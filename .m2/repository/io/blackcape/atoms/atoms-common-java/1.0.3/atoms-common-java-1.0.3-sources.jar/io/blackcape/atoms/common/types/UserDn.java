package io.blackcape.atoms.common.types;

import jakarta.annotation.Nonnull;

import static io.blackcape.atoms.common.format.FormatUtils.formatUserDn;

/**
 * The user DN domain type which enforces casing and formatting
 *
 * @param dn
 *            The user DN
 */
public record UserDn(String dn) {
	/**
	 * Constructor
	 *
	 * @param dn
	 *            The user DN
	 */
	public UserDn {
		// Format the user DN
		dn = formatUserDn(dn);
	}

	@Override
	@Nonnull
	public String toString() {
		return dn;
	}
}
