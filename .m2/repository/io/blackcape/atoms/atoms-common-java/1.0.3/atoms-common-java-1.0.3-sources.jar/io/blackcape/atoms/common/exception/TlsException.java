package io.blackcape.atoms.common.exception;

import lombok.EqualsAndHashCode;
import lombok.experimental.StandardException;

/**
 * An exception to throw when TLS configuration fails
 */
@EqualsAndHashCode(callSuper = false)
@StandardException
public class TlsException extends AtomsException {
	// Intentionally left blank
}
