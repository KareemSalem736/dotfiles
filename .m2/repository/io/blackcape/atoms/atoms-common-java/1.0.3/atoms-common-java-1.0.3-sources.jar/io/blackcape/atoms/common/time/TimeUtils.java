package io.blackcape.atoms.common.time;

import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static lombok.AccessLevel.PRIVATE;

/**
 * A utility class for time based utilities
 */
@NoArgsConstructor(access = PRIVATE)
public final class TimeUtils {
	/**
	 * Get the current UTC time
	 *
	 * @return The current UTC time
	 */
	public static OffsetDateTime utcNow() {
		// Get the current UTC time
		return OffsetDateTime.now(ZoneOffset.UTC);
	}
}
