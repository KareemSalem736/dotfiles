package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The ACM Has Access Response model
 *
 * @param errors
 *            The errors
 * @param acm
 *            The ACM
 * @param path
 *            The path
 */
@JsonInclude(NON_EMPTY)
public record AcmHasAccessResponse(
		@JsonProperty("Errors")
		HasAccessError errors,
		@JsonProperty("ACM")
		Acm acm,
		@JsonProperty("Path")
		String path) {
	// Intentionally left blank
}
