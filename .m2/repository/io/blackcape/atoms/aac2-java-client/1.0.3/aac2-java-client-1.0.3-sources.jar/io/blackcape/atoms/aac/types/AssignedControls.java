package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Assigned Controls model
 *
 * @param coi
 *            The COI
 * @param coiCtrls
 *            The COI controls
 */
@JsonInclude(NON_EMPTY)
public record AssignedControls(
		List<String> coi,
		@JsonProperty("coi_ctrls")
		List<String> coiCtrls) {
	// Intentionally left blank
}
