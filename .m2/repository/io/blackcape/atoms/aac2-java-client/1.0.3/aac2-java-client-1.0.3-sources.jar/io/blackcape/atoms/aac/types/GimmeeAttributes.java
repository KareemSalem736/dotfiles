package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The "gimmee" attributes model
 *
 * @param organization
 *            The organization
 * @param topic
 *            The topics
 * @param region
 *            The regions
 * @param groups
 *            The groups
 * @param isAICP
 *            The is AICP flag
 * @param communityType
 *            The community type
 * @param organizationalPath
 *            The organizational path
 */
@JsonInclude(NON_EMPTY)
public record GimmeeAttributes(
		String organization,
		List<String> topic,
		List<String> region,
		List<String> groups,
		Boolean isAICP,
		String communityType,
		String organizationalPath) {
	// Intentionally left blank
}
