package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Marking to ACM Response model
 *
 * @param errors
 *            The errors
 * @param warnings
 *            The warnings
 * @param acm
 *            The ACM
 * @param path
 *            The path
 */
@JsonInclude(NON_EMPTY)
public record MarkingToAcmResponse(
		@JsonProperty("Errors")
		List<String> errors,
		@JsonProperty("Warnings")
		List<String> warnings,
		@JsonProperty("ACM")
		Acm acm,
		@JsonProperty("Path")
		String path) {
	// Intentionally left blank
}
