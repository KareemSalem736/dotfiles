package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The only as is model
 *
 * @param asIs
 *            The as is list
 */
@JsonInclude(NON_EMPTY)
public record OnlyAsIs(
		@JsonProperty("as_is")
		List<String> asIs) {
	// Intentionally left blank
}
