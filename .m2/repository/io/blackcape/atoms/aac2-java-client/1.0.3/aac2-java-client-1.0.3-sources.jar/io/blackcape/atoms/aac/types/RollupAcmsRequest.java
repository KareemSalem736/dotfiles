package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Rollup ACMs Request model
 *
 * @param share
 *            The share information
 * @param shareType
 *            The share type
 * @param accessTuples
 *            The access tuples
 * @param checkAccess
 *            The check access flag
 */
@JsonInclude(NON_EMPTY)
public record RollupAcmsRequest(
		@JsonProperty("Share")
		RollupShare share,
		@JsonProperty("ShareType")
		String shareType,
		@JsonProperty("AccessTuples")
		List<AccessTuple> accessTuples,
		@JsonProperty("CheckAccess")
		Boolean checkAccess) {
	// Intentionally left blank
}
