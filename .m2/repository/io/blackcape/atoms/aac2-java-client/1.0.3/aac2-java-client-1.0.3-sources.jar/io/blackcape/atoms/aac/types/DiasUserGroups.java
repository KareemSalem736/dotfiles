package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The DIAS user groups model
 *
 * @param projectName
 *            The project name
 * @param groupNames
 *            The group names
 */
@JsonInclude(NON_EMPTY)
public record DiasUserGroups(
		String projectName,
		List<String> groupNames) {
	// Intentionally left blank
}
