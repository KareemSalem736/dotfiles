package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Access Tuple model
 *
 * @param path
 *            The path
 * @param acm
 *            The ACM
 */
@JsonInclude(NON_EMPTY)
public record AccessTuple(
		@JsonProperty("Path")
		String path,
		@JsonProperty("ACM")
		Acm acm) {
	// Intentionally left blank
}
