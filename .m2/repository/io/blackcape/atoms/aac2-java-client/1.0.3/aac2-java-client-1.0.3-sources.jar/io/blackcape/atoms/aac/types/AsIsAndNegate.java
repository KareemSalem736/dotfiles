package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The as is and negate model
 *
 * @param asIs
 *            The as is list
 * @param negate
 *            The negation list
 */
@JsonInclude(NON_EMPTY)
public record AsIsAndNegate(
		@JsonProperty("as_is")
		List<String> asIs,
		List<String> negate) {
	// Intentionally left blank
}
