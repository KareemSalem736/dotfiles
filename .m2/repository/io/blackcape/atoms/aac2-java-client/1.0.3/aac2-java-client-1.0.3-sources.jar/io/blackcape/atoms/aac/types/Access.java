package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Access model
 *
 * @param hasAccess
 *            Whether the user has access
 * @param accessErrors
 *            The access errors
 */
@JsonInclude(NON_EMPTY)
public record Access(
		@JsonProperty("HasAccess")
		Boolean hasAccess,
		@JsonProperty("AccessErrors")
		List<String> accessErrors) {
	// Intentionally left blank
}
