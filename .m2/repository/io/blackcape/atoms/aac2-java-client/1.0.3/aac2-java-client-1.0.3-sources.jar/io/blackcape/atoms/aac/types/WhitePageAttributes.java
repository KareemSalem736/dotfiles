package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The white page attributes model
 *
 * @param firstName
 *            The first name
 * @param surName
 *            The surname
 * @param uid
 *            The UID
 * @param companyName
 *            The company name
 * @param telephoneNumber
 *            The telephone number
 * @param icEmail
 *            The IC email
 * @param siprnetEmail
 *            The SIPRNET email
 * @param niprnetEmail
 *            The NIPRNET email
 */
@JsonInclude(NON_EMPTY)
public record WhitePageAttributes(
		String firstName,
		String surName,
		String uid,
		String companyName,
		String telephoneNumber,
		String icEmail,
		String siprnetEmail,
		String niprnetEmail) {
	// Intentionally left blank
}
