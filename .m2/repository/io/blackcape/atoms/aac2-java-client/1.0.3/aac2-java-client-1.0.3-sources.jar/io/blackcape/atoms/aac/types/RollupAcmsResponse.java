package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Rollup ACMs Response model
 *
 * @param validation
 *            The validation response
 * @param access
 *            The access response
 * @param rollupAcm
 *            The rollup ACM
 */
@JsonInclude(NON_EMPTY)
public record RollupAcmsResponse(
		@JsonProperty("Validation")
		List<AcmValidateResponse> validation,
		@JsonProperty("Access")
		Access access,
		@JsonProperty("RollupACM")
		Acm rollupAcm) {
	// Intentionally left blank
}
