package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Project model
 *
 * @param dispNm
 *            The display name
 * @param groups
 *            The groups
 */
@JsonInclude(NON_EMPTY)
public record Project(
		@JsonProperty("disp_nm")
		String dispNm,
		List<String> groups) {
	// Intentionally left blank
}
