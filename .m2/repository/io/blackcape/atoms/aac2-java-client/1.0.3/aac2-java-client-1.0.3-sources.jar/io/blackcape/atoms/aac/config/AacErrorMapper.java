package io.blackcape.atoms.aac.config;

import io.blackcape.atoms.aac.types.AacException;
import jakarta.annotation.Nonnull;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.springframework.util.StreamUtils.copyToString;

/**
 * A request interceptor to convert REST exceptions to AAC client exceptions
 */
class AacErrorMapper implements ClientHttpRequestInterceptor {
	@Override
	@Nonnull
	public ClientHttpResponse intercept(
			@Nonnull
			HttpRequest request,
			@Nonnull
			byte[] body,
			@Nonnull
			ClientHttpRequestExecution execution) {
		try {
			// Execute the request and return the response
			ClientHttpResponse response = execution.execute(request, body);

			// If the response is not successful, throw an exception
			if (!response.getStatusCode().is2xxSuccessful()) {
				throw new AacException("%s: %s".formatted(
						response.getStatusCode(),
						copyToString(response.getBody(), UTF_8)));
			}

			// Return the response
			return response;
		}
		// Rethrow the aac exception
		catch (AacException e) {
			throw e;
		}
		// Wrap any unexpected exceptions
		catch (Exception e) {
			// Wrap any exception in an AAC exception instance
			throw new AacException("Unexpected exception!", e);
		}
	}
}
