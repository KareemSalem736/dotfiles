package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The ACCM model
 *
 * @param coi
 *            The COI
 * @param dispNm
 *            The display name
 * @param coiCtrls
 *            The COI controls
 */
@JsonInclude(NON_EMPTY)
public record Accm(
		String coi,
		@JsonProperty("disp_nm")
		String dispNm,
		@JsonProperty("coi_ctrls")
		List<CoiControl> coiCtrls) {
	// Intentionally left blank
}
