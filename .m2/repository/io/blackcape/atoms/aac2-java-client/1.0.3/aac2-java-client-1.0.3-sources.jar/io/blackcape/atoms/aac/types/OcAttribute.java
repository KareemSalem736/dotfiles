package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The OC Attribute model
 *
 * @param orgs
 *            The orgs
 * @param missions
 *            The missions
 * @param regions
 *            The regions
 */
@JsonInclude(NON_EMPTY)
public record OcAttribute(
		List<String> orgs,
		List<String> missions,
		List<String> regions) {
	// Intentionally left blank
}
