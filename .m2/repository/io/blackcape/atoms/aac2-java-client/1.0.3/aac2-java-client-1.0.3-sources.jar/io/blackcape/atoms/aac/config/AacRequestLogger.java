package io.blackcape.atoms.aac.config;

import jakarta.annotation.Nonnull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

import static java.util.concurrent.TimeUnit.NANOSECONDS;

/**
 * A request interceptor to perform request logging and latency measurements
 */
@Slf4j
@RequiredArgsConstructor
class AacRequestLogger implements ClientHttpRequestInterceptor {
	// Members
	private final long warningThresholdMs;

	@Override
	@Nonnull
	public ClientHttpResponse intercept(
			@Nonnull
			HttpRequest request,
			@Nonnull
			byte[] body,
			@Nonnull
			ClientHttpRequestExecution execution) throws IOException {
		// Log the outbound request
		log.debug("Sending AAC {} request to {} with headers: {}",
				request.getMethod(), request.getURI(), request.getHeaders());

		// Mark the request start time
		long startTime = System.nanoTime();

		// Execute the request
		ClientHttpResponse response = execution.execute(request, body);

		// Compute the latency
		long requestLatencyMs = NANOSECONDS.toMillis(System.nanoTime() - startTime);

		// Log the response
		log.debug("Got response with status code {} and headers: {} in {} ms",
				response.getStatusCode(), response.getHeaders(), requestLatencyMs);

		// Log a warning the latency was high
		if (requestLatencyMs > warningThresholdMs) {
			log.warn("AAC query was slow. Took {} ms to receive a response", requestLatencyMs);
		}

		// Return the client response
		return response;
	}
}
