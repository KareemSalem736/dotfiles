package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.OffsetDateTime;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The ACM model
 *
 * @param version
 *            The version
 * @param classif
 *            The classification
 * @param classifType
 *            The classification type
 * @param ownerProd
 *            The owner prod
 * @param atomEnergy
 *            The atom energy data
 * @param nonUsCtrls
 *            The non US controls
 * @param sarId
 *            The SAR ID
 * @param sciCtrls
 *            The SCE controls
 * @param disponlyTo
 *            The display only to
 * @param dissemCtrls
 *            The dissemination controls
 * @param nonIc
 *            The non IC markings
 * @param relTo
 *            The RELTO marking
 * @param classifRsn
 *            The classification RSN
 * @param classifBy
 *            The classified by user
 * @param compliesWith
 *            The complies with data
 * @param classifDt
 *            The classification time
 * @param declassDt
 *            The declassification time
 * @param declassEvent
 *            The declassification event
 * @param declassEx
 *            The declassification ex
 * @param derivClassBy
 *            The derivative classification info
 * @param derivFrom
 *            The derived from data
 * @param desVersion
 *            The des version
 * @param noticeRsn
 *            The notice RSN
 * @param poc
 *            The POC
 * @param rsrcElem
 *            The RSRC elements
 * @param compilRsn
 *            The compil RSN
 * @param exFromRollup
 *            The ex from rollup
 * @param fgiOpen
 *            The FGI open marking
 * @param fgiProtect
 *            The FGI protect marking
 * @param portion
 *            The portion marking
 * @param banner
 *            The banner
 * @param dissemCountries
 *            The dissemination countries
 * @param accms
 *            The ACCMs
 * @param macs
 *            The MACs
 * @param ocAttribs
 *            The OC attributes
 * @param share
 *            The share data
 * @param assignedControls
 *            The assigned controls
 * @param fClearance
 *            The f clearance
 * @param fSciCtrls
 *            The f SCI controls
 * @param fAccms
 *            The f ACCMs
 * @param fOcOrg
 *            The f OC Org
 * @param fRegions
 *            The f regions
 * @param fMissions
 *            The f missions
 * @param fShare
 *            The f share
 * @param fSarId
 *            The f SAR ID
 * @param fAtomEnergy
 *            The f atom energy
 * @param fMacs
 *            The f MACs
 */
@JsonInclude(NON_EMPTY)
public record Acm(
		String version,
		String classif,
		@JsonProperty("classif_type")
		String classifType,
		@JsonProperty("owner_prod")
		List<String> ownerProd,
		@JsonProperty("atom_energy")
		List<String> atomEnergy,
		@JsonProperty("non_us_ctrls")
		List<String> nonUsCtrls,
		@JsonProperty("sar_id")
		List<String> sarId,
		@JsonProperty("sci_ctrls")
		List<String> sciCtrls,
		@JsonProperty("disponly_to")
		List<String> disponlyTo,
		@JsonProperty("dissem_ctrls")
		List<String> dissemCtrls,
		@JsonProperty("non_ic")
		List<String> nonIc,
		@JsonProperty("rel_to")
		List<String> relTo,
		@JsonProperty("classif_rsn")
		String classifRsn,
		@JsonProperty("classif_by")
		String classifBy,
		@JsonProperty("complies_with")
		String compliesWith,
		@JsonProperty("classif_dt")
		OffsetDateTime classifDt,
		@JsonProperty("declass_dt")
		OffsetDateTime declassDt,
		@JsonProperty("declass_event")
		String declassEvent,
		@JsonProperty("declass_ex")
		String declassEx,
		@JsonProperty("deriv_class_by")
		String derivClassBy,
		@JsonProperty("deriv_from")
		String derivFrom,
		@JsonProperty("des_version")
		String desVersion,
		@JsonProperty("notice_rsn")
		String noticeRsn,
		String poc,
		@JsonProperty("rsrc_elem")
		Boolean rsrcElem,
		@JsonProperty("compil_rsn")
		String compilRsn,
		@JsonProperty("ex_from_rollup")
		Boolean exFromRollup,
		@JsonProperty("fgi_open")
		List<String> fgiOpen,
		@JsonProperty("fgi_protect")
		List<String> fgiProtect,
		String portion,
		String banner,
		@JsonProperty("dissem_countries")
		List<String> dissemCountries,
		List<Accm> accms,
		List<Accm> macs,
		@JsonProperty("oc_attribs")
		List<OcAttribute> ocAttribs,
		Share share,
		@JsonProperty("assigned_controls")
		AssignedControls assignedControls,
		@JsonProperty("f_clearance")
		List<String> fClearance,
		@JsonProperty("f_sci_ctrls")
		List<String> fSciCtrls,
		@JsonProperty("f_accms")
		List<String> fAccms,
		@JsonProperty("f_oc_org")
		List<String> fOcOrg,
		@JsonProperty("f_regions")
		List<String> fRegions,
		@JsonProperty("f_missions")
		List<String> fMissions,
		@JsonProperty("f_share")
		List<String> fShare,
		@JsonProperty("f_sar_id")
		List<String> fSarId,
		@JsonProperty("f_atom_energy")
		List<String> fAtomEnergy,
		@JsonProperty("f_macs")
		List<String> fMacs) {
	// Intentionally left blank
}
