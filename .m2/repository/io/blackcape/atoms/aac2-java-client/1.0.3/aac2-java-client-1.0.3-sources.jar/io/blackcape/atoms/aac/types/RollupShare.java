package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Rollup Share model
 *
 * @param users
 *            The users
 * @param projects
 *            The projects
 */
@JsonInclude(NON_EMPTY)
public record RollupShare(
		@JsonProperty("Users")
		List<String> users,
		@JsonProperty("Projects")
		Map<String, Project> projects) {
	// Intentionally left blank
}
