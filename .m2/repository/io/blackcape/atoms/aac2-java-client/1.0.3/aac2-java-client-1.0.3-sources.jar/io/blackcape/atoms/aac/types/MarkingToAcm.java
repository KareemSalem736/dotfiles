package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Marking to ACM model
 *
 * @param share
 *            The share information
 * @param marking
 *            The marking
 * @param path
 *            The path
 * @param cois
 *            The COIs
 * @param coiControls
 *            The COI controls
 * @param orgs
 *            The orgs
 */
@JsonInclude(NON_EMPTY)
public record MarkingToAcm(
		@JsonProperty("Share")
		RollupShare share,
		@JsonProperty("Marking")
		String marking,
		@JsonProperty("Path")
		String path,
		@JsonProperty("Cois")
		List<String> cois,
		@JsonProperty("CoiControls")
		List<String> coiControls,
		@JsonProperty("Orgs")
		List<String> orgs) {
	// Intentionally left blank
}
