package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The user clearance model
 *
 * @param clearance
 *            The clearance
 * @param citizenship
 *            The citizenship
 * @param clearanceRank
 *            The clearance rank
 * @param formalAccess
 *            The formal access
 */
@JsonInclude(NON_EMPTY)
public record UserClearance(
		String clearance,
		String citizenship,
		String clearanceRank,
		List<String> formalAccess) {
	// Intentionally left blank
}
