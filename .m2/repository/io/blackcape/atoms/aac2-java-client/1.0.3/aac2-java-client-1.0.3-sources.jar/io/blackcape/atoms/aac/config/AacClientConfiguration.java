package io.blackcape.atoms.aac.config;

import io.blackcape.atoms.aac.client.AacClient;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.support.RestClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

import java.net.http.HttpClient;
import java.time.Duration;

import static org.springframework.http.HttpHeaders.USER_AGENT;

/**
 * Configuration for the AAC2 REST client
 */
@Slf4j
@Getter
@Configuration
public class AacClientConfiguration {
	// Configuration parameters
	@Value("${aac.client.url}")
	private String aacBaseUrl;
	@Value("${aac.client.ssl-bundle-name}")
	private String sslBundleName;
	@Value("${aac.client.read-timeout:10s}")
	private Duration readTimeout;
	@Value("${aac.client.connection-timeout:10s}")
	private Duration connectionTimeout;
	@Value("${aac.client.latency-warning-threshold:500ms}")
	private Duration latencyWarningThreshold;
	@Value("${aac.client.client-name:ATOMS AAC Client}")
	private String clientName;

	/**
	 * Create an instance of AAC client using the given rest client
	 *
	 * @param sslBundles
	 *            The spring SSL bundles
	 * @return The AAC client instance
	 */
	@Bean
	@ConditionalOnMissingBean
	public AacClient aacClient(SslBundles sslBundles) {
		// Create the java HTTP client
		HttpClient httpClient = HttpClient.newBuilder()
				.sslContext(sslBundles.getBundle(sslBundleName).createSslContext())
				.connectTimeout(connectionTimeout)
				.build();

		// Build the JDK client request factory
		JdkClientHttpRequestFactory requestFactory = new JdkClientHttpRequestFactory(httpClient);

		// Set the read timeout
		requestFactory.setReadTimeout(readTimeout);

		// Build and return the rest client instance
		RestClient restClient = RestClient.builder()
				.baseUrl(aacBaseUrl)
				.requestFactory(requestFactory)
				.defaultHeader(USER_AGENT, clientName)
				.requestInterceptor(new AacErrorMapper())
				.requestInterceptor(new AacRequestLogger(latencyWarningThreshold.toMillis()))
				.build();

		// Create a declarative proxy
		HttpServiceProxyFactory proxyFactory = HttpServiceProxyFactory.builder()
				.exchangeAdapter(RestClientAdapter.create(restClient))
				.build();

		// Create and return the AAC client instance
		return proxyFactory.createClient(AacClient.class);
	}

	/**
	 * Log the current configuration parameters
	 */
	@PostConstruct
	private void logConfiguration() {
		log.debug("""
				AAC Client Configuration Loaded
				aac.client.url: {}
				aac.client.ssl-bundle-name: {}
				aac.client.read-timeout: {}
				aac.client.connection-timeout: {}
				aac.client.latency-warning-threshold: {}
				aac.client.client-name: {}
				""", aacBaseUrl, sslBundleName, readTimeout, connectionTimeout, latencyWarningThreshold, clientName);
	}
}
