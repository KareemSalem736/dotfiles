package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * The Has Access Error model
 *
 * @param validation
 *            The validation
 * @param access
 *            The access
 */
public record HasAccessError(
		@JsonProperty("Validation")
		List<String> validation,
		@JsonProperty("Access")
		List<String> access) {
	// Intentionally left blank
}
