package io.blackcape.atoms.aac.client;

import io.blackcape.atoms.aac.types.AccessTuple;
import io.blackcape.atoms.aac.types.AcmHasAccessResponse;
import io.blackcape.atoms.aac.types.AcmValidateResponse;
import io.blackcape.atoms.aac.types.MarkingToAcm;
import io.blackcape.atoms.aac.types.MarkingToAcmResponse;
import io.blackcape.atoms.aac.types.RollupAcmsRequest;
import io.blackcape.atoms.aac.types.RollupAcmsResponse;
import io.blackcape.atoms.aac.types.UserObject;
import jakarta.annotation.Nonnull;
import jakarta.annotation.Nullable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.PostExchange;

import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * A client interface for interacting with AAC 2.0
 */
public interface AacClient {

	/**
	 * Ping AAC and make sure it can be reached
	 */
	@GetExchange(url = "/")
	void ping();

	/**
	 * Check a user's access to the given ACMs
	 *
	 * @param userDn
	 *            The user DN to check
	 * @param accessTuples
	 *            The ACMs to check
	 * @return The access result
	 */
	@Nonnull
	@PostExchange(url = "users/{userDn}/accesses", contentType = APPLICATION_JSON_VALUE, accept = APPLICATION_JSON_VALUE)
	List<AcmHasAccessResponse> accesses(
			@Nonnull @PathVariable
			String userDn,
			@Nonnull @RequestBody
			List<AccessTuple> accessTuples);

	/**
	 * Validate the given ACMs
	 *
	 * @param accessTuples
	 *            The ACMs to validate
	 * @return The validation result
	 */
	@Nonnull
	@PostExchange(url = "acms/validations", contentType = APPLICATION_JSON_VALUE, accept = APPLICATION_JSON_VALUE)
	List<AcmValidateResponse> validations(
			@Nonnull @RequestBody
			List<AccessTuple> accessTuples);

	/**
	 * Rollup the input ACMs into a single ACM
	 *
	 * @param rollupAcmsRequest
	 *            The ACMs to rollup
	 * @return The rollup response
	 */
	@Nonnull
	@PostExchange(url = "acms/rollup", contentType = APPLICATION_JSON_VALUE, accept = APPLICATION_JSON_VALUE)
	RollupAcmsResponse rollup(
			@Nonnull @RequestBody
			RollupAcmsRequest rollupAcmsRequest);

	/**
	 * Get the user attributes for the given user
	 *
	 * @param userToken
	 *            The user DN
	 * @param template
	 *            The search template
	 * @return The user attributes map
	 */
	@Nonnull
	@GetExchange(url = "users")
	UserObject users(
			@Nonnull @RequestParam
			String userToken,
			@Nullable @RequestParam(required = false)
			String template);

	/**
	 * Convert a marking into an ACM
	 *
	 * @param markingToAcm
	 *            The marking to convert
	 * @return The full ACM
	 */
	@Nonnull
	@PostExchange(url = "icmss/markings/acms", contentType = APPLICATION_JSON_VALUE, accept = APPLICATION_JSON_VALUE)
	List<MarkingToAcmResponse> markings(
			@Nonnull @RequestBody
			List<MarkingToAcm> markingToAcm);
}
