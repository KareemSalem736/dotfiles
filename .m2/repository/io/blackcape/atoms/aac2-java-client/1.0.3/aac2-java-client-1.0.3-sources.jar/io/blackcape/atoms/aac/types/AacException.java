package io.blackcape.atoms.aac.types;

import io.blackcape.atoms.common.exception.AtomsException;

/**
 * An exception thrown by AAC
 */
public class AacException extends AtomsException {
	/**
	 * Constructor
	 *
	 * @param message
	 *            The error message
	 */
	public AacException(String message) {
		this(message, null);
	}

	/**
	 * Constructor
	 *
	 * @param message
	 *            The error message
	 * @param cause
	 *            The error cause
	 */
	public AacException(String message, Exception cause) {
		super(message, cause);
	}
}
