package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The user object model
 *
 * @param userDn
 *            The user DN
 * @param diasUserGroups
 *            The DIAS groups
 * @param whitePageAttributes
 *            The white page attributes
 * @param userClearance
 *            The user clearance
 * @param gimmeeAttributes
 *            The gimmee attributes
 * @param adminOrg
 *            The admin org
 * @param dutyOrg
 *            The duty org
 * @param nShare
 *            The n share
 * @param nMacs
 *            The n MACs
 * @param nAccms
 *            The n ACCMs
 * @param nFormalAccess
 *            The n formal access
 * @param fMacs
 *            The f MACs
 * @param fOcOrg
 *            The f OC org
 * @param fAccms
 *            The f ACCMs
 * @param fClearance
 *            The f clearance
 * @param fRegions
 *            The f regions
 * @param fMissions
 *            The f missions
 * @param fShare
 *            The f share
 * @param fSciCtrls
 *            The f SCI controls
 */
@JsonInclude(NON_EMPTY)
public record UserObject(
		@JsonProperty("userDN")
		String userDn,
		Projects diasUserGroups,
		WhitePageAttributes whitePageAttributes,
		UserClearance userClearance,
		GimmeeAttributes gimmeeAttributes,
		String adminOrg,
		String dutyOrg,
		Map<String, List<String>> nShare,
		List<Coi> nMacs,
		List<Coi> nAccms,
		List<String> nFormalAccess,
		@JsonProperty("f_macs")
		AsIsAndNegate fMacs,
		@JsonProperty("f_oc_org")
		OnlyAsIs fOcOrg,
		@JsonProperty("f_accms")
		AsIsAndNegate fAccms,
		@JsonProperty("f_clearance")
		OnlyAsIs fClearance,
		@JsonProperty("f_regions")
		OnlyAsIs fRegions,
		@JsonProperty("f_missions")
		OnlyAsIs fMissions,
		@JsonProperty("f_share")
		OnlyAsIs fShare,
		@JsonProperty("f_sci_ctrls")
		AsIsAndNegate fSciCtrls) {
	// Intentionally left blank
}
