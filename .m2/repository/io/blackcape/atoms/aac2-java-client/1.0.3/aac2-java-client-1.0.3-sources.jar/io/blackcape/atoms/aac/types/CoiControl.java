package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The COI Control model
 *
 * @param coiCtrl
 *            The COI control
 * @param dispNm
 *            The display name
 */
@JsonInclude(NON_EMPTY)
public record CoiControl(
		@JsonProperty("coi_ctrl")
		String coiCtrl,
		@JsonProperty("disp_nm")
		String dispNm) {
	// Intentionally left blank
}
