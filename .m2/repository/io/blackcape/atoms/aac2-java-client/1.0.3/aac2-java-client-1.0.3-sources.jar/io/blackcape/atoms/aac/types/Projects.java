package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Projects model
 *
 * @param projectsList
 *            The projects list
 */
@JsonInclude(NON_EMPTY)
public record Projects(
		@JsonProperty("projects")
		List<DiasUserGroups> projectsList) {
	// Intentionally left blank
}
