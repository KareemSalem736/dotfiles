package io.blackcape.atoms.aac.types;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

/**
 * The Share model
 *
 * @param users
 *            The users
 * @param projects
 *            The projects
 */
@JsonInclude(NON_EMPTY)
public record Share(
		List<String> users,
		Map<String, Project> projects) {
	// Intentionally left blank
}
