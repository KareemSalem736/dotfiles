package io.blackcape.atoms.grpc.server.interceptors;

import static io.blackcape.atoms.grpc.server.interceptors.RequestIdInterceptor.REQUEST_ID_KEY;

import io.grpc.Context;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;

import java.util.UUID;
import java.util.concurrent.ExecutorService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

/**
 * An interceptor to enable thread interruption when a gRPC request is canceled
 * by the client
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "atoms.grpc.server.enable-cancellation", havingValue = "true", matchIfMissing = true)
@GlobalServerInterceptor
@RequiredArgsConstructor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class RequestCancellationInterceptor implements ServerInterceptor {
	// Members
	private final ExecutorService executorService;

	@Override
	public <T, S> ServerCall.Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		// Get the request thread
		Thread thread = Thread.currentThread();

		// Register for cancellation with the context
		Context.current().addListener(cancelledContext -> {
			// If the call is actually canceled by the client
			if (call.isCancelled()) {
				// Get the request ID for logging
				UUID requestId = REQUEST_ID_KEY.get(cancelledContext);

				// Log a warning
				log.warn("Request {} has been canceled by the client", requestId);

				// Interrupt the server thread
				thread.interrupt();
			}
		}, executorService);

		// Continue the call
		return next.startCall(call, headers);
	}
}
