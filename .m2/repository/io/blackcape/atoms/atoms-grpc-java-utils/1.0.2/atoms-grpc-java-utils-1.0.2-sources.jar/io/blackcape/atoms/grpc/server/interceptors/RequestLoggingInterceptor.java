package io.blackcape.atoms.grpc.server.interceptors;

import static io.blackcape.atoms.common.time.TimeUtils.utcNow;
import static io.blackcape.atoms.grpc.server.interceptors.PrincipalDnInterceptor.PRINCIPAL_DN_CONTEXT_KEY;
import static io.blackcape.atoms.grpc.server.interceptors.RequestIdInterceptor.REQUEST_ID_KEY;
import static io.blackcape.atoms.grpc.server.interceptors.UserDnInterceptor.USER_DN_CONTEXT_KEY;
import static java.util.Objects.requireNonNull;

import io.blackcape.atoms.common.types.UserDn;
import io.blackcape.atoms.grpc.utils.ProtobufUtils;
import io.grpc.ForwardingServerCallListener;
import io.grpc.Grpc;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;

/**
 * An interceptor to log incoming requests
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "atoms.grpc.server.enable-request-logging", havingValue = "true", matchIfMissing = true)
@Order(2)
@GlobalServerInterceptor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class RequestLoggingInterceptor implements ServerInterceptor {

	@Override
	public <T, S> ServerCall.Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		// Extract the request metadata for logging
		UserDn principalDn = PRINCIPAL_DN_CONTEXT_KEY.get();
		UserDn userDn = USER_DN_CONTEXT_KEY.get();
		UUID requestId = REQUEST_ID_KEY.get();
		SocketAddress remoteAddr = requireNonNull(call.getAttributes().get(Grpc.TRANSPORT_ATTR_REMOTE_ADDR));
		String requestName = call.getMethodDescriptor().getBareMethodName();

		// Create a forwarding call listener and log each incoming message
		return new ForwardingServerCallListener.SimpleForwardingServerCallListener<>(next.startCall(call, headers)) {
			@Override
			public void onMessage(T message) {
				// Build the metadata map
				Map<String, Object> requestMetadata = LinkedHashMap.newLinkedHashMap(5);
				requestMetadata.put("request_id", requestId);
				requestMetadata.put("principal_dn", principalDn);
				requestMetadata.put("user_dn", userDn);
				requestMetadata.put("request_time", utcNow());
				requestMetadata.put("remote_addr", getIpAddress(remoteAddr));
				requestMetadata.put("request_name", requestName);
				requestMetadata.put("message", ProtobufUtils.toJson(message));

				// Log the message as JSON
				log.info("REQUEST: {}", JsonMapper.shared().writeValueAsString(requestMetadata));

				// Continue the call
				super.onMessage(message);
			}
		};
	}

	/**
	 * Get the IP string from the socket address
	 *
	 * @param socketAddress
	 *            The socket address
	 * @return The IP string
	 */
	private String getIpAddress(SocketAddress socketAddress) {
		// Map the address based on its class type
		if (socketAddress instanceof InetSocketAddress inetSocketAddress) {
			return inetSocketAddress.getAddress().getHostAddress();
		} else {
			return socketAddress.toString();
		}
	}
}
