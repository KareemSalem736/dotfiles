package io.blackcape.atoms.grpc.server.interceptors;

import io.blackcape.atoms.common.types.UserDn;
import io.blackcape.atoms.common.whitelist.Whitelist;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

import static io.blackcape.atoms.grpc.server.interceptors.PrincipalDnInterceptor.PRINCIPAL_DN_CONTEXT_KEY;
import static io.blackcape.atoms.grpc.server.interceptors.UserDnInterceptor.USER_DN_CONTEXT_KEY;
import static io.grpc.Status.PERMISSION_DENIED;

/**
 * An interceptor to validate impersonation attempts
 */
@Slf4j
@Component
@Order(3)
@GlobalServerInterceptor
@RequiredArgsConstructor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class ImpersonationInterceptor implements ServerInterceptor {
	// Members
	private final Whitelist whitelist;

	@Override
	public <T, S> ServerCall.Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		// Extract the principal DN from the cert and the supplied user DN
		UserDn principalDn = PRINCIPAL_DN_CONTEXT_KEY.get();
		UserDn userDn = USER_DN_CONTEXT_KEY.get();

		// If impersonation is happening and the principal is not whitelisted
		if (!principalDn.equals(userDn) && !whitelist.isUserInWhitelist(principalDn)) {
			// Log an exception
			log.error("Illegal impersonation attempt! {} attempted to impersonate {}", principalDn, userDn);

			// Close the call with permission denied
			call.close(PERMISSION_DENIED.withDescription("Unauthorized impersonation attempt!"), new Metadata());

			// End the call chain
			return new ServerCall.Listener<T>() {
				// Intentionally left blank
			};
		} else {
			// Otherwise, continue the call
			return next.startCall(call, headers);
		}
	}
}
