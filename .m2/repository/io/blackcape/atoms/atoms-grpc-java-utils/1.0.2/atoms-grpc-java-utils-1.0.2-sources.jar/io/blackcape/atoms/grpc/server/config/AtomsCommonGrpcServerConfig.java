package io.blackcape.atoms.grpc.server.config;

import static java.util.concurrent.Executors.newThreadPerTaskExecutor;

import io.blackcape.atoms.grpc.server.utils.ErrorMapper;
import io.grpc.ServerBuilder;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.grpc.server.ServerBuilderCustomizer;

import java.util.concurrent.ExecutorService;

/**
 * Common configuration for all ATOMS gRPC servers
 */
@Configuration
public class AtomsCommonGrpcServerConfig {
	@Getter
	@Value("${atoms.grpc.server.name:ATOMS Server}")
	private String serverName;

	@Bean
	public ExecutorService executorService() {
		// Create a new virtual executor service including the server name
		return newThreadPerTaskExecutor(Thread.ofVirtual().name(serverName).factory());
	}

	/**
	 * Update the server to use virtual threads
	 *
	 * @param <T>
	 *            The server type
	 * @return The customizer instance
	 */
	@Bean
	public <T extends ServerBuilder<T>> ServerBuilderCustomizer<T> customizer(ExecutorService executorService) {
		// Build and return the customizer
		return builder ->
		// Enable virtual threads
		builder.executor(executorService);
	}

	/**
	 * The default error mapper
	 *
	 * @return The default instance
	 */
	@Bean
	@ConditionalOnMissingBean
	public ErrorMapper errorMapper() {
		// Create a default error mapper instance
		return status -> status;
	}
}
