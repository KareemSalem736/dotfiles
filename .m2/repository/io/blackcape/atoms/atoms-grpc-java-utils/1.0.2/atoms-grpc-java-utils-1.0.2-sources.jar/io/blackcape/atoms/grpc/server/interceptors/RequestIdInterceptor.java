package io.blackcape.atoms.grpc.server.interceptors;

import io.grpc.Context;
import io.grpc.Context.Key;
import io.grpc.Contexts;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;

import java.util.UUID;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

@Component
@Order(1)
@GlobalServerInterceptor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class RequestIdInterceptor implements ServerInterceptor {
	// Public constants
	public static final Key<UUID> REQUEST_ID_KEY = Context.key("request_id");

	@Override
	public <T, S> ServerCall.Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		// Generate a unique ID for this request and add it to the context
		UUID id = UUID.randomUUID();
		Context context = Context.current().withValue(REQUEST_ID_KEY, id);

		// Attach the modified context to the call
		return Contexts.interceptCall(context, call, headers, next);
	}
}
