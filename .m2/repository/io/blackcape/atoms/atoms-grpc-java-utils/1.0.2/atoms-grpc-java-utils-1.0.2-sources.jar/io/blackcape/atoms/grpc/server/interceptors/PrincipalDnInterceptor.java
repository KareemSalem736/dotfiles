package io.blackcape.atoms.grpc.server.interceptors;

import io.blackcape.atoms.common.types.UserDn;
import io.grpc.Context;
import io.grpc.Context.Key;
import io.grpc.Contexts;
import io.grpc.Grpc;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCall.Listener;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.security.auth.x500.X500Principal;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.stream.Stream;

import static io.grpc.Status.UNAUTHENTICATED;
import static java.util.Objects.requireNonNull;
import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;

/**
 * A gRPC interceptor to extract the user DN from the incoming TLS certificate
 * and put it into the gRPC context
 */
@Component
@Order(HIGHEST_PRECEDENCE)
@GlobalServerInterceptor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class PrincipalDnInterceptor implements ServerInterceptor {
	// Constants
	private static final Metadata EMPTY_METADATA = new Metadata();

	// Public constants
	public static final Key<UserDn> PRINCIPAL_DN_CONTEXT_KEY = Context.key("principal_dn");

	@Override
	public <T, S> Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		try {
			// Get the client cert information
			SSLSession session = requireNonNull(call.getAttributes().get(Grpc.TRANSPORT_ATTR_SSL_SESSION));
			Certificate[] certs = session.getPeerCertificates();
			UserDn userDn = Stream.of(certs)
					.filter(X509Certificate.class::isInstance)
					.map(X509Certificate.class::cast)
					.map(X509Certificate::getSubjectX500Principal)
					.map(X500Principal::getName)
					.findFirst()
					.map(UserDn::new)
					.orElseThrow();

			// Add the user DN to the gRPC context
			Context context = Context.current().withValue(PRINCIPAL_DN_CONTEXT_KEY, userDn);

			// Continue the call with the modified context
			return Contexts.interceptCall(context, call, headers, next);
		} catch (SSLPeerUnverifiedException e) {
			// Return an error and end the call
			call.close(UNAUTHENTICATED.withCause(e), EMPTY_METADATA);
			return new Listener<T>() {
				// Intentionally left blank
			};
		}
	}
}
