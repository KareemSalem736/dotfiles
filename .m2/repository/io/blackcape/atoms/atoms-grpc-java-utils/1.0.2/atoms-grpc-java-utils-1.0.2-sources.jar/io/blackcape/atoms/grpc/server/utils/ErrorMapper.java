package io.blackcape.atoms.grpc.server.utils;

import io.grpc.Status;

/**
 * An error mapper for customizing gRPC statuses
 */
public interface ErrorMapper {
	/**
	 * Map the input status to a custom status
	 *
	 * @param status
	 *            The input status
	 * @return The mapped status
	 */
	Status mapError(Status status);
}
