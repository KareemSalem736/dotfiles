package io.blackcape.atoms.grpc.server.interceptors;

import io.blackcape.atoms.grpc.server.utils.ErrorMapper;
import io.grpc.ForwardingServerCall;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;
import io.grpc.Status;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

/**
 * An error mapping interceptor for converting application errors to gRPC
 * statuses
 */
@Component
@Order(3)
@GlobalServerInterceptor
@RequiredArgsConstructor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class ErrorMappingInterceptor implements ServerInterceptor {
	// Members
	private final ErrorMapper errorMapper;

	@Override
	public <T, S> ServerCall.Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		ServerCall<T, S> wrappedCall = new ForwardingServerCall.SimpleForwardingServerCall<>(call) {
			@Override
			public void close(Status status, Metadata trailers) {
				// If there is an error, convert the exception
				if (!status.isOk()) {
					status = errorMapper.mapError(status);
				}

				// Continue the call
				super.close(status, trailers);
			}
		};

		// Continue the call
		return next.startCall(wrappedCall, headers);
	}
}
