package io.blackcape.atoms.grpc.utils;

import com.google.protobuf.MessageOrBuilder;
import com.hubspot.jackson3.datatype.protobuf.ProtobufModule;
import lombok.NoArgsConstructor;
import tools.jackson.databind.json.JsonMapper;

import static lombok.AccessLevel.PRIVATE;

/**
 * A utility class for interacting with protobuf objects
 */
@NoArgsConstructor(access = PRIVATE)
public final class ProtobufUtils {
	// Constants
	private static final JsonMapper JSON_MAPPER = JsonMapper.builder()
			.addModule(new ProtobufModule())
			.build();

	/**
	 * Convert the given protobuf message to JSON
	 *
	 * @param message
	 *            The message
	 * @param <T>
	 *            The message type
	 * @return The JSON representation
	 */
	public static <T> String toJson(T message) {
		// Convert the message to JSON and return
		return JSON_MAPPER.writeValueAsString(message);
	}

	/**
	 * Convert the given protobuf message to the given java type
	 *
	 * @param message
	 *            The protobuf message
	 * @param dataClass
	 *            The java class
	 * @param <T>
	 *            The data type
	 * @return The converted message
	 */
	public static <T> T fromProto(MessageOrBuilder message, Class<T> dataClass) {
		// Convert the message and return
		return JSON_MAPPER.convertValue(message, dataClass);
	}

	/**
	 * Convert the given java object the given protobuf message type
	 *
	 * @param object
	 *            The java object
	 * @param dataClass
	 *            The protobuf message
	 * @param <T>
	 *            The data type
	 * @return The converted message
	 */
	public static <T extends MessageOrBuilder> T toProto(Object object, Class<T> dataClass) {
		// Convert the message and return
		return JSON_MAPPER.convertValue(object, dataClass);
	}
}
