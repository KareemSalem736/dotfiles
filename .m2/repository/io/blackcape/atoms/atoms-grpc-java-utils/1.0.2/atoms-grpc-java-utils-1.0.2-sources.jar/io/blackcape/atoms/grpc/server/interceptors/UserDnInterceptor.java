package io.blackcape.atoms.grpc.server.interceptors;

import io.blackcape.atoms.common.types.UserDn;
import io.grpc.Context;
import io.grpc.Context.Key;
import io.grpc.Contexts;
import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCall.Listener;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.grpc.server.GlobalServerInterceptor;
import org.springframework.stereotype.Component;

import static io.blackcape.atoms.grpc.server.interceptors.PrincipalDnInterceptor.PRINCIPAL_DN_CONTEXT_KEY;
import static io.grpc.Metadata.ASCII_STRING_MARSHALLER;
import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;

/**
 * A gRPC interceptor to extract the user DN from the incoming TLS certificate
 * and put it into the gRPC context
 */
@Component
@Order(HIGHEST_PRECEDENCE + 1)
@GlobalServerInterceptor
@ConditionalOnProperty(value = "spring.grpc.server.port")
public class UserDnInterceptor implements ServerInterceptor {
	// Constants
	private static final Metadata.Key<String> USER_DN_HEADER_KEY = Metadata.Key.of("user_dn", ASCII_STRING_MARSHALLER);

	// Public constants
	public static final Key<UserDn> USER_DN_CONTEXT_KEY = Context.key("user_dn");

	@Override
	public <T, S> Listener<T> interceptCall(
			ServerCall<T, S> call,
			Metadata headers,
			ServerCallHandler<T, S> next) {
		// Declare the user DN result
		UserDn userDn;

		// If a user_dn has been set in the headers, use it
		if (headers.containsKey(USER_DN_HEADER_KEY)) {
			userDn = new UserDn(headers.get(USER_DN_HEADER_KEY));
		}
		// Otherwise, set the principal DN to the user DN
		else {
			userDn = PRINCIPAL_DN_CONTEXT_KEY.get();
		}

		// Add the user DN to the context
		Context context = Context.current().withValue(USER_DN_CONTEXT_KEY, userDn);

		// Attach the modified context to the call
		return Contexts.interceptCall(context, call, headers, next);
	}
}
