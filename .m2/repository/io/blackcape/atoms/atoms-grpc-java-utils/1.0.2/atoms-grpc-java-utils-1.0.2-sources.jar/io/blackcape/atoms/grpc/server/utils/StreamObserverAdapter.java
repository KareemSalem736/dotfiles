package io.blackcape.atoms.grpc.server.utils;

import static lombok.AccessLevel.PRIVATE;

import io.grpc.stub.StreamObserver;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;
import lombok.NoArgsConstructor;

/**
 * A utility class to assist with handling stream observer responses
 */
@NoArgsConstructor(access = PRIVATE)
public final class StreamObserverAdapter {
	/**
	 * Process a scalar gRPC response
	 *
	 * @param observer
	 *            The stream observer
	 * @param responseSupplier
	 *            The response supplier
	 * @param <T>
	 *            The response type
	 */
	public static <T> void scalarResponse(
			StreamObserver<T> observer,
			Supplier<T> responseSupplier) {
		// Catch any exceptions
		try {
			// Get the response from the supplier and terminate
			observer.onNext(responseSupplier.get());
			observer.onCompleted();
		} catch (Exception e) {
			// Forward the error
			observer.onError(e);
		}
	}

	/**
	 * Process a stream gRPC response
	 *
	 * @param observer
	 *            The stream observer
	 * @param responseStream
	 *            The response stream
	 * @param <T>
	 *            The response type
	 */
	public static <T> void streamResponse(
			StreamObserver<T> observer,
			Stream<T> responseStream) {
		// Catch any exceptions
		try {
			// Stream all responses and terminate
			responseStream.forEach(observer::onNext);
			observer.onCompleted();
		} catch (Exception e) {
			// Forward the error
			observer.onError(e);
		}
	}

	/**
	 * Create a stream observer for the given parameters
	 *
	 * @param onNext
	 *            The request handler
	 * @param onError
	 *            The error handler
	 * @param onComplete
	 *            The on complete signal
	 * @param <R>
	 *            The request type
	 * @return The stream observer instance
	 */
	public static <R> StreamObserver<R> streamRequest(
			Consumer<R> onNext,
			Consumer<Throwable> onError,
			Runnable onComplete) {
		// Create the stream observer instance
		return new StreamObserver<R>() {
			@Override
			public void onNext(R value) {
				onNext.accept(value);
			}

			@Override
			public void onError(Throwable t) {
				onError.accept(t);
			}

			@Override
			public void onCompleted() {
				onComplete.run();
			}
		};
	}
}
